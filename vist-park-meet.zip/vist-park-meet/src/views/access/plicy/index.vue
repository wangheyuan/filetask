<template>
  <div class="app-container">
    <el-form :model="queryParams"
             ref="queryForm"
             :inline="true"
             v-show="showSearch"
             label-width="68px">
      <el-form-item label="策略名称"
                    prop="plicyName">
        <el-input v-model="queryParams.plicyName"
                  placeholder="请输入策略名称"
                  clearable
                  size="small"
                  @keyup.enter.native="handleQuery" />
      </el-form-item>
      <el-form-item>
        <el-button type="cyan"
                   icon="el-icon-search"
                   size="mini"
                   @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh"
                   size="mini"
                   @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10"
            class="mb8">
      <el-col :span="1.5">
        <el-button type="primary"
                   icon="el-icon-plus"
                   size="mini"
                   @click="handleAdd"
                   v-hasPermi="['access:plicy:add']">新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="success"
                   icon="el-icon-edit"
                   size="mini"
                   :disabled="single"
                   @click="handleUpdate"
                   v-hasPermi="['access:plicy:edit']">修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="danger"
                   icon="el-icon-delete"
                   size="mini"
                   :disabled="multiple"
                   @click="handleDelete"
                   v-hasPermi="['access:plicy:remove']">删除</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch"
                     @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading"
              :data="plicyList"
              @selection-change="handleSelectionChange">
      <el-table-column type="selection"
                       width="55"
                       align="center" />
      <el-table-column label="策略名称"
                       align="center"
                       prop="plicyName" />
      <el-table-column label="全时段"
                       align="center"
                       prop="plicyType"
                       :formatter="typeFormat" />
      <el-table-column label="标签"
                       align="center"
                       prop="postIds">
        <template slot-scope="scope">
          <el-tag style="margin-left:5px;margin-top:5px"
                  type="Plain"
                  :key="tag"
                  v-for="tag in scope.row.postIds">
            {{  labelFormat(tag) }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="设备"
                       align="center"
                       prop="deviceIds">
        <template slot-scope="scope">
          <el-tag style="margin-left:5px;margin-top:5px"
                  type="Plain"
                  :key="tag"
                  v-for="tag in scope.row.deviceIds">
            {{  deviceFormat(tag) }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="策略备注"
                       align="center"
                       prop="remark" />
      <el-table-column label="操作"
                       align="center"
                       class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button size="mini"
                     type="text"
                     icon="el-icon-edit"
                     @click="handleUpdate(scope.row)"
                     v-hasPermi="['access:plicy:edit']">修改</el-button>
          <el-button size="mini"
                     type="text"
                     icon="el-icon-delete"
                     @click="handleDelete(scope.row)"
                     v-hasPermi="['access:plicy:remove']">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination v-show="total>0"
                :total="total"
                :page.sync="queryParams.pageNum"
                :limit.sync="queryParams.pageSize"
                @pagination="getList" />

    <!-- 添加或修改策略列对话框 -->
    <el-dialog :title="title"
               :visible.sync="open"
               width="500px"
               append-to-body>
      <el-form ref="form"
               :model="form"
               :rules="rules"
               label-width="80px">
        <el-form-item label="策略名称"
                      prop="plicyName">
          <el-input v-model="form.plicyName"
                    placeholder="请输入策略名称" />
        </el-form-item>
        <el-form-item label="标签">
          <el-select v-model="form.postIds"
                     multiple
                     placeholder="请选择">
            <el-option v-for="item in postOptions"
                       :key="item.postId"
                       :label="item.postName"
                       :value="item.postId"
                       :disabled="item.status == 1"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="设备">
          <el-select v-model="form.deviceIds"
                     multiple
                     placeholder="请选择">
            <el-option v-for="item in deviceOptions"
                       :key="item.deviceId"
                       :label="item.deviceName"
                       :value="item.deviceId"
                       :disabled="item.status == 1"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="时段">
          <el-radio-group v-model="form.plicyType">
            <el-radio v-for="dict in typeOptions"
                      :key="dict.dictValue"
                      :label="dict.dictValue">{{dict.dictLabel}}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item v-show="form.plicyType=='1'"
                      label="周制">

          <el-checkbox true-label='1'
                       false-label="0"
                       label="周一"
                       v-model="form.monday"></el-checkbox>
          <el-checkbox true-label='1'
                       false-label="0"
                       v-model="form.tuesday"
                       label="周二"></el-checkbox>
          <el-checkbox true-label='1'
                       false-label="0"
                       v-model="form.wednesday"
                       label="周三"></el-checkbox>
          <el-checkbox true-label='1'
                       false-label="0"
                       v-model="form.thursday"
                       label="周四"></el-checkbox>
          <el-checkbox true-label='1'
                       false-label="0"
                       v-model="form.friday"
                       label="周五"></el-checkbox>
          <el-checkbox true-label='1'
                       false-label="0"
                       v-model="form.saturday"
                       label="周六"></el-checkbox>
          <el-checkbox true-label='1'
                       false-label="0"
                       v-model="form.sunday"
                       label="周七"></el-checkbox>

        </el-form-item>
        <el-form-item label="开始时间"
                      v-show="form.plicyType=='1'"
                      prop="startTime">
          <el-time-picker v-model="form.startTime"
                          :picker-options="{
      selectableRange: '00:00:00 - 23:59:59'
    }"
                          value-format="HH:mm:ss"
                          placeholder="开始时间">
          </el-time-picker>
        </el-form-item>
        <el-form-item label="结束时间"
                      prop="finishTime"
                      v-show="form.plicyType=='1'">
          <el-time-picker v-model="form.finishTime"
                          :picker-options="{
      selectableRange: '00:00:00 - 23:59:59'
    }"
                          value-format="HH:mm:ss"
                          placeholder="结束时间">
          </el-time-picker>
        </el-form-item>
        <el-form-item label="状态">
          <el-radio-group v-model="form.plicyStatus">
            <el-radio v-for="dict in statusOptions"
                      :key="dict.dictValue"
                      :label="dict.dictValue">{{dict.dictLabel}}</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="策略备注"
                      prop="remark">
          <el-input v-model="form.remark"
                    placeholder="请输入策略备注" />
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button type="primary"
                   @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listPlicy, getPlicy, delPlicy, addPlicy, updatePlicy, exportPlicy } from "@/api/access/plicy";

export default {
  name: "Plicy",
  data () {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 策略列表格数据
      plicyList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 状态字典
      statusOptions: [],
      // 类型字典
      typeOptions: [],
      // 标签选项
      postOptions: [],
      // 设备选项
      deviceOptions: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        plicyName: null,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
      }
    };
  },
  created () {
    //查询空策略的设备列表和标签列表
    getPlicy('').then(response => {
      this.postOptions = response.posts;
      this.deviceOptions = response.devices;
    })
    this.getList();
    this.getDicts("bs_plicy_status").then(response => {
      this.statusOptions = response.data;
    });
    this.getDicts("bs_plicy_type").then(response => {
      this.typeOptions = response.data;
    });
  },
  methods: {
    /** 查询策略列列表 */
    getList () {
      this.loading = true;
      listPlicy(this.queryParams).then(response => {
        this.plicyList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 状态字典翻译
    statusFormat (row, column) {
      return this.selectDictLabel(this.statusOptions, row.plicyStatus);
    },
    // 类型字典翻译
    typeFormat (row, column) {
      if (row.plicyType === '0') {
        return this.selectDictLabel(this.typeOptions, row.plicyType);
      } else if (row.plicyType === '1') {
        let type = this.selectDictLabel(this.typeOptions, row.plicyType);
        let monday = row.monday == '1' ? "周一 " : '';
        let tuesday = row.tuesday == '1' ? "周二 " : '';
        let wednesday = row.wednesday == '1' ? "周三 " : '';
        let thursday = row.thursday == '1' ? "周四 " : '';
        let friday = row.friday == '1' ? "周五 " : ''
        let saturday = row.saturday == '1' ? "周六 " : '';
        let sunday = row.sunday == '1' ? "周日 " : '';
        type = type + ':' + monday + tuesday + wednesday + thursday + friday + saturday + sunday + "时间：" + row.startTime + ":" + row.finishTime;
        return type;
      }

    },
    // 标签展示
    labelFormat (tag) {
      let post;
      for (const key in this.postOptions) {
        post = this.postOptions[key]
        if (post.postId === tag) {
          return post.postName;
        }
      }
      return null
    },
    // 设备展示
    deviceFormat (tag) {
      let device;
      for (const key in this.deviceOptions) {
        device = this.deviceOptions[key]
        if (device.deviceId === tag) {
          return device.deviceName;
        }
      }
      return null
    },
    // 取消按钮
    cancel () {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset () {
      this.form = {
        plicyId: null,
        plicyName: null,
        plicyStatus: '0',
        plicyType: '0',
        startTime: null,
        finishTime: null,
        monday: '1',
        tuesday: '1',
        wednesday: '1',
        thursday: '1',
        friday: '1',
        saturday: '1',
        sunday: '1',
        remark: null,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery () {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery () {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange (selection) {
      this.ids = selection.map(item => item.plicyId)
      this.single = selection.length !== 1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd () {
      this.reset();
      this.open = true;
      this.title = "添加策略列";
    },
    /** 修改按钮操作 */
    handleUpdate (row) {
      this.reset();
      const plicyId = row.plicyId || this.ids
      getPlicy(plicyId).then(response => {
        this.form = response.data;
        this.form.postIds = response.postIds;
        this.form.deviceIds = response.deviceIds;
        this.open = true;
        this.title = "修改策略列";
      });
    },
    /** 提交按钮 */
    submitForm () {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.plicyId != null) {
            updatePlicy(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("修改成功");
                this.open = false;
                this.getList();
              }
            });
          } else {
            addPlicy(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("新增成功");
                this.open = false;
                this.getList();
              }
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete (row) {
      const plicyIds = row.plicyId || this.ids;
      this.$confirm('是否确认删除策略列编号为"' + plicyIds + '"的数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function () {
        return delPlicy(plicyIds);
      }).then(() => {
        this.getList();
        this.msgSuccess("删除成功");
      }).catch(function () { });
    }
  }
};
</script>