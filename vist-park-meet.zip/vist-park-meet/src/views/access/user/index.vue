<template>
  <div class="app-container">
    <el-row :gutter="20">
      <!--部门数据-->
      <el-col :span="4"
              :xs="24">
        <div class="head-container">
          <el-input v-model="deptName"
                    placeholder="请输入部门名称"
                    clearable
                    size="small"
                    prefix-icon="el-icon-search"
                    style="margin-bottom: 20px" />
        </div>
        <div class="head-container">
          <el-tree :data="deptOptions"
                   :props="defaultProps"
                   :expand-on-click-node="false"
                   :filter-node-method="filterNode"
                   ref="tree"
                   default-expand-all
                   @node-click="handleNodeClick" />
        </div>
      </el-col>
      <!--用户数据-->
      <el-col :span="20"
              :xs="24">
        <el-form :model="queryParams"
                 ref="queryForm"
                 :inline="true"
                 v-show="showSearch"
                 label-width="68px">
          <el-form-item label="员工名称"
                        prop="visitorName">
            <el-input v-model="queryParams.visitorName"
                      placeholder="请输入员工名称"
                      clearable
                      size="small"
                      style="width: 240px"
                      @keyup.enter.native="handleQuery" />
          </el-form-item>
          <el-form-item label="证件号码"
                        prop="visitorCard">
            <el-input v-model="queryParams.visitorCard"
                      placeholder="请输入证件号码"
                      clearable
                      size="small"
                      style="width: 240px"
                      @keyup.enter.native="handleQuery" />
          </el-form-item>
          <el-form-item label="创建时间">
            <el-date-picker v-model="dateRange"
                            size="small"
                            style="width: 240px"
                            value-format="yyyy-MM-dd"
                            type="daterange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"></el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="cyan"
                       icon="el-icon-search"
                       size="mini"
                       @click="handleQuery">搜索</el-button>
            <el-button icon="el-icon-refresh"
                       size="mini"
                       @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-form>

        <el-row :gutter="10"
                class="mb8">
          <el-col :span="1.5">
            <el-button type="primary"
                       icon="el-icon-plus"
                       size="mini"
                       @click="handleAdd"
                       v-hasPermi="['system:user:add']">新增</el-button>
          </el-col>
          <el-col :span="1.5">
            <el-button type="success"
                       icon="el-icon-edit"
                       size="mini"
                       :disabled="single"
                       @click="handleUpdate"
                       v-hasPermi="['system:user:edit']">修改</el-button>
          </el-col>
          <el-col :span="1.5">
            <el-button type="danger"
                       icon="el-icon-delete"
                       size="mini"
                       :disabled="multiple"
                       @click="handleDelete"
                       v-hasPermi="['system:user:remove']">删除</el-button>
          </el-col>
          <el-col :span="1.5">
            <el-button type="info"
                       icon="el-icon-upload2"
                       size="mini"
                       @click="handleImport"
                       v-hasPermi="['system:user:import']">导入</el-button>
          </el-col>
          <!-- <el-col :span="1.5">
            <el-button type="warning"
                       icon="el-icon-download"
                       size="mini"
                       @click="handleExport"
                       v-hasPermi="['system:user:export']">导出</el-button>
          </el-col> -->
          <right-toolbar :showSearch.sync="showSearch"
                         @queryTable="getList"></right-toolbar>
        </el-row>

        <el-table v-loading="loading"
                  :data="userList"
                  @selection-change="handleSelectionChange">
          <el-table-column type="selection"
                           width="50"
                           align="center" />
          <el-table-column label="员工编码"
                           align="center"
                           prop="visitorId" />
          <el-table-column label="员工名称"
                           align="center"
                           prop="visitorName"
                           :show-overflow-tooltip="true" />
          <el-table-column label="照片"
                           align="center"
                           prop="imageId"
                           :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <img height="50"
                   :src="server.url+scope.row.imageId">
            </template>
          </el-table-column>
          <el-table-column label="身份证号"
                           align="center"
                           prop="visitorCard"
                           width="120" />
          <el-table-column label="标签"
                           align="center"
                           prop="postIds">
            <template slot-scope="scope">
              <el-tag style="margin-left:5px;margin-top:5px"
                      type="Plain"
                      :key="tag"
                      v-for="tag in scope.row.postIds">
                {{  labelFormat(tag) }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="备注"
                           align="center"
                           prop="remark" />
          <el-table-column label="创建时间"
                           align="center"
                           prop="createTime"
                           width="160">
            <template slot-scope="scope">
              <span>{{ parseTime(scope.row.createTime) }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作"
                           align="center"
                           width="180"
                           class-name="small-padding fixed-width">
            <template slot-scope="scope">
              <el-button size="mini"
                         type="text"
                         icon="el-icon-edit"
                         @click="handleUpdate(scope.row)"
                         v-hasPermi="['system:user:edit']">修改</el-button>
              <el-button v-if="scope.row.visitorId !== 1"
                         size="mini"
                         type="text"
                         icon="el-icon-delete"
                         @click="handleDelete(scope.row)"
                         v-hasPermi="['system:user:remove']">删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <pagination v-show="total>0"
                    :total="total"
                    :page.sync="queryParams.pageNum"
                    :limit.sync="queryParams.pageSize"
                    @pagination="getList" />
      </el-col>
    </el-row>

    <!-- 添加或修改参数配置对话框 -->
    <el-dialog :title="title"
               :visible.sync="open"
               width="600px"
               append-to-body>
      <el-form ref="form"
               :model="form"
               :rules="rules"
               label-width="80px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="员工名称"
                          prop="visitorName">
              <el-input v-model="form.visitorName"
                        placeholder="请输入员工名称" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="归属部门"
                          prop="deptId">
              <treeselect v-model="form.deptId"
                          :options="deptOptions"
                          :disable-branch-nodes="true"
                          :show-count="true"
                          placeholder="请选择归属部门" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="证件号码"
                          prop="visitorCard">
              <el-input v-model="form.visitorCard"
                        placeholder="请输入证件号码"
                        maxlength="11" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="标签">
              <el-select v-model="form.postIds"
                         multiple
                         placeholder="请选择">
                <el-option v-for="item in postOptions"
                           :key="item.postId"
                           :label="item.postName"
                           :value="item.postId"
                           :disabled="item.status == 1"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="人脸照片"
                          prop="imageId">
              <el-upload class="avatar-uploader"
                         :action="`${upload.url}`"
                         :headers="upload.headers"
                         :show-file-list="false"
                         :on-success="handleAvatarSuccess"
                         :before-upload="beforeAvatarUpload">
                <img v-if="form.imageUrl"
                     :src="form.imageUrl"
                     class="avatar">
                <i v-else
                   class="el-icon-plus avatar-uploader-icon">
                </i>
              </el-upload>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="备注">
              <el-input v-model="form.remark"
                        type="textarea"
                        placeholder="请输入内容"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button type="primary"
                   @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 用户导入对话框 -->
    <el-dialog :title="upload.title"
               :visible.sync="upload.open"
               width="400px"
               append-to-body>
      <el-upload ref="upload"
                 :limit="1"
                 accept=".xlsx, .xls"
                 :headers="upload.headers"
                 :action="upload.url + '?updateSupport=' + upload.updateSupport"
                 :disabled="upload.isUploading"
                 :on-progress="handleFileUploadProgress"
                 :on-success="handleFileSuccess"
                 :auto-upload="false"
                 drag>
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">
          将文件拖到此处，或
          <em>点击上传</em>
        </div>
        <div class="el-upload__tip"
             slot="tip">
          <el-checkbox v-model="upload.updateSupport" />是否更新已经存在的用户数据
          <el-link type="info"
                   style="font-size:12px"
                   @click="importTemplate">下载模板</el-link>
        </div>
        <div class="el-upload__tip"
             style="color:red"
             slot="tip">提示：仅允许导入“xls”或“xlsx”格式文件！</div>
      </el-upload>
      <div slot="footer"
           class="dialog-footer">
        <el-button type="primary"
                   @click="submitFileForm">确 定</el-button>
        <el-button @click="upload.open = false">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {
  listUser,
  getUser,
  delUser,
  addUser,
  updateUser,
  exportUser,
} from "@/api/access/user";
import { getToken } from "@/utils/auth";
import { treeselect } from "@/api/access/dept";
import Treeselect from "@riophae/vue-treeselect";
import "@riophae/vue-treeselect/dist/vue-treeselect.css";

export default {
  name: "User",
  components: { Treeselect },
  data () {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 用户表格数据
      userList: null,
      // 弹出层标题
      title: "",
      // 部门树选项
      deptOptions: undefined,
      // 是否显示弹出层
      open: false,
      // 部门名称
      deptName: undefined,
      // 默认密码
      initPassword: undefined,
      // 日期范围
      dateRange: [],
      // 状态数据字典
      statusOptions: [],
      // 性别状态字典
      sexOptions: [],
      // 标签选项
      postOptions: [],
      // 表单参数
      form: {},
      //服务器地址
      server: {
        url: process.env.VUE_APP_BASE_API
      },
      defaultProps: {
        children: "children",
        label: "label",
      },
      // 用户导入参数
      upload: {
        // 是否显示弹出层（用户导入）
        open: false,
        // 弹出层标题（用户导入）
        title: "",
        // 是否禁用上传
        isUploading: false,
        // 是否更新已经存在的用户数据
        updateSupport: 0,
        // 设置上传的请求头部
        headers: { Authorization: "Bearer " + getToken() },
        // 上传的地址
        // url: process.env.VUE_APP_BASE_API + "/system/user/importData",
        url: process.env.VUE_APP_BASE_API + "/common/upload",
      },
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        visitorName: undefined,
        visitorCard: undefined,
        deptId: undefined,
      },
      // 表单校验
      rules: {
        visitorName: [
          { required: true, message: "员工名称不能为空", trigger: "blur" },
        ],
        deptId: [
          { required: true, message: "归属部门不能为空", trigger: "blur" },
        ],
        visitorCard: [
          { required: true, message: "证件号码不能为空", trigger: "blur" },
        ],
      },
    };
  },
  watch: {
    // 根据名称筛选部门树
    deptName (val) {
      this.$refs.tree.filter(val);
    },
  },
  created () {
    getUser('').then(response => {
      this.postOptions = response.posts;
    })
    this.getList();
    this.getTreeselect();
  },
  methods: {
    /** 查询用户列表 */
    getList () {
      this.loading = true;
      listUser(this.addDateRange(this.queryParams, this.dateRange)).then(
        (response) => {
          this.userList = response.rows;
          this.total = response.total;
          this.loading = false;
        }
      );
    },
    // 标签格式化
    labelFormat (tag) {
      let post;
      for (const key in this.postOptions) {
        post = this.postOptions[key]
        if (post.postId === tag) {
          return post.postName;
        }
      }
      return null
    },
    /** 查询部门下拉树结构 */
    getTreeselect () {
      treeselect().then((response) => {
        this.deptOptions = response.data;
      });
    },
    // 筛选节点
    filterNode (value, data) {
      if (!value) return true;
      return data.label.indexOf(value) !== -1;
    },
    // 节点单击事件
    handleNodeClick (data) {
      this.queryParams.deptId = data.id;
      this.getList();
    },
    // 取消按钮
    cancel () {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset () {
      this.form = {
        visitorId: undefined,
        deptId: undefined,
        visitorName: undefined,
        visitorCard: undefined,
        imageId: undefined,
        postIds: [],
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery () {
      this.queryParams.page = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery () {
      this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange (selection) {
      this.ids = selection.map((item) => item.visitorId);
      this.single = selection.length != 1;
      this.multiple = !selection.length;
    },
    /** 新增按钮操作 */
    handleAdd () {
      this.reset();
      this.getTreeselect()
      getUser('').then((response) => {
        this.postOptions = response.posts;
        this.open = true;
        this.title = "添加用户";
      });
    },
    /** 修改按钮操作 */
    handleUpdate (row) {
      const that = this;
      this.reset();
      this.getTreeselect();
      const visitId = row.visitorId || this.ids;
      getUser(visitId).then((response) => {
        this.form = response.data;
        this.postOptions = response.posts;
        this.form.postIds = response.postIds;
        //编辑的时候初始化照片
        that.form.imageUrl = this.server.url + response.data.imageId
        this.open = true;
        this.title = "修改用户";
      });
    },

    /** 提交按钮 */
    submitForm: function () {
      this.$refs["form"].validate((valid) => {
        if (valid) {
          if (this.form.visitorId != undefined) {
            updateUser(this.form).then((response) => {
              if (response.code === 200) {
                this.msgSuccess("修改成功");
                this.open = false;
                this.getList();
              }
            });
          } else {
            addUser(this.form).then((response) => {
              if (response.code === 200) {
                this.msgSuccess("新增成功");
                this.open = false;
                this.getList();
              }
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete (row) {
      const visitorIds = row.visitorId || this.ids;
      this.$confirm(
        '是否确认删除用户编号为"' + visitorIds + '"的数据项?',
        "警告",
        {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        }
      )
        .then(function () {
          return delUser(visitorIds);
        })
        .then(() => {
          this.getList();
          this.msgSuccess("删除成功");
        })
        .catch(function () { });
    },
    /** 导出按钮操作 */
    handleExport () {
      const queryParams = this.queryParams;
      this.$confirm("是否确认导出所有用户数据项?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(function () {
          return exportUser(queryParams);
        })
        .then((response) => {
          this.download(response.msg);
        })
        .catch(function () { });
    },
    /** 导入按钮操作 */
    handleImport () {
      this.upload.title = "用户导入";
      this.upload.open = true;
    },
    /** 下载模板操作 */
    importTemplate () {
      // importTemplate().then((response) => {
      //   this.download(response.msg);
      // });
    },
    // 文件上传中处理
    handleFileUploadProgress (event, file, fileList) {
      this.upload.isUploading = true;
    },
    // 文件上传成功处理
    handleFileSuccess (response, file, fileList) {
      this.upload.open = false;
      this.upload.isUploading = false;
      this.$refs.upload.clearFiles();
      this.$alert(response.msg, "导入结果", { dangerouslyUseHTMLString: true });
      this.getList();
    },
    // 提交上传文件
    submitFileForm () {
      this.$refs.upload.submit();
    },
    handleAvatarSuccess (res, file) {
      const that = this
      that.form.imageUrl = URL.createObjectURL(file.raw)
      let { code, url, fileName } = res
      if (code === 200) {
        that.form.imageUrl = url
        that.form.imageId = fileName
        that.$forceUpdate()
      } else {
        this.$message.error('上传失败')
      }
    },
    beforeAvatarUpload (file) {
      const isJPG = file.type === 'image/jpeg'
      const isLt1M = file.size / 1024 / 1024 < 1

      if (!isJPG) {
        this.$message.error('上传头像图片只能是 JPG 格式!')
      }
      if (!isLt1M) {
        this.$message.error('上传头像图片大小不能超过 1MB!')
      }
      return isJPG && isLt1M
    }
  },
};
</script>

<style scoped>
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 100px;
  height: 100px;
  border: 2px dashed #d9d9d9;
  line-height: 100px;
  text-align: center;
}
.avatar {
  width: 100px;
  height: 100px;
  display: block;
}
</style>