<template>
  <div class="app-container">

    <el-row :gutter="20">
      <!--部门数据-->
      <el-col :span="4"
              :xs="24">
        <div class="head-container">
          <el-input v-model="deptName"
                    placeholder="请输入部门名称"
                    clearable
                    size="small"
                    prefix-icon="el-icon-search"
                    style="margin-bottom: 20px" />
        </div>
        <div class="head-container">
          <el-tree :data="deptOptions"
                   :props="defaultProps"
                   :expand-on-click-node="false"
                   :filter-node-method="filterNode"
                   ref="tree"
                   default-expand-all
                   @node-click="handleNodeClick" />
        </div>
      </el-col>
      <!--用户数据-->
      <el-col :span="20"
              :xs="24">
        <el-form :model="queryParams"
                 ref="queryForm"
                 :inline="true"
                 v-show="showSearch"
                 label-width="68px">
          <!-- <el-form-item label="考勤时间"
                        prop="createTime">
            <el-date-picker clearable
                            size="small"
                            style="width: 200px"
                            v-model="queryParams.checkDay"
                            type="date"
                            value-format="yyyy-MM-dd"
                            placeholder="选择创建时间">
            </el-date-picker>
          </el-form-item> -->
                    <el-form-item label="考勤日期">
            <el-date-picker v-model="dateRange"
                            size="small"
                            style="width: 240px"
                            value-format="yyyy-MM-dd"
                            type="daterange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"></el-date-picker>
          </el-form-item>
          <el-form-item label="名称"
                        prop="staffName">
            <el-input v-model="queryParams.staffName"
                      placeholder="请输入名称"
                      clearable
                      size="small"
                      @keyup.enter.native="handleQuery" />
          </el-form-item>
          <el-form-item label="工号"
                        prop="staffCard">
            <el-input v-model="queryParams.staffCard"
                      placeholder="请输入工号"
                      clearable
                      size="small"
                      @keyup.enter.native="handleQuery" />
          </el-form-item>
          <el-form-item label="状态"
                        prop="status">
            <el-select v-model="queryParams.status"
                       placeholder="请选择状态"
                       clearable
                       size="small">
              <el-option v-for="dict in statusOptions"
                         :key="dict.dictValue"
                         :label="dict.dictLabel"
                         :value="dict.dictValue" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="cyan"
                       icon="el-icon-search"
                       size="mini"
                       @click="handleQuery">搜索</el-button>
            <el-button icon="el-icon-refresh"
                       size="mini"
                       @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-form>

        <el-row :gutter="10"
                class="mb8">
          <el-col :span="1.5">
            <el-button type="success"
                       icon="el-icon-edit"
                       size="mini"
                       :disabled="single"
                       @click="handleUpdate"
                       v-hasPermi="['check:checkDay:edit']">修改</el-button>
          </el-col>
          <el-col :span="1.5">
            <el-button type="warning"
                       icon="el-icon-download"
                       size="mini"
                       @click="handleExport"
                       v-hasPermi="['check:checkDay:export']">导出</el-button>
          </el-col>
          <right-toolbar :showSearch.sync="showSearch"
                         @queryTable="getList"></right-toolbar>
        </el-row>

        <el-table v-loading="loading"
                  :data="checkDayList"
                  @selection-change="handleSelectionChange">
          <el-table-column type="selection"
                           width="55"
                           align="center" />
          <el-table-column label="工号"
                           align="center"
                           prop="staffCard" />
          <el-table-column label="名称"
                           align="center"
                           prop="staffName" />

          <el-table-column label="照片"
                           align="center"
                           prop="imageId">
            <template slot-scope="scope">
              <img height="50"
                   :src="server.url+scope.row.imageId">
            </template>
          </el-table-column>
          <el-table-column label="日期"
                           align="center"
                           prop="checkDay" />
          <el-table-column label="备注"
                           align="center"
                           prop="remark" />
          <el-table-column label="工时"
                           align="center"
                           prop="normalHour" />

          <el-table-column label="上班时间"
                           align="center"
                           prop="inTime"
                           width="180">
            <template slot-scope="scope">
              <span>{{ parseTime(scope.row.inTime, '{y}-{m}-{d} / {h}:{i}:{s}') }}</span>
            </template>
          </el-table-column>
          <el-table-column label="下班时间"
                           align="center"
                           prop="outTime"
                           width="180">
            <template slot-scope="scope">
              <span>{{ parseTime(scope.row.outTime, '{y}-{m}-{d} / {h}:{i}:{s}') }}</span>
            </template>
          </el-table-column>
          <el-table-column label="状态"
                           align="center"
                           prop="status"
                           :formatter="statusFormat" />
          <el-table-column label="创建时间"
                           align="center"
                           prop="createTime"
                           width="180">
            <template slot-scope="scope">
              <span>{{ parseTime(scope.row.createTime, '{y}-{m}-{d} / {h}:{i}:{s}') }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作"
                           align="center"
                           class-name="small-padding fixed-width">
            <template slot-scope="scope">
              <el-button size="mini"
                         type="text"
                         icon="el-icon-edit"
                         @click="handleUpdate(scope.row)"
                         v-hasPermi="['check:checkDay:edit']">修改</el-button>
              <el-button size="mini"
                         type="text"
                         icon="el-icon-delete"
                         @click="handleDelete(scope.row)"
                         v-hasPermi="['check:checkDay:remove']">删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <pagination v-show="total>0"
                    :total="total"
                    :page.sync="queryParams.pageNum"
                    :limit.sync="queryParams.pageSize"
                    @pagination="getList" />
      </el-col>
    </el-row>
    <!-- 添加或修改每日考勤对话框 -->
    <el-dialog :title="title"
               :visible.sync="open"
               width="500px"
               append-to-body>
      <el-form ref="form"
               :model="form"
               :rules="rules"
               label-width="80px">
        <el-form-item label="状态"
                      prop="status">
          <el-select v-model="form.status"
                     placeholder="请选择考勤状态">
            <el-option v-for="dict in statusOptions"
                       :key="dict.dictValue"
                       :label="dict.dictLabel"
                       :value="dict.dictValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="备注"
                      prop="remark">
          <el-input v-model="form.remark"
                    type="textarea"
                    placeholder="请输入内容" />
        </el-form-item>

      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button type="primary"
                   @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listCheckDay, getCheckDay, delCheckDay, addCheckDay, updateCheckDay, exportCheckDay } from "@/api/check/checkDay";
import { treeselect } from "@/api/check/staffDept";
import Treeselect from "@riophae/vue-treeselect";
import "@riophae/vue-treeselect/dist/vue-treeselect.css";

export default {
  name: "CheckDay",
  data () {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 部门名称
      deptName: undefined,
      // 总条数
      total: 0,
      // 每日考勤表格数据
      checkDayList: [],
      // 弹出层标题
      title: "",
      // 部门树选项
      deptOptions: undefined,
      defaultProps: {
        children: "children",
        label: "label",
      },
      // 是否显示弹出层
      open: false,
      // 状态字典
      statusOptions: [],
      //服务器地址
      server: {
        url: process.env.VUE_APP_BASE_API
      },
      // 日期范围
      dateRange: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        staffName: null,
        staffCard: null,
        status: null,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
      }
    };
  },
  watch: {
    // 根据名称筛选部门树
    deptName (val) {
      this.$refs.tree.filter(val);
    },
  },
  created () {
    this.getList();
    this.getDicts("bs_check_staff_status").then(response => {
      this.statusOptions = response.data;
    });
    this.getTreeselect();
  },
  methods: {
    /** 查询每日考勤列表 */
    getList () {
      this.loading = true;
      listCheckDay(this.addDateRange(this.queryParams, this.dateRange)).then(response => {
        this.checkDayList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 状态字典翻译
    statusFormat (row, column) {
      return this.selectDictLabel(this.statusOptions, row.status);
    },
    /** 查询部门下拉树结构 */
    getTreeselect () {
      treeselect().then((response) => {
        this.deptOptions = response.data;
      });
    },
    // 筛选节点
    filterNode (value, data) {
      if (!value) return true;
      return data.label.indexOf(value) !== -1;
    },
    // 节点单击事件
    handleNodeClick (data) {
      this.queryParams.deptId = data.id;
      this.getList();
    },
    // 取消按钮
    cancel () {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset () {
      this.form = {
        historyDayId: null,
        staffId: null,
        staffName: null,
        staffCard: null,
        imageId: null,
        checkDay: null,
        status: null,
        remark: null,
        normalHour: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        inTime: null,
        deptId: undefined,
        outTime: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery () {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery () {
            this.dateRange = [];
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange (selection) {
      this.ids = selection.map(item => item.historyDayId)
      this.single = selection.length !== 1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd () {
      this.reset();
      this.open = true;
      this.title = "添加每日考勤";
    },
    /** 修改按钮操作 */
    handleUpdate (row) {
      this.reset();
      const historyDayId = row.historyDayId || this.ids
      getCheckDay(historyDayId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改每日考勤";
      });
    },
    /** 提交按钮 */
    submitForm () {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.historyDayId != null) {
            updateCheckDay(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("修改成功");
                this.open = false;
                this.getList();
              }
            });
          } else {
            addCheckDay(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("新增成功");
                this.open = false;
                this.getList();
              }
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete (row) {
      const historyDayIds = row.historyDayId || this.ids;
      this.$confirm('是否确认删除每日考勤编号为"' + historyDayIds + '"的数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function () {
        return delCheckDay(historyDayIds);
      }).then(() => {
        this.getList();
        this.msgSuccess("删除成功");
      }).catch(function () { });
    },
    /** 导出按钮操作 */
    handleExport () {
      const queryParams = this.queryParams;
      this.$confirm('是否确认导出所有每日考勤数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function () {
        return exportCheckDay(queryParams);
      }).then(response => {
        this.download(response.msg);
      }).catch(function () { });
    }
  }
};
</script>