import request from '@/utils/request'

// 查询会议详情列表
export function listMeetLine (query) {
  return request({
    url: '/meet/meetLine/list',
    method: 'get',
    params: query
  })
}

// 查询会议详情详细
export function getMeetLine (lineId) {
  return request({
    url: '/meet/meetLine/' + lineId,
    method: 'get'
  })
}

// 新增会议详情
export function addMeetLine (data) {
  return request({
    url: '/meet/meetLine',
    method: 'post',
    data: data
  })
}

// 修改会议详情
export function updateMeetLine (data) {
  return request({
    url: '/meet/meetLine',
    method: 'put',
    data: data
  })
}

// 删除会议详情
export function delMeetLine (lineId) {
  return request({
    url: '/meet/meetLine/' + lineId,
    method: 'delete'
  })
}

// 导出会议详情
export function exportMeetLine (query) {
  return request({
    url: '/meet/meetLine/export',
    method: 'get',
    params: query
  })
}