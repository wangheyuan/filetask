import request from '@/utils/request'

// 查询微软训练模型列表
export function listMeetModel (query) {
  return request({
    url: '/meet/meetModel/list',
    method: 'get',
    params: query
  })
}

// 查询微软训练模型详细
export function getMeetModel (modelId) {
  return request({
    url: '/meet/meetModel/' + modelId,
    method: 'get'
  })
}

// 新增微软训练模型
export function addMeetModel (data) {
  return request({
    url: '/meet/meetModel',
    method: 'post',
    data: data
  })
}

// 修改微软训练模型
export function updateMeetModel (data) {
  return request({
    url: '/meet/meetModel',
    method: 'put',
    data: data
  })
}

// 删除微软训练模型
export function delMeetModel (modelId) {
  return request({
    url: '/meet/meetModel/' + modelId,
    method: 'delete'
  })
}

// 导出微软训练模型
export function exportMeetModel (query) {
  return request({
    url: '/meet/meetModel/export',
    method: 'get',
    params: query
  })
}