import request from '@/utils/request'

// 查询日志列表列表
export function listMeetLog (query) {
  return request({
    url: '/meet/meetLog/list',
    method: 'get',
    params: query
  })
}

// 查询日志列表详细
export function getMeetLog (logId) {
  return request({
    url: '/meet/meetLog/' + logId,
    method: 'get'
  })
}

// 新增日志列表
export function addMeetLog (data) {
  return request({
    url: '/meet/meetLog',
    method: 'post',
    data: data
  })
}

// 修改日志列表
export function updateMeetLog (data) {
  return request({
    url: '/meet/meetLog',
    method: 'put',
    data: data
  })
}

// 删除日志列表
export function delMeetLog (logId) {
  return request({
    url: '/meet/meetLog/' + logId,
    method: 'delete'
  })
}

// 导出日志列表
export function exportMeetLog (query) {
  return request({
    url: '/meet/meetLog/export',
    method: 'get',
    params: query
  })
}