import request from '@/utils/request'

// 查询会议列表列表
export function listMeet (query) {
  return request({
    url: '/meet/meet/list',
    method: 'get',
    params: query
  })
}

// 查询会议列表详细
export function getMeet (meetId) {
  return request({
    url: '/meet/meet/' + meetId,
    method: 'get'
  })
}

// 新增会议列表
export function addMeet (data) {
  return request({
    url: '/meet/meet',
    method: 'post',
    data: data
  })
}

// 修改会议列表
export function updateMeet (data) {
  return request({
    url: '/meet/meet',
    method: 'put',
    data: data
  })
}

// 删除会议列表
export function delMeet (meetId) {
  return request({
    url: '/meet/meet/' + meetId,
    method: 'delete'
  })
}

// 导出会议列表
export function exportMeet (query) {
  return request({
    url: '/meet/meet/export',
    method: 'get',
    params: query
  })
}