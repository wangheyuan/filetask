import request from '@/utils/request'

// 查询访客历史列表列表
export function listHistory(query) {
  return request({
    url: '/access/history/list',
    method: 'get',
    params: query
  })
}

// 查询访客历史列表详细
export function getHistory(visitorId) {
  return request({
    url: '/access/history/' + visitorId,
    method: 'get'
  })
}

// 新增访客历史列表
export function addHistory(data) {
  return request({
    url: '/access/history',
    method: 'post',
    data: data
  })
}

// 修改访客历史列表
export function updateHistory(data) {
  return request({
    url: '/access/history',
    method: 'put',
    data: data
  })
}

// 删除访客历史列表
export function delHistory(visitorId) {
  return request({
    url: '/access/history/' + visitorId,
    method: 'delete'
  })
}

// 导出访客历史列表
export function exportHistory(query) {
  return request({
    url: '/access/history/export',
    method: 'get',
    params: query
  })
}