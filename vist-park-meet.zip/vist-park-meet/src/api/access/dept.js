import request from '@/utils/request'

// 查询门禁系统部门管理列表
export function listDept(query) {
  return request({
    url: '/access/dept/list',
    method: 'get',
    params: query
  })
}

// 查询门禁系统部门管理详细
export function getDept(deptId) {
  return request({
    url: '/access/dept/' + deptId,
    method: 'get'
  })
}

// 新增门禁系统部门管理
export function addDept(data) {
  return request({
    url: '/access/dept',
    method: 'post',
    data: data
  })
}

// 修改门禁系统部门管理
export function updateDept(data) {
  return request({
    url: '/access/dept',
    method: 'put',
    data: data
  })
}

// 删除门禁系统部门管理
export function delDept(deptId) {
  return request({
    url: '/access/dept/' + deptId,
    method: 'delete'
  })
}

// 导出门禁系统部门管理
export function exportDept(query) {
  return request({
    url: '/access/dept/export',
    method: 'get',
    params: query
  })
}

// 查询部门下拉树结构
export function treeselect() {
  return request({
    url: '/access/dept/treeselect',
    method: 'get'
  })
}