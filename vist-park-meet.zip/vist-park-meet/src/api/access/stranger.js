import request from '@/utils/request'

// 查询陌生人列表列表
export function listStranger (query) {
  return request({
    url: '/access/stranger/list',
    method: 'get',
    params: query
  })
}

// 通过陌生人录入
export function passStranger (strangerId) {
  return request({
    url: '/access/stranger/pass/' + strangerId,
    method: 'get'
  })
}

// 查询陌生人列表详细
export function getStranger (strangerId) {
  return request({
    url: '/access/stranger/' + strangerId,
    method: 'get'
  })
}

// 新增陌生人列表
export function addStranger (data) {
  return request({
    url: '/access/stranger',
    method: 'post',
    data: data
  })
}

// 修改陌生人列表
export function updateStranger (data) {
  return request({
    url: '/access/stranger',
    method: 'put',
    data: data
  })
}

// 删除陌生人列表
export function delStranger (strangerId) {
  return request({
    url: '/access/stranger/' + strangerId,
    method: 'delete'
  })
}

// 导出陌生人列表
export function exportStranger (query) {
  return request({
    url: '/access/stranger/export',
    method: 'get',
    params: query
  })
}