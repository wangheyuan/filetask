import request from '@/utils/request'
import { Upload } from 'element-ui'

// 查询访客信息管理列表
export function listUser (query) {
  return request({
    url: '/access/user/list',
    method: 'get',
    params: query
  })
}

// 查询访客信息管理详细
export function getUser (userId) {
  return request({
    url: '/access/user/' + userId,
    method: 'get'
  })
}

// 新增访客信息管理
export function addUser (data) {
  return request({
    url: '/access/user',
    method: 'post',
    data: data
  })
}

// 修改访客信息管理
export function updateUser (data) {
  return request({
    url: '/access/user',
    method: 'put',
    data: data
  })
}

// 删除访客信息管理
export function delUser (userId) {
  return request({
    url: '/access/user/' + userId,
    method: 'delete'
  })
}

// 导出访客信息管理
export function exportUser (query) {
  return request({
    url: '/access/user/export',
    method: 'get',
    params: query
  })
}
