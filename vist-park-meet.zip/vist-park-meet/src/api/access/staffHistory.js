import request from '@/utils/request'

// 查询员工考勤历史列列表
export function listHistory(query) {
  return request({
    url: '/staffHistory/history/list',
    method: 'get',
    params: query
  })
}

// 查询员工考勤历史列详细
export function getHistory(visitorId) {
  return request({
    url: '/staffHistory/history/' + visitorId,
    method: 'get'
  })
}

// 新增员工考勤历史列
export function addHistory(data) {
  return request({
    url: '/staffHistory/history',
    method: 'post',
    data: data
  })
}

// 修改员工考勤历史列
export function updateHistory(data) {
  return request({
    url: '/staffHistory/history',
    method: 'put',
    data: data
  })
}

// 删除员工考勤历史列
export function delHistory(visitorId) {
  return request({
    url: '/staffHistory/history/' + visitorId,
    method: 'delete'
  })
}

// 导出员工考勤历史列
export function exportHistory(query) {
  return request({
    url: '/staffHistory/history/export',
    method: 'get',
    params: query
  })
}