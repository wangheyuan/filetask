import request from '@/utils/request'

// 查询每日考勤列表
export function listCheckDay (query) {
  return request({
    url: '/check/checkDay/list',
    method: 'get',
    params: query
  })
}

// 查询每日考勤详细
export function getCheckDay (historyDayId) {
  return request({
    url: '/check/checkDay/' + historyDayId,
    method: 'get'
  })
}

// 新增每日考勤
export function addCheckDay (data) {
  return request({
    url: '/check/checkDay',
    method: 'post',
    data: data
  })
}

// 修改每日考勤
export function updateCheckDay (data) {
  return request({
    url: '/check/checkDay',
    method: 'put',
    data: data
  })
}

// 删除每日考勤
export function delCheckDay (historyDayId) {
  return request({
    url: '/check/checkDay/' + historyDayId,
    method: 'delete'
  })
}

// 导出每日考勤
export function exportCheckDay (query) {
  return request({
    url: '/check/checkDay/export',
    method: 'get',
    params: query
  })
}