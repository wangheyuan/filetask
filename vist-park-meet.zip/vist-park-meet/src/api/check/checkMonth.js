import request from '@/utils/request'

// 查询员工每月考勤列表
export function listCheckMonth (query) {
  return request({
    url: '/check/checkMonth/list',
    method: 'get',
    params: query
  })
}

// 查询员工每月考勤详细
export function getCheckMonth (historyMonthId) {
  return request({
    url: '/check/checkMonth/' + historyMonthId,
    method: 'get'
  })
}

// 新增员工每月考勤
export function addCheckMonth (data) {
  return request({
    url: '/check/checkMonth',
    method: 'post',
    data: data
  })
}

// 修改员工每月考勤
export function updateCheckMonth (data) {
  return request({
    url: '/check/checkMonth',
    method: 'put',
    data: data
  })
}

// 删除员工每月考勤
export function delCheckMonth (historyMonthId) {
  return request({
    url: '/check/checkMonth/' + historyMonthId,
    method: 'delete'
  })
}

// 导出员工每月考勤
export function exportCheckMonth (query) {
  return request({
    url: '/check/checkMonth/export',
    method: 'get',
    params: query
  })
}