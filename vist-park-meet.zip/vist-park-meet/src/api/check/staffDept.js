import request from '@/utils/request'

// 查询员工部门管理列表
export function listStaffDept (query) {
  return request({
    url: '/check/staffDept/list',
    method: 'get',
    params: query
  })
}

// 查询员工部门管理详细
export function getStaffDept (deptId) {
  return request({
    url: '/check/staffDept/' + deptId,
    method: 'get'
  })
}

// 新增员工部门管理
export function addStaffDept (data) {
  return request({
    url: '/check/staffDept',
    method: 'post',
    data: data
  })
}

// 修改员工部门管理
export function updateStaffDept (data) {
  return request({
    url: '/check/staffDept',
    method: 'put',
    data: data
  })
}

// 删除员工部门管理
export function delStaffDept (deptId) {
  return request({
    url: '/check/staffDept/' + deptId,
    method: 'delete'
  })
}

// 导出员工部门管理
export function exportStaffDept (query) {
  return request({
    url: '/check/staffDept/export',
    method: 'get',
    params: query
  })
}

// 查询部门下拉树结构
export function treeselect () {
  return request({
    url: '/check/staffDept/treeselect',
    method: 'get'
  })
}