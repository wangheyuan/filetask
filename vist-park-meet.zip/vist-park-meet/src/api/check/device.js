import request from '@/utils/request'

// 查询通用设备列表
export function listDevice (query) {
  return request({
    url: '/check/device/list',
    method: 'get',
    params: query
  })
}

// 查询通用设备详细
export function getDevice (deviceId) {
  return request({
    url: '/check/device/' + deviceId,
    method: 'get'
  })
}

// 新增通用设备
export function addDevice (data) {
  return request({
    url: '/check/device',
    method: 'post',
    data: data
  })
}

// 修改通用设备
export function updateDevice (data) {
  return request({
    url: '/check/device',
    method: 'put',
    data: data
  })
}

// 删除通用设备
export function delDevice (deviceId) {
  return request({
    url: '/check/device/' + deviceId,
    method: 'delete'
  })
}

// 导出通用设备
export function exportDevice (query) {
  return request({
    url: '/check/device/export',
    method: 'get',
    params: query
  })
}