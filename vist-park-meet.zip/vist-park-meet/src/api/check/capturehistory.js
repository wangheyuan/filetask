import request from '@/utils/request'

// 查询员工抓拍历史列表
export function listCapturehistory (query) {
  return request({
    url: '/check/capturehistory/list',
    method: 'get',
    params: query
  })
}

// 查询员工抓拍历史详细
export function getCapturehistory (historyId) {
  return request({
    url: '/check/capturehistory/' + historyId,
    method: 'get'
  })
}

// 新增员工抓拍历史
export function addCapturehistory (data) {
  return request({
    url: '/check/capturehistory',
    method: 'post',
    data: data
  })
}

// 修改员工抓拍历史
export function updateCapturehistory (data) {
  return request({
    url: '/check/capturehistory',
    method: 'put',
    data: data
  })
}

// 删除员工抓拍历史
export function delCapturehistory (historyId) {
  return request({
    url: '/check/capturehistory/' + historyId,
    method: 'delete'
  })
}

// 导出员工抓拍历史
export function exportCapturehistory (query) {
  return request({
    url: '/check/capturehistory/export',
    method: 'get',
    params: query
  })
}