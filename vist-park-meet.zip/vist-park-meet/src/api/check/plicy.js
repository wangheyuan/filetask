import request from '@/utils/request'

// 查询策略列列表
export function listPlicy (query) {
  return request({
    url: '/check/plicy/list',
    method: 'get',
    params: query
  })
}

// 查询策略列详细
export function getPlicy (plicyId) {
  return request({
    url: '/check/plicy/' + plicyId,
    method: 'get'
  })
}

// 新增策略列
export function addPlicy (data) {
  return request({
    url: '/check/plicy',
    method: 'post',
    data: data
  })
}

// 修改策略列
export function updatePlicy (data) {
  return request({
    url: '/check/plicy',
    method: 'put',
    data: data
  })
}

// 删除策略列
export function delPlicy (plicyId) {
  return request({
    url: '/check/plicy/' + plicyId,
    method: 'delete'
  })
}