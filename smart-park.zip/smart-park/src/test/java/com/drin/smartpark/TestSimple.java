/**
 * 文件名称:          	TestSimple
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark;

import org.junit.jupiter.api.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.Date;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/11/24 16:17
 */
public class TestSimple {

    private static String getAccountByRtspUrl(String url) {
        if(url!=null) {
            String[] str = url.split("@");
            if(str.length==2) {
                String pre = str[0];
                String[] pres = pre.split(":");
                if(pres.length == 3) {
                    String host=  pres[1];
                    if(host.length()>=3) {
                        return host.substring(2);
                    }
                }
            }
        }
        return null;
    }

    public static void main(String[] args) {
        System.out.println(getAccountByRtspUrl("rtsp://admin:Admin1205@172.16.25.43"));
    }

    @Test
    public void testDate() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String s = sdf.format(new Date());
//        Date date =  sdf.parse(s);
        System.out.println(new Date());


        LocalDate localDate = LocalDate.now();
        Date now = Date.from(localDate.plusMonths(2).atStartOfDay(ZoneId.systemDefault()).toInstant());
        System.out.println(now.toString());
        System.out.println("-------------------1月----------------------");
        System.out.println(sdf.format(now));




        Date date = new Date();
        Instant instant = date.toInstant();
        ZoneId zone = ZoneId.systemDefault();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, zone);
        LocalTime localTime = localDateTime.toLocalTime();
        System.out.println(localTime);
    }

    @Test
    public void testDateFormat() {
        String captureTime = "2020-12-03T13:42:05+08:00";
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        try {
           Date date = fmt.parse(captureTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testTime() {
        LocalTime nowTime = LocalTime.now();
        System.out.println(nowTime);
    }

    @Test
    public void testTest99() {
        String rtspUrl = "rtsp://172.03.23.52";
        String[]  ips = rtspUrl.split("rtsp://");
        System.out.println(ips.length);
        for (int i = 0; i < ips.length; i++) {
            System.out.println(ips[i]);
        }

    }
}
