package com.drin.smartpark;

import com.drin.smartpark.common.tool.JsonUtil;
import com.drin.smartpark.project.api.ythz.DeviceApi;
import com.drin.smartpark.project.api.ythz.dto.ChannelConfigDto;
import com.drin.smartpark.project.api.ythz.form.capture.CaptureChannelsConfig;
import com.drin.smartpark.project.api.ythz.form.video.ChannelConfig;
import com.drin.smartpark.project.api.ythz.form.video.VideoChannel;
import com.drin.smartpark.project.api.ythz.service.RetrofitService;
import com.drin.smartpark.project.check.dto.QueryCheckPlicyParam;
import com.drin.smartpark.project.check.entity.BsCheckPlicy;
import com.drin.smartpark.project.check.mapper.BsCheckPlicyMapper;
import lombok.SneakyThrows;
import net.bytebuddy.asm.Advice;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

@SpringBootTest
class SmartParkApplicationTests {

    @Autowired
    private BsCheckPlicyMapper bsCheckPlicyMapper;

    @Autowired
    private RetrofitService retrofitService;

    @Test
    void contextLoads() {
    }

    @Test
    public void testMapper() {
        QueryCheckPlicyParam param = new QueryCheckPlicyParam();
        param.setDeviceId(21);
        param.setDeptId(7L);
        Long[] postIds =new Long[]{1L};
        param.setPostIds(postIds);
        List<Long> plicyIds = bsCheckPlicyMapper.selectBsCheckPlicyByParam(param);
        for (int i = 0; i < plicyIds.toArray().length; i++) {
            System.out.println(plicyIds.get(i));
        }

        List<BsCheckPlicy> plicys = bsCheckPlicyMapper.selectBsCheckPlicyListByIds(plicyIds);
        if(CollectionUtils.isEmpty(plicys)) {
            System.out.println("-----------null------------");
        }else {
            plicys.stream().forEach(p->{
                System.out.println(p.toString());
            });
        }

    }

    @Test
    public void testHzDevice() throws IOException {
        DeviceApi deviceApi = retrofitService.getApiByIPService("http://172.16.25.166", DeviceApi.class);
        ChannelConfigDto config = deviceApi.channelConfig().execute().body();
        System.out.println(JsonUtil.toJsonString(config));
        List<VideoChannel> lists = config.getChannel_config().getVideo_channels();
        lists.stream().forEach(d->{
            if(d.getChannel_id().equals("6")) {
                System.out.println("----------------------------------------enter-------------------");
                d.setChannel_url("wwttt");
                d.setNumber(0);
            }
        });

        deviceApi.updateChannelConfig(config).execute().body();

    }

    @SneakyThrows
    @Test
    public void testHzCaptureDevice() {
        DeviceApi deviceApi = retrofitService.getApiByIPService("http://172.16.25.166", DeviceApi.class);
        CaptureChannelsConfig config = deviceApi.channelCaptrueConfig().execute().body();
        System.out.println("----------获取抓拍机配置--------------");
        System.out.println(JsonUtil.toJsonString(config));
        config.getCapture_channels().stream().forEach(d->{
            if(d.getChannel_id().equals("CA")) {
                d.setChannel_name("hello");
            }
            d.getTarget_repo().add("1");
        });
        deviceApi.updateCaptureCamera(config).execute().body();
    }

}
