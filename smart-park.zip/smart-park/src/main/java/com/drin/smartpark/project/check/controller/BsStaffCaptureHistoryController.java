package com.drin.smartpark.project.check.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.project.check.entity.BsStaffCaptureHistory;
import com.drin.smartpark.project.check.service.IBsStaffCaptureHistoryService;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.page.TableDataInfo;

/**
 * 员工抓拍历史Controller
 *
 * @author wangheyuan
 * @date 2020-11-26
 */
@RestController
@RequestMapping("/check/capturehistory")
public class BsStaffCaptureHistoryController extends BaseController
{
    @Autowired
    private IBsStaffCaptureHistoryService bsStaffCaptureHistoryService;

    /**
     * 查询员工抓拍历史列表
     */
    @RequiresPermissions("check:capturehistory:list")
    @GetMapping("/list")
    public TableDataInfo list(BsStaffCaptureHistory bsStaffCaptureHistory)
    {
        startPage();
        List<BsStaffCaptureHistory> list = bsStaffCaptureHistoryService.selectBsStaffCaptureHistoryList(bsStaffCaptureHistory);
        return getDataTable(list);
    }

    /**
     * 导出员工抓拍历史列表
     */
    @RequiresPermissions("check:capturehistory:export")
    @Log(title = "员工抓拍历史", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsStaffCaptureHistory bsStaffCaptureHistory)
    {
        List<BsStaffCaptureHistory> list = bsStaffCaptureHistoryService.selectBsStaffCaptureHistoryList(bsStaffCaptureHistory);
        ExcelUtil<BsStaffCaptureHistory> util = new ExcelUtil<BsStaffCaptureHistory>(BsStaffCaptureHistory.class);
        return util.exportExcel(list, "capturehistory");
    }

    /**
     * 获取员工抓拍历史详细信息
     */
    @RequiresPermissions("check:capturehistory:query")
    @GetMapping(value = "/{historyId}")
    public RestResp getInfo(@PathVariable("historyId") Long historyId)
    {
        return RestResp.success(bsStaffCaptureHistoryService.selectBsStaffCaptureHistoryById(historyId));
    }

    /**
     * 新增员工抓拍历史
     */
    @RequiresPermissions("check:capturehistory:add")
    @Log(title = "员工抓拍历史", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsStaffCaptureHistory bsStaffCaptureHistory)
    {
        return toAjax(bsStaffCaptureHistoryService.insertBsStaffCaptureHistory(bsStaffCaptureHistory));
    }

    /**
     * 修改员工抓拍历史
     */
    @RequiresPermissions("check:capturehistory:edit")
    @Log(title = "员工抓拍历史", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsStaffCaptureHistory bsStaffCaptureHistory)
    {
        return toAjax(bsStaffCaptureHistoryService.updateBsStaffCaptureHistory(bsStaffCaptureHistory));
    }

    /**
     * 删除员工抓拍历史
     */
    @RequiresPermissions("check:capturehistory:remove")
    @Log(title = "员工抓拍历史", businessType = BusinessType.DELETE)
    @DeleteMapping("/{historyIds}")
    public RestResp remove(@PathVariable Long[] historyIds)
    {
        return toAjax(bsStaffCaptureHistoryService.deleteBsStaffCaptureHistoryByIds(historyIds));
    }
}