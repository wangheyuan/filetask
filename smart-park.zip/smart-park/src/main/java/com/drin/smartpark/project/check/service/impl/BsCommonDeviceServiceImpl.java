package com.drin.smartpark.project.check.service.impl;

import java.util.*;
import java.util.stream.Collectors;

import com.drin.smartpark.common.exception.CustomException;
import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.common.tool.SecurityUtils;
import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.project.access.entity.BsDevice;
import com.drin.smartpark.project.api.common.service.CommonFaceDeviceService;
import com.drin.smartpark.project.system.model.TreeSelect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.drin.smartpark.project.check.mapper.BsCommonDeviceMapper;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.service.IBsCommonDeviceService;
import org.springframework.util.CollectionUtils;

/**
 * 通用设备Service业务层处理
 *
 * @author wangheyuan
 * @date 2020-11-23
 */
@Service
public class BsCommonDeviceServiceImpl implements IBsCommonDeviceService
{
    @Autowired
    private BsCommonDeviceMapper bsCommonDeviceMapper;

    @Autowired
    private CommonFaceDeviceService commonFaceDeviceService;

    /**
     * 查询通用设备
     *
     * @param deviceId 通用设备ID
     * @return 通用设备
     */
    @Override
    public BsCommonDevice selectBsCommonDeviceById(Integer deviceId)
    {
        return bsCommonDeviceMapper.selectBsCommonDeviceById(deviceId);
    }

    /**
     * 查询通用设备
     *
     * @param realId 第三方平台设备ID
     * @return 通用设备
     */
    @Override
    public BsCommonDevice selectBsCommonDeviceByRealId(String realId) {
        return bsCommonDeviceMapper.selectBsCommonDeviceByRealId(realId);
    }

    /**
     * 查询通用设备列表
     *
     * @param bsCommonDevice 通用设备
     * @return 通用设备
     */
    @Override
    public List<BsCommonDevice> selectBsCommonDeviceList(BsCommonDevice bsCommonDevice)
    {
        return bsCommonDeviceMapper.selectBsCommonDeviceList(bsCommonDevice);
    }

    /**
     * 新增通用设备
     *
     * @param bsCommonDevice 通用设备
     * @return 结果
     */
    @Override
    public int insertBsCommonDevice(BsCommonDevice bsCommonDevice)
    {
        // 校验设备是否可以添加
        if(bsCommonDevice.getParentId().equals("1")) {
            //直连平台 目前只能接人脸闸机，如果选中的不是人脸闸机，那么返回错误
            if(bsCommonDevice.getDeviceType().equals("0")) {
                throw new CustomException("直连平台只允许添加真地人脸闸机");
            }
        }else {
          BsCommonDevice parentD = bsCommonDeviceMapper.selectBsCommonDeviceById(bsCommonDevice.getParentId());
          switch (parentD.getDeviceType()) {
              // 平台选择为盒子的时候，后面只能添加 盒子摄像头 和 盒子抓拍机
              case "1":
                  if(!bsCommonDevice.getDeviceType().equals("2") && !bsCommonDevice.getDeviceType().equals("3") ) {
                      throw new CustomException("盒子平台只允许添加盒子摄像头和盒子抓拍机");
                  }
                  break;
              // 平台选择为云悉的时候，后面只能添加 云悉下面的设备
              case "4":
                  if(!bsCommonDevice.getDeviceType().equals("41") && !bsCommonDevice.getDeviceType().equals("42")&& !bsCommonDevice.getDeviceType().equals("43")
                          && !bsCommonDevice.getDeviceType().equals("44") && !bsCommonDevice.getDeviceType().equals("45")) {
                      throw new CustomException("云悉平台只允许添加云悉依图门禁、云悉依图闸机、云悉海康抓拍机、云悉依图抓拍机、云悉依图摄像头");
                  }
                  break;
          }
        }

        bsCommonDevice.setCreateBy(SecurityUtils.getUsername());
        bsCommonDevice.setCreateTime(DateUtils.getNowDate());
        //默认创建设备为启用
        bsCommonDevice.setStatus("0");
        int flag = bsCommonDeviceMapper.insertBsCommonDevice(bsCommonDevice);
        // 设备设备的了下
        switch (bsCommonDevice.getDeviceType()) {
            case "1":
            case "4":
                // 类型为盒子的时候需要插入盒子下面的节点,云悉的时候也是
                List<BsCommonDevice> childList = commonFaceDeviceService.childDeviceList(bsCommonDevice);
                if(!CollectionUtils.isEmpty(childList)) {
                    childList.stream().forEach(child->{
                        bsCommonDeviceMapper.insertBsCommonDevice(child);
                    });
                }
                break;
            case "2":
            case "3":
                // 新增盒子摄像头2  默认创建的设备id就是 当前系统的设备的id
                bsCommonDevice.setRealId(String.valueOf(bsCommonDevice.getDeviceId()));
                bsCommonDeviceMapper.updateBsCommonDevice(bsCommonDevice);
                commonFaceDeviceService.addDevice(bsCommonDevice);
                break;

        }

        return flag;
    }

    /**
     * 修改通用设备
     *
     * @param bsCommonDevice 通用设备
     * @return 结果
     */
    @Override
    public int updateBsCommonDevice(BsCommonDevice bsCommonDevice)
    {
        int flag = bsCommonDeviceMapper.updateBsCommonDevice(bsCommonDevice);
        bsCommonDevice.setUpdateTime(DateUtils.getNowDate());
        commonFaceDeviceService.updateDevice(bsCommonDevice);
        return flag;
    }

    /**
     * 批量删除通用设备
     *
     * @param deviceIds 需要删除的通用设备ID
     * @return 结果
     */
    @Override
    public int deleteBsCommonDeviceByIds(Integer[] deviceIds)
    {
        // 循环删除
        Set<Long> idSet = new HashSet<>();
        List<TreeSelect> trees = buildDeviceTreeSelect(bsCommonDeviceMapper.selectBsCommonDeviceList(new BsCommonDevice()));
        if(deviceIds!=null && deviceIds.length>0) {
            for (int i = 0; i < deviceIds.length; i++) {
                Long deviceId = deviceIds[i].longValue();
                TreeSelect device = findTreeSelectById(trees,deviceId);
                Long[] ids = getAllChildDeviceIdByTreeSelect(device);
                if(ids.length!=1) {
                    throw new CustomException("该设备存在子设备，无法删除！");
                }
                for (int i1 = 0; i1 < ids.length; i1++) {
                    idSet.add(ids[i1]);
                }

            }
        }
        // 利用set去重
        Long[] resultIds = new Long[idSet.size()];
        idSet.toArray(resultIds);
        // 批量删除设备
        idSet.stream().forEach(
                id->{commonFaceDeviceService.removeDevice(id.intValue());}
        );
        return bsCommonDeviceMapper.deleteBsCommonDeviceByIds(resultIds);
    }

    /**
     * 删除通用设备信息
     *
     * @param deviceId 通用设备ID
     * @return 结果
     */
    @Override
    public int deleteBsCommonDeviceById(Integer deviceId)
    {
        List<TreeSelect> trees = buildDeviceTreeSelect(bsCommonDeviceMapper.selectBsCommonDeviceList(new BsCommonDevice()));
        TreeSelect device = findTreeSelectById(trees,deviceId.longValue());
        Long[] ids = getAllChildDeviceIdByTreeSelect(device);
        // 如果有子节点就不删除
        if(ids.length!=1)
            throw new CustomException("该设备存在子设备，无法删除！");
        commonFaceDeviceService.removeDevice(deviceId);
        int flag = bsCommonDeviceMapper.deleteBsCommonDeviceByIds(ids);

        return flag;
    }

    Long[] getAllChildDeviceIdByTreeSelect(TreeSelect device) {
        List<Long> idList = new ArrayList<>();
        idList.add(device.getId());

        // 设备只能增加到顶级，所以设备最多只有二级
        List<TreeSelect> items = device.getChildren();
        if(!CollectionUtils.isEmpty(items)) {
            items.stream().forEach(item->{
                idList.add(item.getId());
            });
        }

        Long[] ids = new Long[idList.size()];
        idList.toArray(ids);
        return  ids;
    }

    /**
     * 递归查询树状表中的设备位置
     * @param trees
     * @return com.drin.smartpark.project.system.model.TreeSelect
     * @date 2020/11/25 10:21
     */
    private TreeSelect findTreeSelectById(List<TreeSelect> trees,Long deviceId) {
        while(!CollectionUtils.isEmpty(trees)) {
            for (int i = 0; i < trees.size(); i++) {
                if(trees.get(i).getId().equals(deviceId)) {
                    return trees.get(i);
                }
            }

            List<TreeSelect> childrens = new ArrayList<>();
            for (int i = 0; i < trees.size(); i++) {
                if(!CollectionUtils.isEmpty(trees.get(i).getChildren())) {
                    trees.get(i).getChildren().forEach(c->{
                        childrens.add(c);
                    });
                }
            }
            //重置当前寻找的列表
            trees = childrens;
        }
        return null;
    }



    /**
     * 设备构建成树状列表
     *
     * @param deceives
     * @return java.util.List<com.drin.smartpark.project.system.model.TreeSelect>
     * @author HIPAA
     * @date 2020/11/25 10:00
     */
    @Override
    public List<TreeSelect> buildDeviceTreeSelect(List<BsCommonDevice> deceives) {
        List<BsCommonDevice> deptTrees = buildDeviceTree(deceives);
        return deptTrees.stream().map(TreeSelect::new).collect(Collectors.toList());
    }

    /**
     * 根据策略ID获取设备选择框列表
     *
     * @param plicyId 用户ID
     * @return 选中设备ID列表
     */
    @Override
    public List<Long> selectCommonDeviceIdListByPlicyId(Long plicyId) {
        return bsCommonDeviceMapper.selectCommonDeviceIdListByPlicyId(plicyId);
    }

    /**
     * 根据策略ID获取设备选择框列表详细数据
     *
     * @param plicyId 用户ID
     * @return 选中设备实体列表
     */
    @Override
    public List<BsDevice> selectCommonDeviceListByPlicyId(Long plicyId) {
        return bsCommonDeviceMapper.selectCommonDeviceListByPlicyId(plicyId);
    }


    /**
     * 构建前端所需要树结构
     *
     * @param devices 部门列表
     * @return 树结构列表
     */
    public List<BsCommonDevice> buildDeviceTree(List<BsCommonDevice> devices)
    {
        List<BsCommonDevice> returnList = new ArrayList<BsCommonDevice>();
        List<Integer> tempList = new ArrayList<Integer>();
        for (BsCommonDevice device : devices)
        {
            tempList.add(device.getDeviceId());
        }
        for (Iterator<BsCommonDevice> iterator = devices.iterator(); iterator.hasNext();)
        {
            BsCommonDevice device = (BsCommonDevice) iterator.next();
            // 如果是顶级节点, 遍历该父节点的所有子节点
            if (!tempList.contains(device.getParentId()))
            {
                recursionFn(devices, device);
                returnList.add(device);
            }
        }
        if (returnList.isEmpty())
        {
            returnList = devices;
        }
        return returnList;
    }

    /**
     * 递归列表
     */
    private void recursionFn(List<BsCommonDevice> list, BsCommonDevice t)
    {
        // 得到子节点列表
        List<BsCommonDevice> childList = getChildList(list, t);
        t.setChildren(childList);
        for (BsCommonDevice tChild : childList)
        {
            if (hasChild(list, tChild))
            {
                recursionFn(list, tChild);
            }
        }
    }
    /**
     * 得到子节点列表
     */
    private List<BsCommonDevice> getChildList(List<BsCommonDevice> list, BsCommonDevice t)
    {
        List<BsCommonDevice> tlist = new ArrayList<>();
        Iterator<BsCommonDevice> it = list.iterator();
        while (it.hasNext())
        {
            BsCommonDevice n = (BsCommonDevice) it.next();
            if (StringUtils.isNotNull(n.getParentId()) && n.getParentId().longValue() == t.getDeviceId().longValue())
            {
                tlist.add(n);
            }
        }
        return tlist;
    }

    /**
     * 判断是否有子节点
     */
    private boolean hasChild(List<BsCommonDevice> list, BsCommonDevice t)
    {
        return getChildList(list, t).size() > 0 ? true : false;
    }




}