/**
 * 文件名称:          	FaceService
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.drin.smartpark.common.config.VistConfig;
import com.drin.smartpark.common.tool.FileToBase64;
import com.drin.smartpark.common.tool.JsonUtil;
import com.drin.smartpark.project.access.entity.BsDevice;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.access.entity.BsVisitorPost;
import com.drin.smartpark.project.access.mapper.BsVisitorMapper;
import com.drin.smartpark.project.access.mapper.BsVisitorPostMapper;
import com.drin.smartpark.project.access.service.IBsDeviceService;
import com.drin.smartpark.project.api.zdzj.DeviceApi;
import com.drin.smartpark.project.api.zdzj.FaceApi;
import com.drin.smartpark.project.api.zdzj.model.form.AddPersonForm;
import com.drin.smartpark.project.api.zdzj.model.form.DeletePersonForm;
import com.drin.smartpark.project.api.zdzj.model.form.DetectFaceForm;
import com.drin.smartpark.project.api.zdzj.model.form.SearchPersonListForm;
import com.drin.smartpark.project.api.zdzj.model.form.sub.AddPersonFormSub;
import com.drin.smartpark.project.api.zdzj.model.form.sub.SearchPersonListFormSub;
import com.drin.smartpark.project.api.zdzj.model.resp.AddPersonResp;
import com.drin.smartpark.project.api.zdzj.model.resp.DetectFaceResp;
import com.drin.smartpark.project.api.zdzj.model.resp.DeviceResp;
import com.drin.smartpark.project.api.zdzj.model.resp.SearchPersonListResp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

;

/**
 * 闸机人脸操作
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/3 10:17
 */
@Service
public class FaceService {

    @Autowired
    private FaceRetrofitService faceRetrofitService;

    @Autowired
    private BsVisitorPostMapper visitorPostMapper;

    @Autowired
    private BsVisitorMapper visitorMapper;
    
    @Autowired
    private IBsDeviceService deviceService;

    @Autowired
    private IBsDeviceService bsDeviceService;

    /**
     * 创建设备后更新设备id
     * @param device
     * @return java.lang.String
     * @author HIPAA
     * @date 2020/9/9 22:49
     */
    public String getDeviceId(BsDevice device) {
        DeviceApi deviceApi = faceRetrofitService.getApiByIPService(device.getDeviceIp(), DeviceApi.class);
        DeviceResp deviceResp = null;
        try {
            deviceResp = deviceApi.getDeviceInfo().execute().body();
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
        if(deviceResp == null || deviceResp.getInfo()==null || deviceResp.getInfo().getDeviceID()==null)
            return "";
        return String.valueOf(deviceResp.getInfo().getDeviceID());
    }

    /**
     * 给标签id增加人脸
     *
     * @param postId
     * @param device
     * @return void
     * @author HIPAA
     * @date 2020/9/3 10:21
     */
    public void addVisitorFace(Long postId, BsDevice device) throws IOException {
        FaceApi faceApi = faceRetrofitService.getApiByIPService(device.getDeviceIp(), FaceApi.class);
        DeviceApi deviceApi = faceRetrofitService.getApiByIPService(device.getDeviceIp(), DeviceApi.class);
        DeviceResp deviceResp = deviceApi.getDeviceInfo().execute().body();
        device.setDeviceId(deviceResp.getInfo().getDeviceID());
        List<BsVisitor> visitors = getVisitorListByPostId(postId);
        for (int i = 0; i < visitors.size(); i++) {
            BsVisitor visitor = visitors.get(i);
            if (visitor.getImageId() != null) {
                AddPersonForm addPersonForm = personInfo(visitor, device.getDeviceId());
                AddPersonResp addPersonResp = faceApi.addFace(addPersonForm).execute().body();
                System.out.println(JsonUtil.toJsonString(addPersonResp));
            }
        }
    }

    /**
     * 把访客列表加入到多个设备
     *
     * @param visitors
     * @param devices
     * @return void
     * @author HIPAA
     * @date 2020/9/7 10:51
     */
    public void addVisitorListToDevice(List<BsVisitor> visitors, List<BsDevice> devices) {
        if (CollectionUtils.isEmpty(visitors))
            return;
        if (CollectionUtils.isEmpty(devices))
            return;
        devices.stream().forEach(device -> {
            FaceApi faceApi = faceRetrofitService.getApiByIPService(device.getDeviceIp(), FaceApi.class);
//            DeviceApi deviceApi = faceRetrofitService.getApiByIPService(device.getDeviceIp(), DeviceApi.class);
//            DeviceResp deviceResp = null;
//            try {
//                deviceResp = deviceApi.getDeviceInfo().execute().body();
//            } catch (IOException e) {
//                // 增加告警，没导入的数据保存到缓存
//                e.printStackTrace();
//            }
//            device.setDeviceId(device.getDeviceId());
            for (int i = 0; i < visitors.size(); i++) {
                BsVisitor visitor = visitors.get(i);
                if (visitor.getImageId() != null) {
                    AddPersonForm addPersonForm = personInfo(visitor, device.getDeviceId());
                    AddPersonResp addPersonResp = null;
                    try {
                        addPersonResp = faceApi.addFace(addPersonForm).execute().body();
                        System.out.println(addPersonResp);
                    } catch (IOException e) {
                        e.printStackTrace();
                        // 增加告警，没导入的数据保存到缓存
                    }
                }
            }


        });


    }
    
    /**
     * 增加访客信息到所有设备的白名单
     * @param visitor
     * @return void
     * @author HIPAA
     * @date 2020/9/13 3:57
     */
    public void addVisitorToAllDevice(BsVisitor visitor) {
        // 这里查询的设备会返回在线信息的
        List<BsDevice> devices = deviceService.selectBsDeviceList(new BsDevice());
        if (!CollectionUtils.isEmpty(devices)) {
            List<BsDevice> validDeviceList =devices.stream().filter(d->{
                if(d.getRealId()!=null && !"".equals(d.getRealId().trim())) {
                    return true;
                }else {
                    return false;
                }
            }).collect(Collectors.toList());
            //选择在线的设备进行操作
            if(!CollectionUtils.isEmpty(validDeviceList)) {
                validDeviceList.stream().forEach(device -> {
                    FaceApi faceApi = faceRetrofitService.getApiByIPService(device.getDeviceIp(), FaceApi.class);
                    if (visitor.getImageId() != null) {
                        AddPersonForm addPersonForm = personInfo(visitor, Integer.valueOf(device.getRealId()));
                        AddPersonResp addPersonResp = null;
                        try {
                            addPersonResp = faceApi.addFace(addPersonForm).execute().body();
                            System.out.println(addPersonResp);
                        } catch (IOException e) {
                            e.printStackTrace();
                            // 增加告警，没导入的数据保存到缓存
                        }
                    }
                });
               
            }
;        }
    }

    /**
     * 指定设备判断是否有人脸 true 表示图片验证合格，大小要1M以下
     *
     * @param deviceIp
     * @param imgBase64
     * @return boolean
     * @author HIPAA
     * @date 2020/9/7 14:02
     */
    public boolean isFaceExist(String deviceIp, String imgBase64) {
        FaceApi faceApi = faceRetrofitService.getApiByIPService(deviceIp, FaceApi.class);
        DetectFaceResp resp = null;
        try {
            resp = faceApi.detectFace(new DetectFaceForm(imgBase64)).execute().body();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (resp.getInfo().getDetectFace() == 1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 将员工信息批量删除
     *
     * @param visitors
     * @param devices
     * @return void
     * @author HIPAA
     * @date 2020/9/7 11:31
     */
    public void deleteVisitorListFormDevice(List<BsVisitor> visitors, List<BsDevice> devices) {
        if (CollectionUtils.isEmpty(visitors))
            return;
        if (CollectionUtils.isEmpty(devices))
            return;
        devices.stream().forEach(device -> {
            FaceApi faceApi = faceRetrofitService.getApiByIPService(device.getDeviceIp(), FaceApi.class);
            DeviceApi deviceApi = faceRetrofitService.getApiByIPService(device.getDeviceIp(), DeviceApi.class);
            DeviceResp deviceResp = null;
            try {
                deviceResp = deviceApi.getDeviceInfo().execute().body();
            } catch (IOException e) {
                // 增加告警，没导入的数据保存到缓存
                e.printStackTrace();
            }
            Set<Integer> visitorSetIds = visitors.stream().map(t -> {
                return t.getVisitorId().intValue();
            }).collect(Collectors.toSet());
            List<Integer> visitorIds = new ArrayList<>(visitorSetIds);
            DeletePersonForm param = new DeletePersonForm(deviceResp.getInfo().getDeviceID(), visitorIds);
            try {
                faceApi.deleteFace(param).execute();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * 根据访客id 进行删除白名单
     * @param visitorIds
     * @return void
     * @author HIPAA
     * @date 2020/9/14 10:58
     */
    public void deleteVisitorsByIds(List<Integer> visitorIds){
        List<BsDevice> devices = getAllVaildDeviceList();
        if(!CollectionUtils.isEmpty(devices)) {
            devices.stream().forEach(device -> {
                FaceApi faceApi = faceRetrofitService.getApiByIPService(device.getDeviceIp(), FaceApi.class);
                DeletePersonForm param = new DeletePersonForm(Integer.valueOf(device.getRealId()), visitorIds);
                try {
                    faceApi.deleteFace(param).execute();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        }
      
    }

    private List<BsVisitor> getVisitorListByPostId(Long postId) {
        QueryWrapper<BsVisitorPost> wrapper = new QueryWrapper();
        wrapper.eq("post_id", postId);
        List<BsVisitorPost> visitorPosts = visitorPostMapper.selectList(wrapper);
        List<BsVisitor> visitorList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(visitorPosts)) {
            visitorPosts.stream().forEach(vp -> {
                Long visitorId = vp.getVisitorId();
                BsVisitor visitor = visitorMapper.selectBsVisitorById(visitorId);
                visitorList.add(visitor);
            });
        }
        return visitorList;
    }

    private String getImageBase64ByImageId(String id) {
        String imageId = id.replaceAll("/profile", "");
        String imagePath = VistConfig.getProfile() +"/"+ imageId;
        String imgBase64 = FileToBase64.encodeBase64File(imagePath);
        return imgBase64;
    }

    private AddPersonForm personInfo(BsVisitor visitor, Integer deviceId) {
        AddPersonForm addPersonForm = new AddPersonForm();
        addPersonForm.setOperator("AddPerson");
        String imgBase64 = getImageBase64ByImageId(visitor.getImageId());
        addPersonForm.setPicinfo(imgBase64);
        AddPersonFormSub addPersonFormSub = new AddPersonFormSub();
        addPersonFormSub.setDeviceID(deviceId.intValue());
        addPersonFormSub.setPersonType(Integer.valueOf(visitor.getStatus()));
        addPersonFormSub.setName(visitor.getVisitorName());
        addPersonFormSub.setGender(AddPersonFormSub.MAN);
        addPersonFormSub.setNation(1);
        addPersonFormSub.setCardType(AddPersonFormSub.ID_CARD_TYPE);
        addPersonFormSub.setIdCard(visitor.getVisitorCard());
        addPersonFormSub.setBirthday("");
        addPersonFormSub.setTelnum("");
        addPersonFormSub.setNative("");
        addPersonFormSub.setAddress("");
        addPersonFormSub.setNotes("");
        addPersonFormSub.setCustomizeID(visitor.getVisitorId().intValue());
        addPersonForm.setInfo(addPersonFormSub);
        return addPersonForm;
    }

    /*
     * @Author Kano
     * @Description //TODO 查询多个名单
     * @Date 2020/9/8
     * @Param []
     * @return com.drin.smartpark.project.api.zd.model.resp.SearchPersonListResp
     **/
    public SearchPersonListResp searchPersonList()  {
        SearchPersonListForm form = new SearchPersonListForm();
        SearchPersonListFormSub sub = new SearchPersonListFormSub();
//        sub.setDeviceID(getDeviceID());
        form.setInfo(sub);
        List<BsDevice> device = bsDeviceService.selectBsDeviceList(new BsDevice());
        FaceApi faceApi = faceRetrofitService.getApiByIPService(device.get(0).getDeviceIp(), FaceApi.class);
        SearchPersonListResp body = null;
        try {
            body = faceApi.searchPersonList(form).execute().body();
        } catch (IOException e) {
            System.out.println("-----error----------------");
            e.printStackTrace();
        }
        return body;

    }
    
    private List<BsDevice> getAllVaildDeviceList() {
        List<BsDevice> devices = deviceService.selectBsDeviceList(new BsDevice());
        if (!CollectionUtils.isEmpty(devices)) {
            List<BsDevice> validDeviceList =devices.stream().filter(d->{
                if(d.getRealId()!=null && !"".equals(d.getRealId().trim())) {
                    return true;
                }else {
                    return false;
                }
            }).collect(Collectors.toList());
            return validDeviceList;
        }
        return null;
    }


}
