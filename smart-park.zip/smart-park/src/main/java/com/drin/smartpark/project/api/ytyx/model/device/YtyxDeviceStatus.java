/**
 * 文件名称:          	YtyxDeviceStatus
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.device;

import lombok.Data;

/**
 * 设备状态
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/4 10:16
 */
@Data
public class YtyxDeviceStatus {

    private Long  device_add_time;
    private Long  last_capture_timestamp;
    private Long last_heart_beat_timestamp;
    //enum (WAITING, RUNNING, DELETING, ERROR, ACTIVE_DELETING)
    private String status;
    //enum (OK, STARTING, DISCONNECT, DELETING, PASSWORD_ERROR, DEVICE_TYPE_UNMATCHED, UNEXPECTED_ERROR,
    // BAD_REQUEST, DEVICE_INTERNAL_ERROR, UNKNOWN_HOST, UPGRADING, DEVICE_TYPE_NOT_SUPPORT, ACTIVE_DELETING,
    // DEVICE_VERSION_UNMATCHED, CONNECTED_FAILED)
    private String status_description;
    private String status_detail;
}
