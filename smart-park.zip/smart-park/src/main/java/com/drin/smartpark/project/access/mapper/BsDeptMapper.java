package com.drin.smartpark.project.access.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.access.entity.BsDept;

import java.util.List;

/**
 * 门禁系统部门管理Mapper接口
 *
 * @author ruoyi
 * @date 2020-09-03
 */
public interface BsDeptMapper  extends BaseMapper<BsDept>
{
    /**
     * 查询门禁系统部门管理
     *
     * @param deptId 门禁系统部门管理ID
     * @return 门禁系统部门管理
     */
    public BsDept selectBsDeptById(Long deptId);

    /**
     * 查询门禁系统部门管理列表
     *
     * @param bsDept 门禁系统部门管理
     * @return 门禁系统部门管理集合
     */
    public List<BsDept> selectBsDeptList(BsDept bsDept);

    /**
     * 新增门禁系统部门管理
     *
     * @param bsDept 门禁系统部门管理
     * @return 结果
     */
    public int insertBsDept(BsDept bsDept);

    /**
     * 修改门禁系统部门管理
     *
     * @param bsDept 门禁系统部门管理
     * @return 结果
     */
    public int updateBsDept(BsDept bsDept);

    /**
     * 删除门禁系统部门管理
     *
     * @param deptId 门禁系统部门管理ID
     * @return 结果
     */
    public int deleteBsDeptById(Long deptId);

    /**
     * 批量删除门禁系统部门管理
     *
     * @param deptIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsDeptByIds(Long[] deptIds);
}