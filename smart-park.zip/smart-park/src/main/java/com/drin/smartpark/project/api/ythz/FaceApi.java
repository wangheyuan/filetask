/**
 * 文件名称:          	FaceApi
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz;

import com.drin.smartpark.project.api.ythz.dto.face.FaceSearchItemDto;
import com.drin.smartpark.project.api.ythz.form.FaceInsertForm;
import com.drin.smartpark.project.api.ythz.form.FaceSearchForm;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.List;

/**
 * 人脸相关的api
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 10:43
 */
public interface FaceApi {

    /**
     * 模糊搜索人脸库人脸
     * @param param
     * @return retrofit2.Call<java.util.List<com.drin.shom.api.dto.face.FaceSearchItemDto>>
     * @author HIPAA
     * @date 2020/7/29 10:57
     */
    @GET("face/v1.1/repositories/{repository_id}/faces")
    Call<List<FaceSearchItemDto>> faceList(@Path("repository_id") String repositoryId, @Body FaceSearchForm param);

    /**
     * 删除人像
     * @param repositoryId
     * @param faceId
     * @return retrofit2.Call<java.lang.String>
     * @author HIPAA
     * @date 2020/7/29 11:01
     */
    @DELETE("face/v1/repositories/{repository_id}/faces/{face_id}")
    Call<String> removeFace(@Path("repository_id") String repositoryId,@Path("face_id") String faceId);

    /**
     *  新增人像
     * @param repositoryId
     * @param faceId
     * @param param
     * @return retrofit2.Call<java.lang.String>
     * @author HIPAA
     * @date 2020/7/29 11:12
     */
    @Headers("Content-Type:application/json")
    @POST("face/v1/repositories/{repository_id}/faces/{face_id}")
    Call<String> addFace(@Path("repository_id") String repositoryId, @Path("face_id") String faceId, @Body FaceInsertForm param);


    /**
     * 通过人脸id进行下载
     * @param imageId
     * @return retrofit2.Call<okhttp3.ResponseBody>
     * @author HIPAA
     * @date 2020/7/31 13:12
     */
    @Streaming
    @GET("face/v1/images/{imageId}")
    Call<ResponseBody> downloadPicWithUrl(@Path("imageId") String imageId);

}
