package com.drin.smartpark.project.access.controller;

import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.framework.page.TableDataInfo;
import com.drin.smartpark.project.access.entity.BsStranger;
import com.drin.smartpark.project.access.service.IBsStrangerService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 陌生人列表Controller
 *
 * @author wangheyuan
 * @date 2020-09-09
 */
@RestController
@RequestMapping("/access/stranger")
public class BsStrangerController extends BaseController
{
    @Autowired
    private IBsStrangerService bsStrangerService;

    /**
     * 查询陌生人列表列表
     */
    @RequiresPermissions("access:stranger:list")
    @GetMapping("/list")
    public TableDataInfo list(BsStranger bsStranger)
    {
        startPage();
        List<BsStranger> list = bsStrangerService.selectBsStrangerList(bsStranger);
        return getDataTable(list);
    }

    /**
     * 导出陌生人列表列表
     */
    @RequiresPermissions("access:stranger:export")
    @Log(title = "陌生人列表", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsStranger bsStranger)
    {
        List<BsStranger> list = bsStrangerService.selectBsStrangerList(bsStranger);
        ExcelUtil<BsStranger> util = new ExcelUtil<BsStranger>(BsStranger.class);
        return util.exportExcel(list, "stranger");
    }

    /**
     * 获取陌生人列表详细信息
     */
    @RequiresPermissions("access:stranger:query")
    @GetMapping(value = "/{strangerId}")
    public RestResp getInfo(@PathVariable("strangerId") Long strangerId)
    {
        return RestResp.success(bsStrangerService.selectBsStrangerById(strangerId));
    }

    /**
     * 新增陌生人列表
     */
    @RequiresPermissions("access:stranger:add")
    @Log(title = "陌生人列表", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsStranger bsStranger)
    {
        return toAjax(bsStrangerService.insertBsStranger(bsStranger));
    }

    /**
     * 修改陌生人列表
     */
    @RequiresPermissions("access:stranger:edit")
    @Log(title = "陌生人列表", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsStranger bsStranger)
    {
        return toAjax(bsStrangerService.updateBsStranger(bsStranger));
    }

    @RequiresPermissions("access:stranger:edit")
    @Log(title = "陌生人通过", businessType = BusinessType.UPDATE)
    @GetMapping(value = "/pass/{strangerId}")
    public RestResp pass(@PathVariable("strangerId") Long strangerId)
    {
        bsStrangerService.passStranger(strangerId);
        return RestResp.success();
    }


    /**
     * 删除陌生人列表
     */
    @RequiresPermissions("access:stranger:remove")
    @Log(title = "陌生人列表", businessType = BusinessType.DELETE)
    @DeleteMapping("/{strangerIds}")
    public RestResp remove(@PathVariable Long[] strangerIds)
    {
        return toAjax(bsStrangerService.deleteBsStrangerByIds(strangerIds));
    }
}