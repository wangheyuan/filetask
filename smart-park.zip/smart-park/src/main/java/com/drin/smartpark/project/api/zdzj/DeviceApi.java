/**
 * 文件名称:          	DeviceApi
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj;

import com.drin.smartpark.project.api.zdzj.model.resp.DeviceResp;
import retrofit2.Call;
import retrofit2.http.POST;

/**
 * 访问设备信息
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/3 9:28
 */
public interface DeviceApi {

    //获取设备信息
    @POST("action/GetSysParam")
    Call<DeviceResp> getDeviceInfo();

    // 设置开门条件参数
    @POST("action/SetDoorCondition")
    Call<Object> setDoorCondition();

}