package com.drin.smartpark.project.check.service;

import java.time.LocalTime;
import java.util.List;

import com.drin.smartpark.project.check.dto.GroupCheckDay;
import com.drin.smartpark.project.check.entity.BsCheckPlicy;
import com.drin.smartpark.project.check.entity.BsStaffCaptureDay;

/**
 * 每日考勤Service接口
 *
 * @author wangheyuan
 * @date 2020-11-27
 */
public interface IBsStaffCaptureDayService
{
    /**
     * 查询每日考勤
     *
     * @param historyDayId 每日考勤ID
     * @return 每日考勤
     */
    public BsStaffCaptureDay selectBsStaffCaptureDayById(Long historyDayId);

    /**
     * 查询每日考勤列表
     *
     * @param bsStaffCaptureDay 每日考勤
     * @return 每日考勤集合
     */
    public List<BsStaffCaptureDay> selectBsStaffCaptureDayList(BsStaffCaptureDay bsStaffCaptureDay);

    /**
     * 查询每日考勤分组列表
     *
     * @param bsStaffCaptureDay 每日考勤
     * @return 每日考勤集合
     */
    public List<GroupCheckDay> selectBsStaffCaptureDayGroupList(BsStaffCaptureDay bsStaffCaptureDay);

    /**
     * 新增每日考勤
     *
     * @param bsStaffCaptureDay 每日考勤
     * @return 结果
     */
    public int insertBsStaffCaptureDay(BsStaffCaptureDay bsStaffCaptureDay);

    /**
     * 修改每日考勤
     *
     * @param bsStaffCaptureDay 每日考勤
     * @return 结果
     */
    public int updateBsStaffCaptureDay(BsStaffCaptureDay bsStaffCaptureDay);

    /**
     * 批量删除每日考勤
     *
     * @param historyDayIds 需要删除的每日考勤ID
     * @return 结果
     */
    public int deleteBsStaffCaptureDayByIds(Long[] historyDayIds);

    /**
     * 删除每日考勤信息
     *
     * @param historyDayId 每日考勤ID
     * @return 结果
     */
    public int deleteBsStaffCaptureDayById(Long historyDayId);

    /**
     * 更新 每日考勤的进入时间
     * @return void
     * @author HIPAA
     * @date 2020/12/7 11:14
     */
    public void setBsStaffCaptureDayNowInTime(Long staffId, BsCheckPlicy plicy);

    /**
     * 更新 每日考勤的外出时间
     * @return void
     * @author HIPAA
     * @date 2020/12/7 11:14
     */
    public void setBsStaffCaptureDayNowOutTime(Long staffId, BsCheckPlicy plicy);

}