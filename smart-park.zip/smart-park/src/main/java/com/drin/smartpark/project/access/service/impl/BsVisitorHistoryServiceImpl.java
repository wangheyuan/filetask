package com.drin.smartpark.project.access.service.impl;

import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.access.entity.BsVisitorHistory;
import com.drin.smartpark.project.access.mapper.BsVisitorHistoryMapper;
import com.drin.smartpark.project.access.service.IBsVisitorHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * 访客历史列表Service业务层处理
 *
 * @author ruoyi
 * @date 2020-09-07
 */
@Service
public class BsVisitorHistoryServiceImpl implements IBsVisitorHistoryService
{
    @Autowired
    private BsVisitorHistoryMapper bsVisitorHistoryMapper;

    /**
     * 查询访客历史列表
     *
     * @param visitorId 访客历史列表ID
     * @return 访客历史列表
     */
    @Override
    public BsVisitorHistory selectBsVisitorHistoryById(Long visitorId)
    {
        return bsVisitorHistoryMapper.selectBsVisitorHistoryById(visitorId);
    }

    /**
     * 根据访客信息创建历史
     *
     * @param visitor
     * @return void
     * @author HIPAA
     * @date 2020/9/14 10:13
     */
    @Override
    public void insertVisitorHistoryByBsVisitor(BsVisitor visitor,String deviceName) {
        BsVisitorHistory history = new BsVisitorHistory();
        history.setImageId(visitor.getImageId());
        history.setStatus("0");
        history.setVisitorCard(visitor.getVisitorCard());
        history.setInTime(new Date());
        history.setVisitorName(visitor.getVisitorName());
        history.setRemark(deviceName);
        bsVisitorHistoryMapper.insert(history);
    }

    /**
     * 查询访客历史列表列表
     *
     * @param bsVisitorHistory 访客历史列表
     * @return 访客历史列表
     */
    @Override
    public List<BsVisitorHistory> selectBsVisitorHistoryList(BsVisitorHistory bsVisitorHistory)
    {
        return bsVisitorHistoryMapper.selectBsVisitorHistoryList(bsVisitorHistory);
    }

    /**
     * 新增访客历史列表
     *
     * @param bsVisitorHistory 访客历史列表
     * @return 结果
     */
    @Override
    public int insertBsVisitorHistory(BsVisitorHistory bsVisitorHistory)
    {
        bsVisitorHistory.setCreateTime(DateUtils.getNowDate());
        return bsVisitorHistoryMapper.insertBsVisitorHistory(bsVisitorHistory);
    }

    /**
     * 修改访客历史列表
     *
     * @param bsVisitorHistory 访客历史列表
     * @return 结果
     */
    @Override
    public int updateBsVisitorHistory(BsVisitorHistory bsVisitorHistory)
    {
        bsVisitorHistory.setUpdateTime(DateUtils.getNowDate());
        return bsVisitorHistoryMapper.updateBsVisitorHistory(bsVisitorHistory);
    }

    /**
     * 批量删除访客历史列表
     *
     * @param visitorIds 需要删除的访客历史列表ID
     * @return 结果
     */
    @Override
    public int deleteBsVisitorHistoryByIds(Long[] visitorIds)
    {
        return bsVisitorHistoryMapper.deleteBsVisitorHistoryByIds(visitorIds);
    }

    /**
     * 删除访客历史列表信息
     *
     * @param visitorId 访客历史列表ID
     * @return 结果
     */
    @Override
    public int deleteBsVisitorHistoryById(Long visitorId)
    {
        return bsVisitorHistoryMapper.deleteBsVisitorHistoryById(visitorId);
    }
}