/**
 * 文件名称:          	DetectFaceSubResp
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj.model.resp.sub;

import lombok.Data;

/**
 * 返回人脸的检测信息
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/7 13:48
 */
@Data
public class DetectFaceSubResp {
    // 返回人脸条数
    private Integer DetectFace ;
}
