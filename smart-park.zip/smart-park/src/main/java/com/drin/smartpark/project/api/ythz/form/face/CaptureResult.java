/**
 * 文件名称:          	CaptureResult
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.face;

import lombok.Data;

/**
 * 抓拍对象
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 14:36
 */
@Data
public class CaptureResult {
    private String channel_name;
    private String extra_meta;
    private String face_image_url;
    private FacePosition face_position;
    private String scene_image_url;
    private String vision_attributes;
    private HitPerson hit_person;
    private Integer id;
}
