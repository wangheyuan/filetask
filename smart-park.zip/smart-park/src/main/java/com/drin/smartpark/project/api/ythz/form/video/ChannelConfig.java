/**
 * 文件名称:          	ChannelConfig
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.video;

import lombok.Data;

import java.util.List;

/**
 * 摄像头配置
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 16:55
 */
@Data
public class ChannelConfig {
    List<VideoChannel> video_channels;
}
