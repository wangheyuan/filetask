/**
 * 文件名称:          	YtyxRetrofitService
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.service;

/**
 * 处理依图云悉盒子的请求
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/4 11:34
 */

import com.drin.smartpark.project.api.ythz.service.SyncEhcacheService;
import com.drin.smartpark.project.api.zdzj.net.SSLTool;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.mapper.BsCommonDeviceMapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import javax.net.ssl.*;
import java.io.IOException;
import java.security.KeyStore;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
public class YtyxRetrofitService {

    @Value("${httpLogFlag}")
    private Boolean httpLogFlag;

    @Autowired
    private SyncEhcacheService ehcacheService;

    @Autowired
    private BsCommonDeviceMapper commonDeviceMapper;

    private Map<String,OkHttpClient> httpClientMap = new HashMap<>();

    private Map<String,Retrofit> retrofitMap = new HashMap<>();

    private Map<String,Retrofit> tempRetrofitMap = new HashMap<>();

    @SneakyThrows
    private Retrofit retrofitByCommonDevice(BsCommonDevice device) {
        TrustManagerFactory trustManagerFactory = null;
        trustManagerFactory = TrustManagerFactory.getInstance(
                TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init((KeyStore) null);
        TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
        if (trustManagers.length != 1 || !(trustManagers[0] instanceof X509TrustManager)) {
            throw new IllegalStateException("Unexpected default trust managers:"
                    + Arrays.toString(trustManagers));
        }
        X509TrustManager trustManager = (X509TrustManager) trustManagers[0];
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{trustManager}, null);
        SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

        HttpLoggingInterceptor logInterceptor = new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
            @Override
            public void log(String message) {
                if(httpLogFlag && !message.contains("----------------------")) {
                    log.info("第三方请求：{}",message);
                }
            }
        });
        logInterceptor.setLevel( HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client=  new OkHttpClient.Builder().connectTimeout(5L, TimeUnit.SECONDS)
                .sslSocketFactory(sslSocketFactory, trustManager)
//                .sslSocketFactory(SSLTool.createSSLSocketFactory())
                .hostnameVerifier(new SSLTool.TrustAllHostnameVerifier())
                .addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request originalRequest = chain.request();
                        String url = originalRequest.url().toString();
                        Request.Builder requestBuilder = originalRequest
                                .newBuilder();
                        if(!url.contains("token") && device.getAccount()!=null && device.getPassword()!=null) {
                            String token = "";
                            requestBuilder.header("token",token);
                        }
                        Request original = chain.request();
                        Request request = requestBuilder.header("Content-Type","application/json")
                                .header("Accept","application/json")
                                .method(original.method(), original.body()).build();
                        return chain.proceed(request);
                    }
                })
                .addInterceptor(logInterceptor)
                .build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(device.getDeviceIp())
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        return retrofit;
    }


}
