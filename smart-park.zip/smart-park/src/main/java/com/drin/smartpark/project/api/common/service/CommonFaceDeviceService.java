/**
 * 文件名称:          	CommonFaceService
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.common.service;

import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.entity.BsStaff;
import com.drin.smartpark.project.check.entity.BsStaffCaptureHistory;

import java.util.List;
import java.util.Map;

/**
 * 通用人脸设备远端操作接口
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/11/24 10:23
 */
public interface CommonFaceDeviceService {

    /**
     * 增加员工到设备
     * @param device
     * @param staff
     * @date 2020/11/24 10:39
     */
    void addStaffToDevice(BsCommonDevice device, BsStaff staff) ;

    /**
     * 增加员工到所有设备
     * @param staff
     * @date 2020/11/24 10:39
     */
    void addStaffToAllDevice(BsStaff staff);

    /**
     * 移除员工到设备
     * @param device
     * @param staffId
     * @date 2020/11/24 10:39
     */
    void removeStaffFromDevice(BsCommonDevice device,String staffId);

    /**
     * 从设备移除员工
     * @param staffId
     * @date 2020/11/24 10:39
     */
    void removeStaffFromAllDevice(String staffId);

    /**
     * 增加访客到设备
     * @param device
     * @param visitor
     * @date 2020/11/24 10:39
     */
    void addVisitorToDevice(BsCommonDevice device, BsVisitor visitor) ;

    /**
     * 增加访客到所有设备
     * @param visitor
     * @date 2020/11/24 10:39
     */
    void addVisitorToAllDevice(BsVisitor visitor) ;

    /**
     * 增加访客到所有设备
     * @param visitor
     * @date 2020/11/24 10:39
     */
    void removeVisitorFromDevice(BsCommonDevice device,BsVisitor visitor);


    /**
     * 从设备移除所有的访客
     * @param visitor
     * @date 2020/11/24 10:39
     */
    void removeVisitorFromAllDevice(BsVisitor visitor);

    /**
     * 增加设备
     * @param device
     * @date 2020/11/24 10:45
     */
    void addDevice(BsCommonDevice device);

    /**
     * 更新设备
     * @param device
     * @return void
     * @author HIPAA
     * @date 2021/1/7 11:18
     */
    void updateDevice(BsCommonDevice device);

    /**
     * 移除设备
     * @param deviceId
     * @date 2020/11/24 10:45
     */
    void removeDevice(Integer deviceId);

    /**
     * 返回设备所有的人员信息
     * @param device
     * @date 2020/11/24 10:45
     */
    List<BsStaffCaptureHistory> listStaffCaptureHistoryFromDevice(BsCommonDevice device);


    /**
     * 返回所有的人员信息
     * @date 2020/11/24 10:45
     */
    List<BsStaffCaptureHistory> listStaffCaptureHistoryFromAllDevice();


    /**
     * 根据人员id 返回人员信息
     * @param device
     * @date 2020/11/24 10:45
     */
    Map<String,Object> personFromDeviceById(BsCommonDevice device,String personId);


    /**
     * 返回设备中的人员信息
     * @date 2020/11/24 10:45
     */
    Map<String,Object> personFromAllDeviceById(String personId);

    /**
     * 通过设备获取子设备
     * @param parentDevice
     * @date 2020/11/24 15:07
     */
    public List<BsCommonDevice> childDeviceList(BsCommonDevice parentDevice);
    
    

}