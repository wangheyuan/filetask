/**
 * 文件名称:          	UserLogin
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.login;

import lombok.Data;

/**
 * 登录
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/17 12:00
 */
@Data
public class YtyxUserLoginForm {

    private String username;
    private String password;
}
