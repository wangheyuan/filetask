package com.drin.smartpark.project.access.entity;

import com.drin.smartpark.common.BaseEntity;
import com.drin.smartpark.framework.excel.annotation.Excel;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.ArrayList;
import java.util.List;

/**
 * 门禁系统部门管理对象 bs_dept
 *
 * @author ruoyi
 * @date 2020-09-03
 */
public class BsDept extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 部门id */
    private Long deptId;

    /** 祖级列表 */
    private String ancestors;

    /** 父部门ID */
    private Long parentId;

    /** 显示顺序 */
    private String orderNum;

    /** 子部门 */
    private List<BsDept> children = new ArrayList<BsDept>();

    /** 部门名称 */
    @Excel(name = "部门名称")
    private String deptName;

    public void setDeptId(Long deptId)
    {
        this.deptId = deptId;
    }

    public Long getDeptId()
    {
        return deptId;
    }
    public void setDeptName(String deptName)
    {
        this.deptName = deptName;
    }

    public String getDeptName()
    {
        return deptName;
    }

    public String getAncestors() {
        return ancestors;
    }

    public void setAncestors(String ancestors) {
        this.ancestors = ancestors;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public List<BsDept> getChildren() {
        return children;
    }

    public void setChildren(List<BsDept> children) {
        this.children = children;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("deptId", getDeptId())
                .append("deptName", getDeptName())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}