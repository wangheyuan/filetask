/**
 * 文件名称:          	FaceInsertForm
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form;

import com.drin.smartpark.project.api.ythz.dto.face.FaceImageDto;
import lombok.Data;

/**
 * 新增人像的form
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 11:09
 */
@Data
public class FaceInsertForm {
    private String extra_meta;
    // {"name":"test","gender":"male","id":"32","address":"23","photoImg":""}
    private FaceImageDto face_image;
}
