package com.drin.smartpark.project.check.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.project.check.entity.BsStaffCaptureMonth;
import com.drin.smartpark.project.check.service.IBsStaffCaptureMonthService;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.page.TableDataInfo;

/**
 * 员工每月考勤Controller
 *
 * @author wangheyuan
 * @date 2020-11-27
 */
@RestController
@RequestMapping("/check/checkMonth")
public class BsStaffCaptureMonthController extends BaseController
{
    @Autowired
    private IBsStaffCaptureMonthService bsStaffCaptureMonthService;

    /**
     * 查询员工每月考勤列表
     */
    @RequiresPermissions("check:checkMonth:list")
    @GetMapping("/list")
    public TableDataInfo list(BsStaffCaptureMonth bsStaffCaptureMonth)
    {
        startPage();
        List<BsStaffCaptureMonth> list = bsStaffCaptureMonthService.selectBsStaffCaptureMonthList(bsStaffCaptureMonth);
        return getDataTable(list);
    }

    /**
     * 导出员工每月考勤列表
     */
    @RequiresPermissions("check:checkMonth:export")
    @Log(title = "员工每月考勤", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsStaffCaptureMonth bsStaffCaptureMonth)
    {
        List<BsStaffCaptureMonth> list = bsStaffCaptureMonthService.selectBsStaffCaptureMonthList(bsStaffCaptureMonth);
        ExcelUtil<BsStaffCaptureMonth> util = new ExcelUtil<BsStaffCaptureMonth>(BsStaffCaptureMonth.class);
        return util.exportExcel(list, "checkMonth");
    }

    /**
     * 获取员工每月考勤详细信息
     */
    @RequiresPermissions("check:checkMonth:query")
    @GetMapping(value = "/{historyMonthId}")
    public RestResp getInfo(@PathVariable("historyMonthId") Long historyMonthId)
    {
        return RestResp.success(bsStaffCaptureMonthService.selectBsStaffCaptureMonthById(historyMonthId));
    }

    /**
     * 新增员工每月考勤
     */
    @RequiresPermissions("check:checkMonth:add")
    @Log(title = "员工每月考勤", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsStaffCaptureMonth bsStaffCaptureMonth)
    {
        return toAjax(bsStaffCaptureMonthService.insertBsStaffCaptureMonth(bsStaffCaptureMonth));
    }

    /**
     * 修改员工每月考勤
     */
    @RequiresPermissions("check:checkMonth:edit")
    @Log(title = "员工每月考勤", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsStaffCaptureMonth bsStaffCaptureMonth)
    {
        return toAjax(bsStaffCaptureMonthService.updateBsStaffCaptureMonth(bsStaffCaptureMonth));
    }

    /**
     * 删除员工每月考勤
     */
    @RequiresPermissions("check:checkMonth:remove")
    @Log(title = "员工每月考勤", businessType = BusinessType.DELETE)
    @DeleteMapping("/{historyMonthIds}")
    public RestResp remove(@PathVariable Long[] historyMonthIds)
    {
        return toAjax(bsStaffCaptureMonthService.deleteBsStaffCaptureMonthByIds(historyMonthIds));
    }
}