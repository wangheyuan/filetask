package com.drin.smartpark.project.api.zdzj.model.resp.sub;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @作者: Kano
 * @时间:2020/9/9 14:28
 * @描述: 陌生人抓拍上报info
 */
@Data
public class SubscribeSnapSubResp {
    //设备ID
    @JsonProperty("DeviceID")
    private Integer DeviceID;
    //当前设备时间
    @JsonProperty("CreateTime")
    private LocalDateTime CreateTime;
    //抓拍人脸图片类型   0比对失败  1比对成功黑名单  2比对成功白名单    3身份证+人脸比对失败  4身份证+人脸比对成功
    @JsonProperty("PictureType")
    private Integer PictureType;
    //实时监测人脸温度
    @JsonProperty("Temperature")
    private Double Temperature;
    //实时监测人脸温度是否超过阈值 0没超过 1超过
    @JsonProperty("TemperatureAlarm")
    private Integer TemperatureAlarm;
    //人脸抓拍的通道号
    @JsonProperty("SnapChannel")
    private Integer SnapChannel;
    //是否及时推送信息   0未及时   1及时推送
    @JsonProperty("Sendintime")
    private Integer Sendintime;
}
