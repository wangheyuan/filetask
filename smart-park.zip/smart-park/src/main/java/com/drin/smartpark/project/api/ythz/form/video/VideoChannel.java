/**
 * 文件名称:          	VideoChannel
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.video;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 视频通道
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 15:17
 */
@Data
public class VideoChannel {


    private String channel_id;
    private String channel_name;
    private String channel_url;
    //FaceRetrieval
    private String channel_type;
    private String status;
    private Integer targetRepositoryNum;
    private int Number=1  ;

    private String channel_protocol;
    private String channel_format;

    private String vendor;

    ChannelResolution channel_resolution;

    Map<String,Object> capture_area;

    private List<String> target_repo = new ArrayList<>();

    String extra_meta;

}
