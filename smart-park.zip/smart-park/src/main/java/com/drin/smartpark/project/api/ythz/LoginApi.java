/**
 * 文件名称:          	Login
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz;

import com.drin.smartpark.project.api.ythz.dto.LoginRespDto;
import com.drin.smartpark.project.api.ythz.form.HzLoginForm;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * 登录的接口
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/24 16:34
 */
public interface LoginApi {

   @POST("authentication/v1/token")
   Call<LoginRespDto> login(@Body HzLoginForm param);

}