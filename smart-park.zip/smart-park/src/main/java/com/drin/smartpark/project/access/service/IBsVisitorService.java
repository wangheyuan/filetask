package com.drin.smartpark.project.access.service;

import com.drin.smartpark.project.access.entity.BsVisitor;

import java.util.List;

/**
 * 访客信息管理Service接口
 *
 * @author wangheyuan
 * @date 2020-09-02
 */
public interface IBsVisitorService
{
    /**
     * 查询访客信息管理
     *
     * @param visitorId 访客信息管理ID
     * @return 访客信息管理
     */
    public BsVisitor selectBsVisitorById(Long visitorId);

    /**
     * 查询访客信息管理列表
     *
     * @param bsVisitor 访客信息管理
     * @return 访客信息管理集合
     */
    public List<BsVisitor> selectBsVisitorList(BsVisitor bsVisitor);

    /**
     * 新增访客信息管理
     *
     * @param bsVisitor 访客信息管理
     * @return 结果
     */
    public int insertBsVisitor(BsVisitor bsVisitor);

    /**
     * 修改访客信息管理
     *
     * @param bsVisitor 访客信息管理
     * @return 结果
     */
    public int updateBsVisitor(BsVisitor bsVisitor);

    /**
     * 批量删除访客信息管理
     *
     * @param visitorIds 需要删除的访客信息管理ID
     * @return 结果
     */
    public int deleteBsVisitorByIds(Long[] visitorIds);

    /**
     * 删除访客信息管理信息
     *
     * @param visitorId 访客信息管理ID
     * @return 结果
     */
    public int deleteBsVisitorById(Long visitorId);

    /**
     * 根据标签查询访客列表
     * @param postIds
     * @return java.util.List<com.drin.smartpark.project.access.entity.BsVisitor>
     * @author HIPAA
     * @date 2020/9/7 9:44
     */
    public List<BsVisitor> selectBsVisitorListByPostIds(List<Long> postIds);

    /**
     * 通过策略id查询访客列表
     * @param plicyId
     * @return java.util.List<com.drin.smartpark.project.access.entity.BsVisitor>
     * @author HIPAA
     * @date 2020/9/8 10:38
     */
    public List<BsVisitor> selectBsVisitorListByPlicyId(Long plicyId);

    /**
     * 查询当前所有应该通过的访客信息
     * @param
     * @return java.util.List<com.drin.smartpark.project.access.entity.BsVisitor>
     * @author HIPAA
     * @date 2020/9/8 11:46
     */
    public List<BsVisitor> selectAllValidVisitorList();
}