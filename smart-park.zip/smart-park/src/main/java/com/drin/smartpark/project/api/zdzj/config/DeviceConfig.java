/**
 * 文件名称:          	DeviceConfig
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj.config;

import lombok.Getter;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 设备的配置
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/31 11:08
 */
@Configuration
public class DeviceConfig {

    @Getter
    private final List<Map<String, String>> accountList = new ArrayList<>();

    @PostConstruct
    public void initDevice() {
        Map<String,String> device = new HashMap<>();
        device.put("ip","172.16.25.60");
        device.put("username","admin");
        device.put("password","admin");
    }



}
