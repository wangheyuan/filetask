/**
 * 文件名称:          	YtyxDevice
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.device;

import lombok.Data;

/**
 * 依图云悉的设备实体
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/4 10:15
 */
@Data
public class YtyxDevice {

    // 设备id
    private String device_id;

    // ACTIVE代表主动，PASSIVE代表被动
    private String connection_type;

    private String dept_id;

    //设备元信息
    private YtyxDeviceMeta device_meta;

    // 设备状态
    private YtyxDeviceStatus device_status;
}
