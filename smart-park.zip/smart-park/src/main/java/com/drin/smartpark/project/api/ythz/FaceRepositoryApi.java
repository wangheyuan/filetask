/**
 * 文件名称:          	FaceRepository
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz;

import com.drin.smartpark.project.api.ythz.dto.RepositoryDetailDto;
import com.drin.smartpark.project.api.ythz.dto.RepositoryListDto;
import com.drin.smartpark.project.api.ythz.form.EditRepositoryForm;
import retrofit2.Call;
import retrofit2.http.*;

/**
 * 调用人脸库Api
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 9:49
 */
public interface FaceRepositoryApi {

    /**
     *  获取人脸库列表
     * @param 
     * @return retrofit2.Call<com.drin.shom.api.dto.RepositoryListDto>
     * @author HIPAA
     * @date 2020/7/29 10:13
     */
    @GET("face/v1/repositories")
    Call<RepositoryListDto> repositoryList();

    /**
     * 移除人脸库
     * @param id
     * @return retrofit2.Call<java.lang.String>
     * @author HIPAA
     * @date 2020/7/29 10:15
     */
    @DELETE("face/v1/repositories/{id}")
    Call<String> removeReopository(@Path("id") String id);

    /**
     * 获取人脸库的详情
     * @param id
     * @return retrofit2.Call<com.drin.shom.api.dto.RepositoryDetailDto>
     * @author HIPAA
     * @date 2020/7/29 10:33
     */
    @GET("face/v1/repositories/{id}")
    Call<RepositoryDetailDto> reopsitoryDetail(@Path("id") String id);

    /**
     * 新增或者编辑人像库
     * @param id
     * @param param
     * @return retrofit2.Call<java.lang.String>
     * @author HIPAA
     * @date 2020/7/29 10:38
     */
    @PUT("face/v1/repositories/{id}")
    Call<String> editOrInsertReopository(@Path("id") String id, @Body EditRepositoryForm param);



}