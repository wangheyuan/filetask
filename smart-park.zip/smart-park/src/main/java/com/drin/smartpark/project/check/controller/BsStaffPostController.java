package com.drin.smartpark.project.check.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.project.check.entity.BsStaffPost;
import com.drin.smartpark.project.check.service.IBsStaffPostService;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.page.TableDataInfo;

/**
 * 标签信息Controller
 *
 * @author wangheyuan
 * @date 2020-11-20
 */
@RestController
@RequestMapping("/check/post")
public class BsStaffPostController extends BaseController
{
    @Autowired
    private IBsStaffPostService bsStaffPostService;

    /**
     * 查询标签信息列表
     */
    @RequiresPermissions("check:post:list")
    @GetMapping("/list")
    public TableDataInfo list(BsStaffPost bsStaffPost)
    {
        startPage();
        List<BsStaffPost> list = bsStaffPostService.selectBsStaffPostList(bsStaffPost);
        return getDataTable(list);
    }

    /**
     * 导出标签信息列表
     */
    @RequiresPermissions("check:post:export")
    @Log(title = "标签信息", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsStaffPost bsStaffPost)
    {
        List<BsStaffPost> list = bsStaffPostService.selectBsStaffPostList(bsStaffPost);
        ExcelUtil<BsStaffPost> util = new ExcelUtil<BsStaffPost>(BsStaffPost.class);
        return util.exportExcel(list, "post");
    }

    /**
     * 获取标签信息详细信息
     */
    @RequiresPermissions("check:post:query")
    @GetMapping(value = "/{postId}")
    public RestResp getInfo(@PathVariable("postId") Long postId)
    {
        return RestResp.success(bsStaffPostService.selectBsStaffPostById(postId));
    }

    /**
     * 新增标签信息
     */
    @RequiresPermissions("check:post:add")
    @Log(title = "标签信息", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsStaffPost bsStaffPost)
    {
        return toAjax(bsStaffPostService.insertBsStaffPost(bsStaffPost));
    }

    /**
     * 修改标签信息
     */
    @RequiresPermissions("check:post:edit")
    @Log(title = "标签信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsStaffPost bsStaffPost)
    {
        return toAjax(bsStaffPostService.updateBsStaffPost(bsStaffPost));
    }

    /**
     * 删除标签信息
     */
    @RequiresPermissions("check:post:remove")
    @Log(title = "标签信息", businessType = BusinessType.DELETE)
    @DeleteMapping("/{postIds}")
    public RestResp remove(@PathVariable Long[] postIds)
    {
        return toAjax(bsStaffPostService.deleteBsStaffPostByIds(postIds));
    }
}