package com.drin.smartpark.project.api.zdzj.model.form.sub;

import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/8/31 10:30
 * @描述: 添加名单
 */
@Data
public class AddPersonFormSub {

    public static final Integer MAN = 0;
    public static final Integer WOMAN = 1;
    public static final Integer ID_CARD_TYPE = 0;

    //设备ID
    private Integer DeviceID;
    //人员类型 0-黑名单  1-白名单
    private Integer PersonType;
    //人员姓名
    private String Name;
    //性别   0-男 1-女
    private Integer Gender;
    //民族1~57  1-汉族
    private Integer Nation;
    //证件类型 0-身份证
    private Integer CardType;
    //身份证号
    private String IdCard;
    //出生年月日
    private String Birthday;
    //电话号码
    private String Telnum;
    //籍贯
    private String Native;
    //地址
    private String Address;
    //备注
    private String Notes;
    //是否是临时名单 0-永久名单 1-临时名单1   2-临时名单2   3-临时名单3
    private Integer Tempvalid;
    //员工ID号
    private Integer CustomizeID;


}
