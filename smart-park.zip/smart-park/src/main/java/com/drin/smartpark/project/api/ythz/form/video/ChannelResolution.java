/**
 * 文件名称:          	ChannelResolution
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.video;

import lombok.Data;

/**
 *
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/5 16:01
 */
@Data
public class ChannelResolution {
    private Integer width;
    private Integer height;
}
