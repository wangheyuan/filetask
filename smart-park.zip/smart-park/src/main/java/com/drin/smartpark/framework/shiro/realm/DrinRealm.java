package com.drin.smartpark.framework.shiro.realm;

import com.drin.smartpark.common.tool.JsonUtil;
import com.drin.smartpark.project.system.model.LoginUser;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.Permission;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.util.CollectionUtils;

import java.util.Collection;

//公共的realm：获取安全数据，构造权限信息
public class DrinRealm extends AuthorizingRealm {

    public void setName(String name) {
        super.setName("drinRealm");
    }

    //授权方法
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        //1.获取安全数据
        String userInfoStr = JsonUtil.toJsonString(principalCollection.getPrimaryPrincipal());
        LoginUser userInfo = JsonUtil.toObject(userInfoStr,LoginUser.class);
        //2.获取权限信息
//        Set<String> apisPerms = (Set<String>)result.getRoles().get("apis");
        //3.构造权限数据，返回值
        SimpleAuthorizationInfo info = new  SimpleAuthorizationInfo();
        // 设置权限信息
        info.setStringPermissions(userInfo.getPermissions());
//        info.setStringPermissions(apisPerms);
        return info;
    }

    /**
     * 判断是否永远权限
     * @param permission
     * @param info
     * @return boolean
     * @author HIPAA
     * @date 2020/8/31 1:18
     */
    @Override
    protected boolean isPermitted(Permission permission, AuthorizationInfo info) {
        Collection<Permission> pers = getPermissions(info);
        if(CollectionUtils.isEmpty(pers)) {
            return false;
        }else {
            for (Permission p:pers) {
              if(p.toString().equals("*:*:*"))
                  return true;
            }
        }
        return super.isPermitted(permission, info);
    }

    //认证方法
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        return null;
    }
}
