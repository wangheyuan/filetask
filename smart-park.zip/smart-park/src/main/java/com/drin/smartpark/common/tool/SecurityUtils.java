package com.drin.smartpark.common.tool;


import com.drin.smartpark.common.constant.HttpStatus;
import com.drin.smartpark.common.exception.CustomException;
import com.drin.smartpark.project.system.model.LoginUser;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;

/**
 * 安全服务工具类
 * 
 * @author wangheyuan
 */
public class SecurityUtils
{
    /**
     * 获取用户账户
     **/
    public static String getUsername()
    {
        try
        {
//            .getUsername()
            return getLoginUser().getUser().getUserName();
        }
        catch (Exception e)
        {
            throw new CustomException("获取用户账户异常", HttpStatus.UNAUTHORIZED);
        }
    }

    /**
     * 获取用户
     **/
    public static LoginUser getLoginUser()
    {
        try
        {
            Subject subject = org.apache.shiro.SecurityUtils.getSubject();
            //1.subject获取所有的安全数据集合
            PrincipalCollection principals = subject.getPrincipals();
            //2.获取安全数据
            String userInfoStr = JsonUtil.toJsonString(principals.getPrimaryPrincipal());
            LoginUser userInfo = JsonUtil.toObject(userInfoStr,LoginUser.class);
//				(UserInfo) principals.getPrimaryPrincipal();
            return userInfo;
        }
        catch (Exception e)
        {
            throw new CustomException("获取用户信息异常", HttpStatus.UNAUTHORIZED);
        }
    }




    /**
     * 是否为管理员
     * 
     * @param userId 用户ID
     * @return 结果
     */
    public static boolean isAdmin(Long userId)
    {
        return userId != null && 1L == userId;
    }

    /**
     * 给密码加密
     * @param username
     * @param password
     * @return java.lang.String
     * @author HIPAA
     * @date 2020/8/30 5:01
     */
    public static String encryptPassword(String username,String password) {
        return  new Md5Hash(password,username,3).toString();
    }

    /**
     * 比较密码是否相同
     * @param username
     * @param oldPassword
     * @param password
     * @return boolean
     * @author HIPAA
     * @date 2020/8/30 12:37
     */
    public static boolean matchesPassword(String username,String oldPassword, String password) {
        return password.equals(encryptPassword(username,oldPassword));
    }
}
