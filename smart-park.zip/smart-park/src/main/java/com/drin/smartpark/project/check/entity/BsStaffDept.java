package com.drin.smartpark.project.check.entity;

import com.drin.smartpark.common.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.drin.smartpark.framework.excel.annotation.Excel;
import com.drin.smartpark.project.system.model.TreeEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * 员工部门管理对象 bs_staff_dept
 *
 * @author wangheyuan
 * @date 2020-11-19
 */
public class BsStaffDept extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 部门编码 */
    private Long deptId;

    /** 部门名称 */
    @Excel(name = "部门名称")
    private String deptName;

    /** 父部门ID */
    private Long parentId;

    /** 显示顺序 */
    private String orderNum;

    /** 祖级列表 */
    private String ancestors;


    /** 子部门 */
    private List<BsStaffDept> children = new ArrayList<BsStaffDept>();

    public void setDeptId(Long deptId)
    {
        this.deptId = deptId;
    }

    public Long getDeptId()
    {
        return deptId;
    }
    public void setDeptName(String deptName)
    {
        this.deptName = deptName;
    }

    public String getDeptName()
    {
        return deptName;
    }

    public List<BsStaffDept> getChildren() {
        return children;
    }


    public void setChildren(List<BsStaffDept> list) {
        this.children = list;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public String getAncestors() {
        return ancestors;
    }

    public void setAncestors(String ancestors) {
        this.ancestors = ancestors;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("deptId", getDeptId())
                .append("parentId", getParentId())
                .append("ancestors", getAncestors())
                .append("deptName", getDeptName())
                .append("orderNum", getOrderNum())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}