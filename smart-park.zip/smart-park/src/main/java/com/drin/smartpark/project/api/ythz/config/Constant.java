/**
 * 文件名称:          	Constant
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.config;

/**
 * 常用的配置类
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 11:25
 */
public class Constant {

    // 检索类型 抓拍  比对
    public enum SearchFaceType {
        CAPTURE("capture"),
        RETRIEVAL("retrieval");;
        private String name;
        private SearchFaceType(String name) {
            this.name =name;
        }
        public String getValue() {
            return this.name;
        }
    }

    // 性别类型
    public enum GenderType {
        MALE("MALE","男"),
        FEMALE("FEMALE","女");
        private String value;
        private String label;
        public static String key ="GENDER";
        private GenderType(String value,String label) {
            this.value = value;
            this.label = label;
        }
        public static String getLabel(String value) {
            GenderType[] genderTypes = values();
            for (int i = 0; i < genderTypes.length; i++) {
                GenderType genderType = genderTypes[i];
                if(value.equals(genderType.value)) {
                    return genderType.label;
                }
            }
            return null;
        }
    }

    // 性别类型
    public enum AgeType {
        //15以内
        KID("KID","孩子"),
        // 15-20
        KID_YOUTH("KID_YOUTH","学生"),
        // 20-30
        YOUTH("YOUTH","青年"),
        // 30-35
        YOUTH_ADULT("YOUTH_ADULT","青年"),
        // 35-45
        ADULT("ADULT","青年"),
        // 45-55
        ADULT_OLD("ADULT_OLD","中年"),
        //>55
        OLD("OLD","老年");
        private String value;
        private String label;
        public static String key ="AGE";
        private AgeType(String value, String label) {
            this.value = value;
            this.label = label;
        }
        public static String getLabel(String value) {
            AgeType[] ageTypes = values();
            for (int i = 0; i < ageTypes.length; i++) {
                AgeType ageType = ageTypes[i];
                if(value.equals(ageType.value)) {
                    return ageType.label;
                }
            }
            return null;
        }
    }
}
