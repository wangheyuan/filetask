package com.drin.smartpark.project.access.service.impl;

import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.project.access.entity.BsDept;
import com.drin.smartpark.project.access.mapper.BsDeptMapper;
import com.drin.smartpark.project.access.service.IBsDeptService;
import com.drin.smartpark.project.system.model.TreeSelect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 门禁系统部门管理Service业务层处理
 *
 * @author ruoyi
 * @date 2020-09-03
 */
@Service
public class BsDeptServiceImpl implements IBsDeptService
{
    @Autowired
    private BsDeptMapper bsDeptMapper;

    /**
     * 查询门禁系统部门管理
     *
     * @param deptId 门禁系统部门管理ID
     * @return 门禁系统部门管理
     */
    @Override
    public BsDept selectBsDeptById(Long deptId)
    {
        return bsDeptMapper.selectBsDeptById(deptId);
    }

    /**
     * 查询门禁系统部门管理列表
     *
     * @param bsDept 门禁系统部门管理
     * @return 门禁系统部门管理
     */
    @Override
    public List<BsDept> selectBsDeptList(BsDept bsDept)
    {
        return bsDeptMapper.selectBsDeptList(bsDept);
    }

    /**
     * 新增门禁系统部门管理
     *
     * @param bsDept 门禁系统部门管理
     * @return 结果
     */
    @Override
    public int insertBsDept(BsDept bsDept)
    {
        bsDept.setCreateTime(DateUtils.getNowDate());
        return bsDeptMapper.insertBsDept(bsDept);
    }

    /**
     * 修改门禁系统部门管理
     *
     * @param bsDept 门禁系统部门管理
     * @return 结果
     */
    @Override
    public int updateBsDept(BsDept bsDept)
    {
        bsDept.setUpdateTime(DateUtils.getNowDate());
        return bsDeptMapper.updateBsDept(bsDept);
    }

    /**
     * 批量删除门禁系统部门管理
     *
     * @param deptIds 需要删除的门禁系统部门管理ID
     * @return 结果
     */
    @Override
    public int deleteBsDeptByIds(Long[] deptIds)
    {
        return bsDeptMapper.deleteBsDeptByIds(deptIds);
    }

    /**
     * 删除门禁系统部门管理信息
     *
     * @param deptId 门禁系统部门管理ID
     * @return 结果
     */
    @Override
    public int deleteBsDeptById(Long deptId)
    {
        return bsDeptMapper.deleteBsDeptById(deptId);
    }

    /**
     * 获取树状设备列表
     *
     * @param depts
     * @return java.util.List<com.drin.smartpark.project.system.model.TreeSelect>
     * @author HIPAA
     * @date 2020/9/8 15:11
     */
    @Override
    public List<TreeSelect> buildDeptTreeSelect(List<BsDept> depts) {
        List<BsDept> deptTrees = buildDeptTree(depts);
        return deptTrees.stream().map(TreeSelect::new).collect(Collectors.toList());
    }

    /**
     * 构建前端所需要树结构
     *
     * @param depts 部门列表
     * @return 树结构列表
     */
    public List<BsDept> buildDeptTree(List<BsDept> depts)
    {
        List<BsDept> returnList = new ArrayList<BsDept>();
        List<Long> tempList = new ArrayList<Long>();
        for (BsDept dept : depts)
        {
            tempList.add(dept.getDeptId());
        }
        for (Iterator<BsDept> iterator = depts.iterator(); iterator.hasNext();)
        {
            BsDept dept = (BsDept) iterator.next();
            // 如果是顶级节点, 遍历该父节点的所有子节点
            if (!tempList.contains(dept.getParentId()))
            {
                recursionFn(depts, dept);
                returnList.add(dept);
            }
        }
        if (returnList.isEmpty())
        {
            returnList = depts;
        }
        return returnList;
    }

    /**
     * 递归列表
     */
    private void recursionFn(List<BsDept> list, BsDept t)
    {
        // 得到子节点列表
        List<BsDept> childList = getChildList(list, t);
        t.setChildren(childList);
        for (BsDept tChild : childList)
        {
            if (hasChild(list, tChild))
            {
                recursionFn(list, tChild);
            }
        }
    }
    /**
     * 得到子节点列表
     */
    private List<BsDept> getChildList(List<BsDept> list, BsDept t)
    {
        List<BsDept> tlist = new ArrayList<BsDept>();
        Iterator<BsDept> it = list.iterator();
        while (it.hasNext())
        {
            BsDept n = (BsDept) it.next();
            if (StringUtils.isNotNull(n.getParentId()) && n.getParentId().longValue() == t.getDeptId().longValue())
            {
                tlist.add(n);
            }
        }
        return tlist;
    }

    /**
     * 判断是否有子节点
     */
    private boolean hasChild(List<BsDept> list, BsDept t)
    {
        return getChildList(list, t).size() > 0 ? true : false;
    }


}