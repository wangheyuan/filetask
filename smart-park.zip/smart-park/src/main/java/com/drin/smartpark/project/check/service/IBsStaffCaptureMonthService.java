package com.drin.smartpark.project.check.service;

import java.util.List;
import com.drin.smartpark.project.check.entity.BsStaffCaptureMonth;

/**
 * 员工每月考勤Service接口
 *
 * @author wangheyuan
 * @date 2020-11-27
 */
public interface IBsStaffCaptureMonthService
{
    /**
     * 查询员工每月考勤
     *
     * @param historyMonthId 员工每月考勤ID
     * @return 员工每月考勤
     */
    public BsStaffCaptureMonth selectBsStaffCaptureMonthById(Long historyMonthId);

    /**
     * 查询员工每月考勤列表
     *
     * @param bsStaffCaptureMonth 员工每月考勤
     * @return 员工每月考勤集合
     */
    public List<BsStaffCaptureMonth> selectBsStaffCaptureMonthList(BsStaffCaptureMonth bsStaffCaptureMonth);

    /**
     * 新增员工每月考勤
     *
     * @param bsStaffCaptureMonth 员工每月考勤
     * @return 结果
     */
    public int insertBsStaffCaptureMonth(BsStaffCaptureMonth bsStaffCaptureMonth);

    /**
     * 修改员工每月考勤
     *
     * @param bsStaffCaptureMonth 员工每月考勤
     * @return 结果
     */
    public int updateBsStaffCaptureMonth(BsStaffCaptureMonth bsStaffCaptureMonth);

    /**
     * 批量删除员工每月考勤
     *
     * @param historyMonthIds 需要删除的员工每月考勤ID
     * @return 结果
     */
    public int deleteBsStaffCaptureMonthByIds(Long[] historyMonthIds);

    /**
     * 删除员工每月考勤信息
     *
     * @param historyMonthId 员工每月考勤ID
     * @return 结果
     */
    public int deleteBsStaffCaptureMonthById(Long historyMonthId);
}