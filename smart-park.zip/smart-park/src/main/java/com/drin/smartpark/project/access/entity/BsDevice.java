/**
 * 文件名称:          	BsDevice
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.access.entity;

import com.drin.smartpark.common.BaseEntity;
import com.drin.smartpark.framework.excel.annotation.Excel;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.data.annotation.Id;

/**
 * 门禁设备对象 bs_device
 *
 * @author wangheyuan
 * @date 2020-09-01
 */
public class BsDevice extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 设备主键 */
    @Id
    private Integer deviceId;

    /** 设备名称 */
    @Excel(name = "设备名称")
    private String deviceName;

    /** 设备ip */
    @Excel(name = "设备ip")
    private String deviceIp;

    /** 设备账号 */
    @Excel(name = "设备账号")
    private String account;

    /** 设备密码 */
    @Excel(name = "设备密码")
    private String password;

    /** 设备版本 */
    @Excel(name = "版本实际id")
    private String realId;

    public void setDeviceId(Integer deviceId)
    {
        this.deviceId = deviceId;
    }

    public Integer getDeviceId()
    {
        return deviceId;
    }
    public void setDeviceName(String deviceName)
    {
        this.deviceName = deviceName;
    }

    public String getDeviceName()
    {
        return deviceName;
    }
    public void setDeviceIp(String deviceIp)
    {
        this.deviceIp = deviceIp;
    }

    public String getDeviceIp()
    {
        return deviceIp;
    }
    public void setAccount(String account)
    {
        this.account = account;
    }

    public String getAccount()
    {
        return account;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }

    public String getPassword()
    {
        return password;
    }
    public void setRealId(String realId)
    {
        this.realId = realId;
    }

    public String getRealId()
    {
        return realId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("deviceId", getDeviceId())
                .append("deviceName", getDeviceName())
                .append("deviceIp", getDeviceIp())
                .append("account", getAccount())
                .append("password", getPassword())
                .append("realId", getRealId())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("remark", getRemark())
                .toString();
    }
}