/**
 * 文件名称:          	FaceRecordApi
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz;

import com.drin.smartpark.project.api.ythz.dto.CaptureRecordDto;
import com.drin.smartpark.project.api.ythz.dto.RetrievalRecordDto;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.QueryMap;

import java.util.Map;

/**
 * 人脸记录api
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 11:32
 */
public interface FaceRecordApi {

    @GET("face/v1/records")
    Call<CaptureRecordDto> captureRecordList(@QueryMap Map<String,Object> param);

    @GET("face/v1/records")
    Call<RetrievalRecordDto> retrievalRecordList(@QueryMap Map<String,Object> param);
}