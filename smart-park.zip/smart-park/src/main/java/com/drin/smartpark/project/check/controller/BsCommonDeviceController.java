package com.drin.smartpark.project.check.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.service.IBsCommonDeviceService;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;

/**
 * 通用设备Controller
 *
 * @author wangheyuan
 * @date 2020-11-23
 */
@RestController
@RequestMapping("/check/device")
public class BsCommonDeviceController extends BaseController
{
    @Autowired
    private IBsCommonDeviceService bsCommonDeviceService;

    /**
     * 查询通用设备列表
     */
    @RequiresPermissions("check:device:list")
    @GetMapping("/list")
    public RestResp list(BsCommonDevice bsCommonDevice)
    {
        List<BsCommonDevice> list = bsCommonDeviceService.selectBsCommonDeviceList(bsCommonDevice);
        return RestResp.success(list);
    }

    /**
     * 导出通用设备列表
     */
    @RequiresPermissions("check:device:export")
    @Log(title = "通用设备", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsCommonDevice bsCommonDevice)
    {
        List<BsCommonDevice> list = bsCommonDeviceService.selectBsCommonDeviceList(bsCommonDevice);
        ExcelUtil<BsCommonDevice> util = new ExcelUtil<BsCommonDevice>(BsCommonDevice.class);
        return util.exportExcel(list, "device");
    }

    /**
     * 获取通用设备详细信息
     */
    @RequiresPermissions("check:device:query")
    @GetMapping(value = "/{deviceId}")
    public RestResp getInfo(@PathVariable("deviceId") Integer deviceId)
    {
        return RestResp.success(bsCommonDeviceService.selectBsCommonDeviceById(deviceId));
    }

    /**
     * 新增通用设备
     */
    @RequiresPermissions("check:device:add")
    @Log(title = "通用设备", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsCommonDevice bsCommonDevice)
    {
        return toAjax(bsCommonDeviceService.insertBsCommonDevice(bsCommonDevice));
    }

    /**
     * 修改通用设备
     */
    @RequiresPermissions("check:device:edit")
    @Log(title = "通用设备", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsCommonDevice bsCommonDevice)
    {
        return toAjax(bsCommonDeviceService.updateBsCommonDevice(bsCommonDevice));
    }

    /**
     * 删除通用设备
     */
    @RequiresPermissions("check:device:remove")
    @Log(title = "通用设备", businessType = BusinessType.DELETE)
    @DeleteMapping("/{deviceIds}")
    public RestResp remove(@PathVariable Integer[] deviceIds)
    {
        return toAjax(bsCommonDeviceService.deleteBsCommonDeviceByIds(deviceIds));
    }
}