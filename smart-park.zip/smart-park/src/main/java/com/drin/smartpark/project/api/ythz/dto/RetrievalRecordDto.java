/**
 * 文件名称:          	RetrievalRecordDto
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.dto;

import com.drin.smartpark.project.api.ythz.form.face.RetrievalResult;
import lombok.Data;

import java.util.List;

/**
 * 比对返回的对象
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 14:47
 */
@Data
public class RetrievalRecordDto {
    private List<RetrievalResult> records;
    private Long total;
}
