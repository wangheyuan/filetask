package com.drin.smartpark.project.api.ytyx.model.label;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @作者: Kano
 * @时间:2020/8/17 16:16
 * @描述:
 */
@Data
public class LabelForm {
    private List<LabelModel> tag_list = new ArrayList<>();
}
