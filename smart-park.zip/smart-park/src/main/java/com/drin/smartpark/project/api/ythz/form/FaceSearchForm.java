/**
 * 文件名称:          	FaceSearchForm
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form;

import lombok.Data;

/**
 * 模糊搜索人像对应的姓名和信息
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 10:45
 */
@Data
public class FaceSearchForm {

    private String name;
    private Integer start;
    private Integer limit;
    private String order;

}
