/**
 * 文件名称:          	UpdateDoorConditionSub
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj.model.form.sub;

import lombok.Data;

/**
 *  更新设备开门条件
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/18 10:19
 */
@Data
public class UpdateDoorConditionSub {
    private Integer FaceThreshold;
    private Integer IDCardThreshold;
    private Integer OpendoorWay;
    private Integer VerifyMode;
    private Integer ControlType;
    private Integer IOType;
    private Integer IOStayTime;
    private Integer Endian;
    private Integer CardMode;

}
