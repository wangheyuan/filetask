package com.drin.smartpark.project.api.ytyx;

import com.drin.smartpark.project.api.ytyx.dto.YtyxRestResp;
import com.drin.smartpark.project.api.ytyx.model.che.NewAccessPolicyDTO;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.List;

/**
 * @作者: Kano
 * @时间:2020/8/19 15:59
 * @描述: 策略相关API
 */
public interface YtyxCheApi {

    //添加策略
    @POST("park/website/access/policy")
    Call<YtyxRestResp<Object>> addChe(@Body NewAccessPolicyDTO param);

    //获取所有策略
    @GET("park/website/access/policy")
    Call<YtyxRestResp<List<NewAccessPolicyDTO>>> getChe();

    //删除策略
    @DELETE("park/website/access/policy/{id}")
    Call<YtyxRestResp<Object>> deleteChe(@Path("id") String id);

}
