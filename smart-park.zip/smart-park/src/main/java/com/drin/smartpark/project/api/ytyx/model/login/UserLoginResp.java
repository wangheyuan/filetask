/**
 * 文件名称:          	UserLoginResp
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.login;

import lombok.Data;

/**
 * 登录返回体
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/17 12:03
 */
@Data
public class UserLoginResp {

    private String web_authorization;
    private String backend_authorization;
}
