/**
 * 文件名称:          	StorageConfig
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.video;

import com.drin.smartpark.project.api.ythz.form.video.config.CaptureRecordConfig;
import com.drin.smartpark.project.api.ythz.form.video.config.RetrieveRecordConfig;
import lombok.Data;

import java.util.Map;

/**
 * 盒子存储的配置
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/5 14:18
 */
@Data
public class StorageConfig {

    private Map<String,Object> db_image_config;

    private CaptureRecordConfig capture_record_config;

    private RetrieveRecordConfig retrieve_record_config;

}
