/**
 * 文件名称:          	DeviceConfig
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.config;

import com.drin.smartpark.project.api.ythz.dto.Device;
import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 读取盒子的配置
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/28 11:13
 */
@Configuration
@ConfigurationProperties(prefix = "company")
public class HeziDeviceConfig {

    @Getter
    private final  List<Device> devices = new ArrayList<>();

    public void add(String name,String ip) {
        Device device = new Device(name, ip);
        devices.add(device);
    }

    public void update(String ip,String name) {
        for (int i = devices.size()-1; i >=0 ; i--) {
            Device device = devices.get(i);
            if(device.getIp().equals(ip)) {
                device.setName(name);
            }
        }
    }

    public void remove(String ip) {
        for (int i = devices.size()-1; i >=0 ; i--) {
            Device device = devices.get(i);
            if(device.getIp().equals(ip)) {
                devices.remove(i);
            }
        }
    }

    public Map<String,String> getDeviceMap() {
        Map<String,String> result = new HashMap<>();
        if(CollectionUtils.isEmpty(devices))
            return result;
        devices.stream().forEach(device -> {
            result.put(device.getIp(),device.getName());
        });
        return result;
    }


}
