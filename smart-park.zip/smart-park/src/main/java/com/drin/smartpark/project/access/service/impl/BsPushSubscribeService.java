/**
 * 文件名称:          	BsPushSubscribeService
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.access.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.drin.smartpark.common.config.VistConfig;
import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.common.tool.FileToBase64;
import com.drin.smartpark.framework.util.uuid.IdUtils;
import com.drin.smartpark.project.access.entity.BsDevice;
import com.drin.smartpark.project.access.entity.BsStranger;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.access.mapper.BsDeviceMapper;
import com.drin.smartpark.project.access.mapper.BsStrangerMapper;
import com.drin.smartpark.project.access.mapper.BsVisitorMapper;
import com.drin.smartpark.project.access.service.IBsVisitorHistoryService;
import com.drin.smartpark.project.access.service.IBsVisitorService;
import com.drin.smartpark.project.api.zdzj.model.resp.SubscribeIDCardResp;
import com.drin.smartpark.project.api.zdzj.model.resp.SubscribeSnapResp;
import com.drin.smartpark.project.api.zdzj.model.resp.SubscribeVerifyResp;
import com.drin.smartpark.project.api.zdzj.model.resp.sub.SubscribeIDCardSubResp;
import com.drin.smartpark.project.api.zdzj.model.resp.sub.SubscribeSnapSubResp;
import com.drin.smartpark.project.api.zdzj.model.resp.sub.SubscribeVerifySubResp;
import com.drin.smartpark.project.api.zdzj.service.FaceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 * 订阅信息的处理类
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/13 3:08
 */
@Slf4j
@Service
public class BsPushSubscribeService {
    
    @Autowired
    private IBsVisitorService visitorService;

    @Autowired
    private BsVisitorMapper visitorMapper;

    @Autowired
    private BsDeviceMapper deviceMapper;

    @Autowired
    private BsStrangerMapper strangerMapper;
    
    @Autowired
    private FaceService faceService;

    @Autowired
    private IBsVisitorHistoryService historyService;
    
    /**
     * 处理认证过了的人的数据
     * @param person
     * @return void
     * @author HIPAA
     * @date 2020/9/13 3:09
     */
    public void dealVerity(SubscribeVerifyResp person) {
//        person
        //判断认证的方式、
        SubscribeVerifySubResp info = person.getInfo();
        // 获取设备名称
        Integer deviceId = info.getDeviceID();
        QueryWrapper<BsDevice> deviceQueryWrapper = new QueryWrapper<>();
        deviceQueryWrapper.eq("real_id",deviceId);
        BsDevice device = deviceMapper.selectOne(deviceQueryWrapper);
        if(device==null) {
            device = new BsDevice();
            device.setDeviceName("");
        }

        // 自定义id小于0 表示是认证合一通过的
        if(info.getCustomizeID() < 0 && info.getVerfyType()==2) {
            QueryWrapper query = new QueryWrapper<BsVisitor>();
            query.eq("visitor_card",info.getIdCard());
            //判断用户是否创建，没有创建就创建用户
           if(visitorMapper.selectCount(query) == 0) {
               // 增加访客信息
              BsVisitor visitor = addVisitor(person);
              // 增加历史
              historyService.insertVisitorHistoryByBsVisitor(visitor,device.getDeviceName());
               // 增加闸机抓拍的数据到所有的白名单
               faceService.addVisitorToAllDevice(visitor);
           }else {
               // 身份证信息录入过来增加历史
               List<BsVisitor> visitors = visitorMapper.selectList(query);
               BsVisitor visitor = visitors.get(0);
               //增加历史
               historyService.insertVisitorHistoryByBsVisitor(visitor,device.getDeviceName());

           }
        }else  {
            //之前已经录入过的，直接刷脸，增加记录
            QueryWrapper query = new QueryWrapper<BsVisitor>();
            System.out.println("-------------------------");
            System.out.println(info.getCustomizeID());
            query.eq("visitor_id",info.getCustomizeID());
            List<BsVisitor> visitors = visitorMapper.selectList(query);
            BsVisitor visitor = visitors.get(0);
            //增加历史
            historyService.insertVisitorHistoryByBsVisitor(visitor,device.getDeviceName());

        }
    }

    /**
     * 增加访客信息
     * @param person
     * @return void
     * @author HIPAA
     * @date 2020/9/13 3:42
     */
    private BsVisitor addVisitor(SubscribeVerifyResp person) {
        BsVisitor visitor = new BsVisitor();
        SubscribeVerifySubResp info = person.getInfo();
        //访客类型为访客
        visitor.setVisitorType("1");
        //状态有效
        visitor.setStatus("0");
        visitor.setVisitorName(info.getName());
        visitor.setVisitorCard(info.getIdCard());
        String base64 =String.valueOf(person.getSanpPic());
        base64 = base64.substring(23,base64.length());
        try {
            //保存抓拍的图片
            String fileName  = IdUtils.fastUUID() + ".jpg";
            String path = VistConfig.getUploadPath()+"/"+DateUtils.datePath() + "/" ;
            File dir = new File(path);
            if(!dir.exists()){
                dir.mkdirs();
            }
            path = path+fileName;
            //保存图片的路径
            visitor.setImageId("/profile/upload/"+DateUtils.datePath() + "/"+fileName);
            FileToBase64.decoderBase64File(base64, path);
            // 插入访客信息
            visitorService.insertBsVisitor(visitor);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return visitor;
    }


    /**
     * 处理认证过了的身份证信息
     * @param person
     * @return void
     * @author HIPAA
     * @date 2020/9/13 3:11
     */
    public void dealIdCard(SubscribeIDCardResp person) {

        SubscribeIDCardSubResp info = person.getInfo();
        // 获取设备信息
        Integer deviceId = Integer.valueOf(info.getDeviceID());
        QueryWrapper<BsDevice> deviceQueryWrapper = new QueryWrapper<>();
        deviceQueryWrapper.eq("real_id",deviceId);
        BsDevice device = deviceMapper.selectOne(deviceQueryWrapper);
        if(device==null) {
            device = new BsDevice();
            device.setDeviceName("");
        }

        String idcard = info.getIDCard_Idno();
        QueryWrapper<BsVisitor> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("visitor_card",idcard);

        QueryWrapper<BsStranger> queryStrangerWrapper = new QueryWrapper<>();
        queryStrangerWrapper.eq("stranger_card",idcard);
        // 当身份证信息没有录入的时候才会记录陌生人信息，否则不记录
        if(visitorMapper.selectCount(queryWrapper)==0) {
            addStranger(person,device);
        }
        
    }

    private BsStranger addStranger(SubscribeIDCardResp person,BsDevice device) {
        SubscribeIDCardSubResp info = person.getInfo();
        BsStranger stranger = new BsStranger();
        stranger.setStrangerName(info.getIDCard_Name());
        stranger.setStrangerCard(info.getIDCard_Idno());
        stranger.setCreateTime(new Date());
        stranger.setAddress(info.getIDCard_Address());
        // 记录抓拍的设备id
        stranger.setCaptureId(device.getRealId());
        // 备注用为设备名称
        stranger.setRemark(device.getDeviceName());
        String base64 =String.valueOf(person.getIDCard_photo());
        base64 = base64.substring(23,base64.length());
        //保存抓拍的图片
        String fileName  = IdUtils.fastUUID() + ".jpg";
        String path = VistConfig.getUploadPath()+"/"+DateUtils.datePath() + "/" ;
        File dir = new File(path);
        if(!dir.exists()){
            dir.mkdirs();
        }
        path = path+fileName;
        //保存图片的路径
        stranger.setImageId("/profile/upload/"+DateUtils.datePath() + "/"+fileName);
        try {
            FileToBase64.decoderBase64File(base64, path);
        } catch (Exception e) {
            e.printStackTrace();
        }
        strangerMapper.insertBsStranger(stranger);
        return stranger;
    }

    /**
     * 处理陌生人请求的信息
     * @param person
     * @return void
     * @author HIPAA
     * @date 2020/9/13 3:12
     */
    public void dealSnap(SubscribeSnapResp person) {

        SubscribeSnapSubResp info = person.getInfo();
        // 获取抓拍陌生人的时间
        LocalDateTime time = LocalDateTime.now();
        Integer deviceId = info.getDeviceID();
        String base64 = person.getSanpPic();

        System.out.println("抓拍的时间:");
        System.out.println(time);
        QueryWrapper<BsStranger> queryWrapper = new QueryWrapper<>();
        queryWrapper.lt("create_time",time.plusSeconds(5));
        queryWrapper.gt("create_time",time.minusSeconds(5));
        queryWrapper.eq("capture_id",deviceId);
        // 查询出符合条件的前后3秒的人员信息
        List<BsStranger> list = strangerMapper.selectList(queryWrapper);
        //没有查询到人员就不存储抓拍信息
        if(!CollectionUtils.isEmpty(list)) {
            base64 = base64.substring(23,base64.length());
            //保存抓拍的图片
            String fileName  = IdUtils.fastUUID() + ".jpg";
            String path = VistConfig.getUploadPath()+"/"+DateUtils.datePath() + "/" ;
            File dir = new File(path);
            if(!dir.exists()){
                dir.mkdirs();
            }
            path = path+fileName;
            try {
                FileToBase64.decoderBase64File(base64, path);
            } catch (Exception e) {
                e.printStackTrace();
            }
            list.stream().forEach(s->{
               s.setCaptureId("/profile/upload/"+DateUtils.datePath() + "/"+fileName);
               // 更新陌生人信息
               strangerMapper.updateBsStranger(s);
            });

        }else {
            System.out.println("陌生人信息不需要处理");
        }


        //将陌生人的信息进行存储


    }
    
}
