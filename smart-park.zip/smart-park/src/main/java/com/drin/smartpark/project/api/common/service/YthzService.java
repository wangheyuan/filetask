/**
 * 文件名称:          	YtHzService
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.common.service;

import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.entity.BsStaff;
import com.drin.smartpark.project.check.entity.BsStaffCaptureHistory;

import java.util.List;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/5 11:18
 */
public interface YthzService {

    /**
     * 根据盒子设备获取子设备
     * @param parentDevice
     * @return java.util.List<com.drin.smartpark.project.check.entity.BsCommonDevice>
     * @author HIPAA
     * @date 2021/1/5 11:19
     */
    public List<BsCommonDevice> childDeviceList(BsCommonDevice parentDevice);
    
    /**
     * 盒子录入人员
     * @param device
     * @param staff
     * @return void
     * @author HIPAA
     * @date 2021/1/5 11:31
     */
    public void addStaffToDevice(BsCommonDevice device, BsStaff staff);

    /**
     * 盒子删除人员
     * @param device
     * @param staffId
     * @return void
     * @author HIPAA
     * @date 2021/1/5 11:35
     */
    public void removeStaffFromDevice(BsCommonDevice device, String staffId);

    /**
     * 查询设备的所有员工
     * @param device
     * @return java.util.List<com.drin.smartpark.project.check.entity.BsStaffCaptureHistory>
     * @author HIPAA
     * @date 2021/1/5 11:40
     */
    public List<BsStaffCaptureHistory> listStaffCaptureHistoryFromDevice(BsCommonDevice device);

    /**
     * 增加盒子摄像头设备
     * @param device
     * @return void
     * @author HIPAA
     * @date 2021/1/6 15:56
     */
    public void addDevice(BsCommonDevice device);

    /**
     * 移除设备
     * @param device
     * @return void
     * @author HIPAA
     * @date 2021/1/7 10:00
     */
    public void removeDevice(BsCommonDevice device);
    
    /**
     * 更新设备
     * @param device
     * @return void
     * @author HIPAA
     * @date 2021/1/7 10:27
     */
    public void updateDevice(BsCommonDevice device);

}