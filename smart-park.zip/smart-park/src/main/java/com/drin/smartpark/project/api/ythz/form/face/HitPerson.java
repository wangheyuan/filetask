/**
 * 文件名称:          	HitPerson
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.face;

import lombok.Data;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 14:32
 */
@Data
public class HitPerson {
    private String extra_meta;
    private String id;
    private String name;
    private Integer repository_id;
}
