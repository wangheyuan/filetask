package com.drin.smartpark.project.api.zdzj.model.resp.sub;

import lombok.Data;

import java.util.List;

/**
 * @作者: Kano
 * @时间:2020/9/8 11:51
 * @描述: 查询多个名单返回对象info
 */
@Data
public class SearchPersonListSubResp {
    //设备ID
    private String Result;
    private Integer DeviceID;
    private Integer Listnum;
    private Integer Totalnum;
    private List<SearchPersonListInfo> List;
}


@Data
class SearchPersonListInfo {
    //数据库ID
    private Integer LibID;
    //名单类型 0白名单 1黑名单 2所有
    private Integer PersonType;
    //姓名
    private String Name;
    //性别 0男 1女 2其他
    private Integer Gender;
    //证件类型 0身份证
    private Integer CardType;
    //身份证号
    private String IdCard;
    //出生年月日
    private String Birthday;
    //电话号码
    private String Telnum;
    //籍贯
    private String Native;
    //地址
    private String Address;
    //备注信息
    private String Notes;
    //名单类型  0永久名单  1临时名单1  2临时名单2  3临时名单3
    private Integer Tempvalid;
    //自定义ID
    private String CustomizeID;
    //UUID
    private String PersonUUID;
    //如果是临时名单，临时名单生效的开始时间
    private String ValidBegin;
    //如果是临时名单，临时名单生效的结束时间
    private String ValidEnd;


}
