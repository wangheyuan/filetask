package com.drin.smartpark.project.check.service.impl;

import java.time.LocalTime;
import java.util.Date;
import java.util.List;
import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.project.check.dto.GroupCheckDay;
import com.drin.smartpark.project.check.entity.BsCheckPlicy;
import com.drin.smartpark.project.check.entity.BsStaffCaptureHistory;
import com.drin.smartpark.project.check.service.IBsStaffCaptureHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.drin.smartpark.project.check.mapper.BsStaffCaptureDayMapper;
import com.drin.smartpark.project.check.entity.BsStaffCaptureDay;
import com.drin.smartpark.project.check.service.IBsStaffCaptureDayService;

/**
 * 每日考勤Service业务层处理
 *
 * @author wangheyuan
 * @date 2020-11-27
 */
@Service
public class BsStaffCaptureDayServiceImpl implements IBsStaffCaptureDayService
{
    @Autowired
    private BsStaffCaptureDayMapper bsStaffCaptureDayMapper;

    @Autowired
    private IBsStaffCaptureHistoryService historyService;

    /**
     * 查询每日考勤
     *
     * @param historyDayId 每日考勤ID
     * @return 每日考勤
     */
    @Override
    public BsStaffCaptureDay selectBsStaffCaptureDayById(Long historyDayId)
    {
        return bsStaffCaptureDayMapper.selectBsStaffCaptureDayById(historyDayId);
    }

    /**
     * 查询每日考勤列表
     *
     * @param bsStaffCaptureDay 每日考勤
     * @return 每日考勤
     */
    @Override
    public List<BsStaffCaptureDay> selectBsStaffCaptureDayList(BsStaffCaptureDay bsStaffCaptureDay)
    {
        return bsStaffCaptureDayMapper.selectBsStaffCaptureDayList(bsStaffCaptureDay);
    }

    /**
     * 查询每日考勤分组列表
     *
     * @param bsStaffCaptureDay 每日考勤
     * @return 每日考勤集合
     */
    @Override
    public List<GroupCheckDay> selectBsStaffCaptureDayGroupList(BsStaffCaptureDay bsStaffCaptureDay) {
        return bsStaffCaptureDayMapper.selectBsStaffCaptureDayGroupList(bsStaffCaptureDay);
    }

    /**
     * 新增每日考勤
     *
     * @param bsStaffCaptureDay 每日考勤
     * @return 结果
     */
    @Override
    public int insertBsStaffCaptureDay(BsStaffCaptureDay bsStaffCaptureDay)
    {
        bsStaffCaptureDay.setCreateTime(DateUtils.getNowDate());
        return bsStaffCaptureDayMapper.insertBsStaffCaptureDay(bsStaffCaptureDay);
    }

    /**
     * 修改每日考勤
     *
     * @param bsStaffCaptureDay 每日考勤
     * @return 结果
     */
    @Override
    public int updateBsStaffCaptureDay(BsStaffCaptureDay bsStaffCaptureDay)
    {
        bsStaffCaptureDay.setUpdateTime(DateUtils.getNowDate());
        return bsStaffCaptureDayMapper.updateBsStaffCaptureDay(bsStaffCaptureDay);
    }

    /**
     * 批量删除每日考勤
     *
     * @param historyDayIds 需要删除的每日考勤ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffCaptureDayByIds(Long[] historyDayIds)
    {
        return bsStaffCaptureDayMapper.deleteBsStaffCaptureDayByIds(historyDayIds);
    }

    /**
     * 删除每日考勤信息
     *
     * @param historyDayId 每日考勤ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffCaptureDayById(Long historyDayId)
    {
        return bsStaffCaptureDayMapper.deleteBsStaffCaptureDayById(historyDayId);
    }

    /**
     * 更新 每日考勤的进入时间
     *
     * @return void
     * @author HIPAA
     * @date 2020/12/7 11:14
     */
    @Override
    public void setBsStaffCaptureDayNowInTime(Long staffId, BsCheckPlicy plicy) {
        BsStaffCaptureDay sparam  = new BsStaffCaptureDay();
        sparam.setStaffId(staffId);
        // 每日考情会有定时每天产生数据，比如 每天凌晨创建  策略点的时候，更新早上的状态和晚上的状态，所以下面的查询只有一条
        List<BsStaffCaptureDay> captureDays = selectBsStaffCaptureDayList(sparam);
        BsStaffCaptureDay today = captureDays.get(0);
        today.setInTime(new Date());
        if(LocalTime.now().isAfter(plicy.getStartTime())) {
           today.setRemark("迟到");
        }
        // 更新考勤进入时间 和 考勤备注
        updateBsStaffCaptureDay(today);
    }

    /**
     * 更新 每日考勤的外出时间
     *
     * @author HIPAA
     * @date 2020/12/7 11:14
     */
    @Override
    public void setBsStaffCaptureDayNowOutTime(Long staffId, BsCheckPlicy plicy) {
        BsStaffCaptureDay sparam  = new BsStaffCaptureDay();
        sparam.setStaffId(staffId);
        // 每日考情会有定时每天产生数据，比如 每天凌晨创建  策略点的时候，更新早上的状态和晚上的状态，所以下面的查询只有一条
        List<BsStaffCaptureDay> captureDays = selectBsStaffCaptureDayList(sparam);
        BsStaffCaptureDay today = captureDays.get(0);
        today.setOutTime(new Date());
        if (LocalTime.now().isAfter(plicy.getFinishTime())) {
            // 如果只抓到一条记录都会有时间
            LocalTime inTime = DateUtils.getLocalTimeByDate(today.getInTime());
            LocalTime outTime = DateUtils.getLocalTimeByDate(today.getOutTime());
            if(inTime.isBefore(plicy.getStartTime())) {
                today.setStatus("0");
                today.setNormalHour(outTime.getHour()-inTime.getHour());

            }
        }else {
            List<BsStaffCaptureHistory> histories = historyService.getTodayStaffCaptureHistory(staffId);
            if(today.getInTime()==null) {
                today.setInTime(histories.get(0).getCreateTime());
            }
            LocalTime inTime = DateUtils.getLocalTimeByDate(today.getInTime());

            // 取最后一个历史记录
            BsStaffCaptureHistory history = histories.get(histories.size()-1);
            today.setOutTime(history.getCreateTime());
            LocalTime outTime = DateUtils.getLocalTimeByDate(history.getCreateTime());
            today.setNormalHour(outTime.getHour()-inTime.getHour());

        }
        updateBsStaffCaptureDay(today);

    }
}