package com.drin.smartpark.project.access.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.access.entity.BsPassPlicy;

import java.util.List;

/**
 * 策略列Mapper接口
 *
 * @author wangheyuan
 * @date 2020-09-03
 */
public interface BsPassPlicyMapper  extends BaseMapper<BsPassPlicy>
{
    /**
     * 查询策略列
     *
     * @param plicyId 策略列ID
     * @return 策略列
     */
    public BsPassPlicy selectBsPassPlicyById(Long plicyId);

    /**
     * 查询策略列列表
     *
     * @param bsPassPlicy 策略列
     * @return 策略列集合
     */
    public List<BsPassPlicy> selectBsPassPlicyList(BsPassPlicy bsPassPlicy);

    /**
     * 新增策略列
     *
     * @param bsPassPlicy 策略列
     * @return 结果
     */
    public int insertBsPassPlicy(BsPassPlicy bsPassPlicy);

    /**
     * 修改策略列
     *
     * @param bsPassPlicy 策略列.
     *
     *
     * @return 结果
     */
    public int updateBsPassPlicy(BsPassPlicy bsPassPlicy);

    /**
     * 删除策略列
     *
     * @param plicyId 策略列ID
     * @return 结果
     */
    public int deleteBsPassPlicyById(Long plicyId);

    /**
     * 批量删除策略列
     *
     * @param plicyIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsPassPlicyByIds(Long[] plicyIds);
}