package com.drin.smartpark.project.system.controller;


import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.framework.page.TableDataInfo;
import com.drin.smartpark.project.system.entity.SysOperLog;
import com.drin.smartpark.project.system.service.SysOperLogService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 操作日志记录
 * 
 * @author wangheyuan
 */
@RestController
@RequestMapping("/monitor/operlog")
public class SysOperlogController extends BaseController
{
    @Autowired
    private SysOperLogService operLogService;

    @RequiresPermissions("monitor:operlog:list")
    @GetMapping("/list")
    public TableDataInfo list(SysOperLog operLog)
    {
        startPage();
        List<SysOperLog> list = operLogService.selectOperLogList(operLog);
        return getDataTable(list);
    }

    @Log(title = "操作日志", businessType = BusinessType.EXPORT)
    @RequiresPermissions("monitor:operlog:export")
    @GetMapping("/export")
    public RestResp export(SysOperLog operLog)
    {
        List<SysOperLog> list = operLogService.selectOperLogList(operLog);
        ExcelUtil<SysOperLog> util = new ExcelUtil<SysOperLog>(SysOperLog.class);
        return util.exportExcel(list, "操作日志");
    }

    @RequiresPermissions("monitor:operlog:remove")
    @DeleteMapping("/{operIds}")
    public RestResp remove(@PathVariable Long[] operIds)
    {
        return toAjax(operLogService.deleteOperLogByIds(operIds));
    }

    @Log(title = "操作日志", businessType = BusinessType.CLEAN)
    @RequiresPermissions("monitor:operlog:remove")
    @DeleteMapping("/clean")
    public RestResp clean()
    {
        operLogService.cleanOperLog();
        return RestResp.success();
    }
}
