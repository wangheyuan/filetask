/**
 * 文件名称:          	ChannelTargetConfig
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.video;

import lombok.Data;

import java.util.List;

/**
 * 单个摄像头的目标
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/30 14:22
 */
@Data
public class ChannelTargetItem {
    private List<String> target_repo;
    private String video_name;
}
