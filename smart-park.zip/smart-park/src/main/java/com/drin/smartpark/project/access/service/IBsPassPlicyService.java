package com.drin.smartpark.project.access.service;

import com.drin.smartpark.project.access.entity.BsPassPlicy;

import java.util.List;

/**
 * 策略列Service接口
 *
 * @author wangheyuan
 * @date 2020-09-03
 */
public interface IBsPassPlicyService
{
    /**
     * 查询策略列
     *
     * @param plicyId 策略列ID
     * @return 策略列
     */
    public BsPassPlicy selectBsPassPlicyById(Long plicyId);

    /**
     * 查询策略列列表
     *
     * @param bsPassPlicy 策略列
     * @return 策略列集合
     */
    public List<BsPassPlicy> selectBsPassPlicyList(BsPassPlicy bsPassPlicy);

    /**
     * 新增策略列
     *
     * @param bsPassPlicy 策略列
     * @return 结果
     */
    public Long insertBsPassPlicy(BsPassPlicy bsPassPlicy);

    /**
     * 修改策略列
     *
     * @param bsPassPlicy 策略列
     * @return 结果
     */
    public int updateBsPassPlicy(BsPassPlicy bsPassPlicy);

    /**
     * 批量删除策略列
     *
     * @param plicyIds 需要删除的策略列ID
     * @return 结果
     */
    public int deleteBsPassPlicyByIds(Long[] plicyIds);

    /**
     * 删除策略列信息
     *
     * @param plicyId 策略列ID
     * @return 结果
     */
    public int deleteBsPassPlicyById(Long plicyId);

    /**
     * 判断当天是否是在政策内，是否需要导入新的人员，删除对应的人员
     * @param plicy
     * @return boolean
     * @author HIPAA
     * @date 2020/9/8 10:56
     */
    public boolean isValidToday(BsPassPlicy plicy);
}