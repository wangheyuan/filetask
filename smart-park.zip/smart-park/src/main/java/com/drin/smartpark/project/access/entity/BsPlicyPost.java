/**
 * 文件名称:          	BsPlicyPost
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.access.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 策略标签表
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/4 1:35
 */
public class BsPlicyPost {

    /** 策略ID */
    private Long plicyId;

    /** 岗位ID */
    private Long postId;

    public Long getPlicyId()
    {
        return plicyId;
    }

    public void setPlicyId(Long plicyId)
    {
        this.plicyId = plicyId;
    }

    public Long getPostId()
    {
        return postId;
    }

    public void setPostId(Long postId)
    {
        this.postId = postId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("plicyId", getPlicyId())
                .append("postId", getPostId())
                .toString();
    }

}
