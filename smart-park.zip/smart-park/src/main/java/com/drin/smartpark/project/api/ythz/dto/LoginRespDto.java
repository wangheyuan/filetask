/**
 * 文件名称:          	LoginRespDto
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.dto;

import lombok.Data;

/**
 * 登录返回体
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/24 16:48
 */
@Data
public class LoginRespDto {
    private String token;
    private Integer issue_at;
    private Integer expiration;
    private Integer not_before;
}
