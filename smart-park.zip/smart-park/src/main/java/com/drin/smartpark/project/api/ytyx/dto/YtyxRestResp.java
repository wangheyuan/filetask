/**
 * 文件名称:          	YtyxRestResp
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.dto;

import lombok.Data;

import java.util.HashMap;

/**
 * 统一返回体
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/4 10:50
 */
@Data
public class YtyxRestResp<T>  {
    private String message;
    private T result;
    private Integer rtn;
    private Integer total;
}
