package com.drin.smartpark.project.access.service;

import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.access.entity.BsVisitorHistory;

import java.util.List;

/**
 * 访客历史列表Service接口
 *
 * @author ruoyi
 * @date 2020-09-07
 */
public interface IBsVisitorHistoryService
{
    /**
     * 查询访客历史列表
     *
     * @param visitorId 访客历史列表ID
     * @return 访客历史列表
     */
    public BsVisitorHistory selectBsVisitorHistoryById(Long visitorId);
    
    /**
     * 根据访客信息创建历史
     * @param visitor
     * @return void
     * @author HIPAA
     * @date 2020/9/14 10:14
     */
    public void insertVisitorHistoryByBsVisitor(BsVisitor visitor,String deviceName);

    /**
     * 查询访客历史列表列表
     *
     * @param bsVisitorHistory 访客历史列表
     * @return 访客历史列表集合
     */
    public List<BsVisitorHistory> selectBsVisitorHistoryList(BsVisitorHistory bsVisitorHistory);

    /**
     * 新增访客历史列表
     *
     * @param bsVisitorHistory 访客历史列表
     * @return 结果
     */
    public int insertBsVisitorHistory(BsVisitorHistory bsVisitorHistory);

    /**
     * 修改访客历史列表
     *
     * @param bsVisitorHistory 访客历史列表
     * @return 结果
     */
    public int updateBsVisitorHistory(BsVisitorHistory bsVisitorHistory);

    /**
     * 批量删除访客历史列表
     *
     * @param visitorIds 需要删除的访客历史列表ID
     * @return 结果
     */
    public int deleteBsVisitorHistoryByIds(Long[] visitorIds);

    /**
     * 删除访客历史列表信息
     *
     * @param visitorId 访客历史列表ID
     * @return 结果
     */
    public int deleteBsVisitorHistoryById(Long visitorId);
}