/**
 * 文件名称:          	CaptureRecordDto
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.dto;

import com.drin.smartpark.project.api.ythz.form.face.CaptureItem;
import lombok.Data;

import java.util.List;

/**
 * 抓拍返回的对象
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 14:45
 */
@Data
public class CaptureRecordDto {

    private List<CaptureItem> records;
    private Integer total;

}
