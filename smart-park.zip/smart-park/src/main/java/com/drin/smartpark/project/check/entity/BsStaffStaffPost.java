/**
 * 文件名称:          	BsStaffStaffPost
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 员工与员工标签关联
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/11/21 21:44
 */
public class BsStaffStaffPost {
    /** 员工ID */
    private Long staffId;

    /** 标签ID */
    private Long postId;

    public Long getStaffId()
    {
        return staffId;
    }

    public void setStaffId(Long visitorId)
    {
        this.staffId = visitorId;
    }

    public Long getPostId()
    {
        return postId;
    }

    public void setPostId(Long postId)
    {
        this.postId = postId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("staffId", getStaffId())
                .append("postId", getPostId())
                .toString();
    }
}
