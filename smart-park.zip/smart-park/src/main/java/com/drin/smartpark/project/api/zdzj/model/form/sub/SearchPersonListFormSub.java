package com.drin.smartpark.project.api.zdzj.model.form.sub;

import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/9/8 11:11
 * @描述: 查询多个名单info
 */
@Data
public class SearchPersonListFormSub {
    //设备ID
    private Integer DeviceID;
    //名单类型 0~2  0白名单 1黑名单 2所有
    private Integer PersonType;
    //开始时间 "2018-06-01T00:00:00"
    private String BeginTime;
    //结束时间 "2018-06-19T23:59:59"
    private String EndTime;
    //性别 0男 1女 2所有
    private int Gender;
    //年龄范围 如 "0-100"
    private String Age;
    //姓名
    private String Name;
    //是否包含图片信息   1包含
    private int Picture;
}
