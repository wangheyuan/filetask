package com.drin.smartpark.project.api.zdzj.model.resp;

import com.drin.smartpark.project.api.zdzj.model.resp.sub.SubscribeVerifySubResp;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/9/7 14:06
 * @描述: 认证信息返回实体类
 */
@Data
public class SubscribeVerifyResp {
    private String operator;
    private SubscribeVerifySubResp info;
    //抓拍的人脸图片的base64编码
    @JsonProperty("SanpPic")
    private Object SanpPic;
    //匹配名单库里注册的人脸图片的base64编码
    @JsonProperty("RegisteredPic")
    private String RegisteredPic;
}
