/**
 * 文件名称:          	ChannelConfigStr
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.video;

import lombok.Data;

import java.util.List;

/**
 * 返回摄像头对应的目标配置
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/30 14:21
 */
@Data
public class ChannelConfigStr {
    // 摄像头配置
    List<ChannelTargetItem> channel_config;
    // 人脸库设置
    List<RepositoryTargetItem> repository_config;

}
