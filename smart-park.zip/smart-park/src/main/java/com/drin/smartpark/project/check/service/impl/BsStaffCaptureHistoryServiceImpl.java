package com.drin.smartpark.project.check.service.impl;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import com.drin.smartpark.common.tool.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.drin.smartpark.project.check.mapper.BsStaffCaptureHistoryMapper;
import com.drin.smartpark.project.check.entity.BsStaffCaptureHistory;
import com.drin.smartpark.project.check.service.IBsStaffCaptureHistoryService;
import org.springframework.util.CollectionUtils;

/**
 * 员工抓拍历史Service业务层处理
 *
 * @author wangheyuan
 * @date 2020-11-26
 */
@Service
public class BsStaffCaptureHistoryServiceImpl implements IBsStaffCaptureHistoryService
{
    @Autowired
    private BsStaffCaptureHistoryMapper bsStaffCaptureHistoryMapper;

    /**
     * 查询员工抓拍历史
     *
     * @param historyId 员工抓拍历史ID
     * @return 员工抓拍历史
     */
    @Override
    public BsStaffCaptureHistory selectBsStaffCaptureHistoryById(Long historyId)
    {
        return bsStaffCaptureHistoryMapper.selectBsStaffCaptureHistoryById(historyId);
    }

    /**
     * 查询员工抓拍历史列表
     *
     * @param bsStaffCaptureHistory 员工抓拍历史
     * @return 员工抓拍历史
     */
    @Override
    public List<BsStaffCaptureHistory> selectBsStaffCaptureHistoryList(BsStaffCaptureHistory bsStaffCaptureHistory)
    {
        return bsStaffCaptureHistoryMapper.selectBsStaffCaptureHistoryList(bsStaffCaptureHistory);
    }

    /**
     * 新增员工抓拍历史
     *
     * @param bsStaffCaptureHistory 员工抓拍历史
     * @return 结果
     */
    @Override
    public int insertBsStaffCaptureHistory(BsStaffCaptureHistory bsStaffCaptureHistory)
    {
        return bsStaffCaptureHistoryMapper.insertBsStaffCaptureHistory(bsStaffCaptureHistory);
    }

    /**
     * 修改员工抓拍历史
     *
     * @param bsStaffCaptureHistory 员工抓拍历史
     * @return 结果
     */
    @Override
    public int updateBsStaffCaptureHistory(BsStaffCaptureHistory bsStaffCaptureHistory)
    {
        return bsStaffCaptureHistoryMapper.updateBsStaffCaptureHistory(bsStaffCaptureHistory);
    }

    /**
     * 批量删除员工抓拍历史
     *
     * @param historyIds 需要删除的员工抓拍历史ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffCaptureHistoryByIds(Long[] historyIds)
    {
        return bsStaffCaptureHistoryMapper.deleteBsStaffCaptureHistoryByIds(historyIds);
    }

    /**
     * 删除员工抓拍历史信息
     *
     * @param historyId 员工抓拍历史ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffCaptureHistoryById(Long historyId)
    {
        return bsStaffCaptureHistoryMapper.deleteBsStaffCaptureHistoryById(historyId);
    }

    /**
     * 获取抓拍历史
     * @param staffId
     * @return java.util.List<com.drin.smartpark.project.check.entity.BsStaffCaptureHistory>
     * @author HIPAA
     * @date 2020/12/4 13:43
     */
    @Override
    public List<BsStaffCaptureHistory> getTodayStaffCaptureHistory(Long staffId) {
        BsStaffCaptureHistory param = new BsStaffCaptureHistory();
        param.setStaffId(staffId);
        LocalDate localDate = LocalDate.now();
        Date now = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        param.setCreateTime(now);
        List<BsStaffCaptureHistory> histories = bsStaffCaptureHistoryMapper.selectBsStaffCaptureHistoryList(param);
        if(!CollectionUtils.isEmpty(histories)) {
            histories.sort(new Comparator<BsStaffCaptureHistory>() {
                @Override
                public int compare(BsStaffCaptureHistory o1, BsStaffCaptureHistory o2) {
                    if(o2.getCreateTime().after(o1.getCreateTime())){
                        return -1;
                    }else {
                        return 1;
                    }

                }
            });
        }
        return histories;
    }
}