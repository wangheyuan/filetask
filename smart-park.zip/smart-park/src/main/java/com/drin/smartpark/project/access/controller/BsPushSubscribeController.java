package com.drin.smartpark.project.access.controller;

import com.drin.smartpark.project.access.service.impl.BsPushSubscribeService;
import com.drin.smartpark.project.api.zdzj.model.resp.SubscribeIDCardResp;
import com.drin.smartpark.project.api.zdzj.model.resp.SubscribeSnapResp;
import com.drin.smartpark.project.api.zdzj.model.resp.SubscribeVerifyResp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @作者: Kano
 * @时间:2020/9/7 13:54
 * @描述:
 */
@RestController
public class BsPushSubscribeController {

    @Autowired
    private BsPushSubscribeService subscribeService;

    @PostMapping("/Subscribe/Verify")
    public void getSubscribeVerify(@RequestBody SubscribeVerifyResp resp) {
        System.out.println("认证通过");
        System.out.println(resp);
        // 通过的人进行访客的记录 通过历史的记录
        subscribeService.dealVerity(resp);

    }

    @PostMapping("/Subscribe/IDCard")
    public void getSubscribeIDCard(@RequestBody SubscribeIDCardResp resp) {
        System.out.println("----身份证信息上报----");
//        System.out.println(resp);
        subscribeService.dealIdCard(resp);
    }


    @PostMapping("/Subscribe/Snap")
    public void getSubscribeSnap(@RequestBody SubscribeSnapResp resp) {
        System.out.println("----陌生人抓拍上报----");
//        System.out.println(resp);
        subscribeService.dealSnap(resp);
    }

}
