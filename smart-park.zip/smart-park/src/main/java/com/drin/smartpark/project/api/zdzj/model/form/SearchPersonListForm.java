package com.drin.smartpark.project.api.zdzj.model.form;

import com.drin.smartpark.project.api.zdzj.model.form.sub.SearchPersonListFormSub;
import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/9/8 11:08
 * @描述: 查询多个名单
 */
@Data
public class SearchPersonListForm {

    //
    private String operator = "SearchPersonList";
    private SearchPersonListFormSub info;

}
