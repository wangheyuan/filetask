/**
 * 文件名称:          	CheckTime
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.dto;

import lombok.Data;

import java.time.LocalTime;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/11/27 13:55
 */
@Data
public class CheckTime {

    private LocalTime startTime;
    private LocalTime finishTime;

}
