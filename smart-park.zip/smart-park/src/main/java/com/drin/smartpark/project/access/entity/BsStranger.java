package com.drin.smartpark.project.access.entity;

import com.drin.smartpark.common.BaseEntity;
import com.drin.smartpark.framework.excel.annotation.Excel;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.data.annotation.Id;

import java.util.Date;

/**
 * 陌生人列表对象 bs_stranger
 *
 * @author wangheyuan
 * @date 2020-09-09
 */
public class BsStranger extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编码 */
    @Id
    private Long strangerId;

    /** 名称 */
    @Excel(name = "名称")
    private String strangerName;

    /** 身份证号 */
    @Excel(name = "身份证号")
    private String strangerCard;

    /** 身份证照片 */
    @Excel(name = "身份证照片")
    private String imageId;

    /** 抓拍照片id */
    @Excel(name = "抓拍照片id")
    private String captureId;

    /** 生日 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "生日", width = 30, dateFormat = "yyyy-MM-dd")
    private Date birthday;

    /** 地址 */
    @Excel(name = "地址")
    private String address;

    /** 0正常 1 为黑名单 */
    @Excel(name = "0正常 1 为黑名单")
    private String status;

    public void setStrangerId(Long strangerId)
    {
        this.strangerId = strangerId;
    }

    public Long getStrangerId()
    {
        return strangerId;
    }
    public void setStrangerName(String strangerName)
    {
        this.strangerName = strangerName;
    }

    public String getStrangerName()
    {
        return strangerName;
    }
    public void setStrangerCard(String strangerCard)
    {
        this.strangerCard = strangerCard;
    }

    public String getStrangerCard()
    {
        return strangerCard;
    }
    public void setImageId(String imageId)
    {
        this.imageId = imageId;
    }

    public String getImageId()
    {
        return imageId;
    }
    public void setCaptureId(String captureId)
    {
        this.captureId = captureId;
    }

    public String getCaptureId()
    {
        return captureId;
    }
    public void setBirthday(Date birthday)
    {
        this.birthday = birthday;
    }

    public Date getBirthday()
    {
        return birthday;
    }
    public void setAddress(String address)
    {
        this.address = address;
    }

    public String getAddress()
    {
        return address;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("strangerId", getStrangerId())
                .append("strangerName", getStrangerName())
                .append("strangerCard", getStrangerCard())
                .append("imageId", getImageId())
                .append("captureId", getCaptureId())
                .append("birthday", getBirthday())
                .append("address", getAddress())
                .append("status", getStatus())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}