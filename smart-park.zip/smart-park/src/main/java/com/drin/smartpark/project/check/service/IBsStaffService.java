package com.drin.smartpark.project.check.service;

import java.util.List;
import com.drin.smartpark.project.check.entity.BsStaff;

/**
 * 员工Service接口
 *
 * @author wangheyuan
 * @date 2020-11-20
 */
public interface IBsStaffService
{
    /**
     * 查询员工
     *
     * @param staffId 员工ID
     * @return 员工
     */
    public BsStaff selectBsStaffById(Long staffId);

    /**
     * 查询员工
     *
     * @param cardId 员工ID
     * @return 员工
     */
    public BsStaff selectBsStaffByCardId(String  cardId);

    /**
     * 查询员工列表
     *
     * @param bsStaff 员工
     * @return 员工集合
     */
    public List<BsStaff> selectBsStaffList(BsStaff bsStaff);

    /**
     * 新增员工
     *
     * @param bsStaff 员工
     * @return 结果
     */
    public int insertBsStaff(BsStaff bsStaff);

    /**
     * 修改员工
     *
     * @param bsStaff 员工
     * @return 结果
     */
    public int updateBsStaff(BsStaff bsStaff);

    /**
     * 批量删除员工
     *
     * @param staffIds 需要删除的员工ID
     * @return 结果
     */
    public int deleteBsStaffByIds(Long[] staffIds);

    /**
     * 删除员工信息
     *
     * @param staffId 员工ID
     * @return 结果
     */
    public int deleteBsStaffById(Long staffId);

    /**
     * 根据标签列表查询员工列表
     *
     * @param postIds
     * @return 员工集合
     */
    public List<BsStaff> selectBsStaffListByPostIds(List<Long> postIds);
}