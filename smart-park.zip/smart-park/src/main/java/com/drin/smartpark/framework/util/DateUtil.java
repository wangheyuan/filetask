/**
 * 文件名称:          	DateUtil
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.framework.util;

import java.time.LocalDate;

/**
 * 时间处理工具类
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/31 13:32
 */
public class DateUtil {

    public static String getDateDirByDate(LocalDate date) {
        return date.getYear()+"/"+date.getMonth().getValue()+"/"+date.getDayOfMonth();
    }

}
