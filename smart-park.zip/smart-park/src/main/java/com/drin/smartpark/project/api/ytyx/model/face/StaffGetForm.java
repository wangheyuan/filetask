/**
 * 文件名称:          	StaffGetForm
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.face;

import lombok.Data;

import java.util.List;

/**
 * 查询员工的参数
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/18 2:37
 */
@Data
public class StaffGetForm {

    private String fuzzy_query;
    private List<String> tag_id_list;
}
