/**
 * 文件名称:          	YthzServiceImpl
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.common.service.impl;

import com.drin.smartpark.common.config.VistConfig;
import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.common.tool.FileToBase64;
import com.drin.smartpark.common.tool.JsonUtil;
import com.drin.smartpark.framework.util.JsonMapper;
import com.drin.smartpark.framework.util.MapUtil;
import com.drin.smartpark.project.api.common.service.YthzService;
import com.drin.smartpark.project.api.common.util.RtspUrlUtil;
import com.drin.smartpark.project.api.ythz.DeviceApi;
import com.drin.smartpark.project.api.ythz.FaceApi;
import com.drin.smartpark.project.api.ythz.FaceRecordApi;
import com.drin.smartpark.project.api.ythz.config.Constant;
import com.drin.smartpark.project.api.ythz.dto.ChannelConfigDto;
import com.drin.smartpark.project.api.ythz.dto.RetrievalRecordDto;
import com.drin.smartpark.project.api.ythz.dto.capture.VisionAttrItem;
import com.drin.smartpark.project.api.ythz.dto.face.FaceImageDto;
import com.drin.smartpark.project.api.ythz.dto.face.FaceMetaDto;
import com.drin.smartpark.project.api.ythz.form.FaceInsertForm;
import com.drin.smartpark.project.api.ythz.form.PullFaceRecordForm;
import com.drin.smartpark.project.api.ythz.form.capture.CaptureChannel;
import com.drin.smartpark.project.api.ythz.form.capture.CaptureChannelsConfig;
import com.drin.smartpark.project.api.ythz.form.face.RetrievalResult;
import com.drin.smartpark.project.api.ythz.form.video.VideoChannel;
import com.drin.smartpark.project.api.ythz.service.HeSerice;
import com.drin.smartpark.project.api.ythz.service.RetrofitService;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.entity.BsStaff;
import com.drin.smartpark.project.check.entity.BsStaffCaptureHistory;
import com.drin.smartpark.project.check.mapper.BsCommonDeviceMapper;
import com.drin.smartpark.project.check.service.IBsCommonDeviceService;
import com.drin.smartpark.project.check.service.IBsStaffService;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.*;

/**
 * 处理盒子api相关逻辑
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/5 11:18
 */
@Slf4j
@Service
public class YthzServiceImpl implements YthzService {


    // 处理盒子设备相关的
    @Autowired
    private RetrofitService retrofitService;

    @Autowired
    private IBsStaffService staffService;

    @Autowired
    private IBsCommonDeviceService deviceService;


    /**
     * 根据盒子设备获取子设备
     *
     * @param parentDevice
     * @return java.util.List<com.drin.smartpark.project.check.entity.BsCommonDevice>
     * @author HIPAA
     * @date 2021/1/5 11:19
     */
    @SneakyThrows
    @Override
    public List<BsCommonDevice> childDeviceList(BsCommonDevice parentDevice) {
        // 只有是盒子设备的时候才会返回
        if(parentDevice.getDeviceType().equals("1")) {
            retrofitService.tempInitDeviceService(parentDevice);
            DeviceApi deviceApi = retrofitService.getApiByIPService(parentDevice.getDeviceIp(),DeviceApi.class);
            ChannelConfigDto channelConfigDto = deviceApi.channelConfig().execute().body();
            List<VideoChannel> channels = channelConfigDto.getChannel_config().getVideo_channels();
            if (!CollectionUtils.isEmpty(channels)) {
                List<BsCommonDevice> childDeviceList = new ArrayList<>();
                channels.stream().forEach(c->{
                    BsCommonDevice childDevice =  commonDevice(parentDevice.getDeviceId(),c);
                    childDeviceList.add(childDevice);
                });
                return childDeviceList;
            }
        }
        return null;
    }

    /**
     * 盒子录入人员
     *
     * @param device
     * @param staff
     * @return void
     * @author HIPAA
     * @date 2021/1/5 11:31
     */
    @Override
    public void addStaffToDevice(BsCommonDevice device, BsStaff staff) {
        if("1".equals(device.getDeviceType())){
            FaceApi faceApi = retrofitService.getApiByIPService(device.getDeviceIp(),FaceApi.class);
            FaceInsertForm param = faceInsertStaffForm(staff);
            log.info("param:{}",param);
            try {
                faceApi.addFace("1", String.valueOf(staff.getStaffId()), param).execute();
            }catch (EOFException e) {
                log.info("盒子调用成功不返回任何数据");
            }catch (IOException e) {
                log.info("盒子IO异常");
            }
        }
    }

    /**
     * 盒子删除人员
     *
     * @param device
     * @param staffId
     * @return void
     * @author HIPAA
     * @date 2021/1/5 11:35
     */
    @Override
    public void removeStaffFromDevice(BsCommonDevice device, String staffId) {
        if("1".equals(device.getDeviceType())) {
            FaceApi faceApi = retrofitService.getApiByIPService(device.getDeviceIp(), FaceApi.class);
            try {
                faceApi.removeFace("1", staffId).execute();
            } catch (IOException e) {
                log.info("盒子删除成功不会返回数据");
            }
        }
    }

    /**
     * 查询设备的所有员工
     *
     * @param device
     * @return java.util.List<com.drin.smartpark.project.check.entity.BsStaffCaptureHistory>
     * @author HIPAA
     * @date 2021/1/5 11:40
     */
    @Override
    public List<BsStaffCaptureHistory> listStaffCaptureHistoryFromDevice(BsCommonDevice device) {
        if("1".equals(device.getDeviceType())) {
            return listStaffByYthzDevice(device);
        }
        return  null;
    }

    /**
     * 增加盒子摄像头设备
     *
     * @param device
     * @return void
     * @author HIPAA
     * @date 2021/1/6 15:56
     */
    @SneakyThrows
    @Override
    public void addDevice(BsCommonDevice device)  {
        switch (device.getDeviceType()) {
            // 增加RTSP摄像头
            case "2":
                BsCommonDevice parent = deviceService.selectBsCommonDeviceById(device.getParentId().intValue());
                DeviceApi deviceApi = retrofitService.getApiByIPService(parent.getDeviceIp(),DeviceApi.class);
                ChannelConfigDto configDto = deviceApi.channelConfig().execute().body();
                List<VideoChannel> lists = configDto.getChannel_config().getVideo_channels();
                VideoChannel vd = videoChannel(device);
                lists.add(vd);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            deviceApi.updateChannelConfig(configDto).execute().body();
                        }catch (Exception e) {
                            //这里的异常不处理
                        }
                    }
                }).start();
                break;
            // 增加抓拍机
            case "3":
                BsCommonDevice p = deviceService.selectBsCommonDeviceById(device.getParentId().intValue());
                DeviceApi pdeviceApi = retrofitService.getApiByIPService(p.getDeviceIp(),DeviceApi.class);
                CaptureChannelsConfig captrueConfig = pdeviceApi.channelCaptrueConfig().execute().body();
                List<CaptureChannel> plists = captrueConfig.getCapture_channels();
                CaptureChannel cc = captureChannel(device);
                plists.add(cc);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            pdeviceApi.updateCaptureCamera(captrueConfig).execute().body();
                        }catch (Exception e) {
                            //这里的异常不处理
                        }
                    }
                }).start();
                break;
        }
    }

    /**
     * 移除设备
     *
     * @param device
     * @return void
     * @author HIPAA
     * @date 2021/1/7 10:00
     */
    @SneakyThrows
    @Override
    public void removeDevice(BsCommonDevice device) {
        switch (device.getDeviceType()) {
            // 摄像头2
            case "2":
                // 获取盒子设备的设备id
                String realId = device.getRealId();
                BsCommonDevice parent = deviceService.selectBsCommonDeviceById(device.getParentId().intValue());
                DeviceApi deviceApi = retrofitService.getApiByIPService(parent.getDeviceIp(),DeviceApi.class);
                ChannelConfigDto configDto = deviceApi.channelConfig().execute().body();
                List<VideoChannel> lists = configDto.getChannel_config().getVideo_channels();
                if(CollectionUtils.isEmpty(lists))
                    return;
                // 删除摄像头
                for (int i = 0; i < lists.size(); i++) {
                    if(lists.get(i).getChannel_id().equals(realId)) {
                        lists.remove(i);
                    }
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            deviceApi.updateChannelConfig(configDto).execute().body();
                        }catch (Exception e) {
                            //这里的异常不处理
                        }
                    }
                }).start();
                break;
            // 摄像哦图3
            case "3":
                String prealId = device.getRealId();
                BsCommonDevice p = deviceService.selectBsCommonDeviceById(device.getParentId().intValue());
                DeviceApi pdeviceApi = retrofitService.getApiByIPService(p.getDeviceIp(),DeviceApi.class);
                CaptureChannelsConfig captrueConfig = pdeviceApi.channelCaptrueConfig().execute().body();
                List<CaptureChannel> plists = captrueConfig.getCapture_channels();
                for (int i = 0; i < plists.size(); i++) {
                    if(plists.get(i).getChannel_id().equals(prealId)) {
                        plists.remove(i);
                    }
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            pdeviceApi.updateCaptureCamera(captrueConfig).execute().body();
                        }catch (Exception e) {
                            //这里的异常不处理
                        }
                    }
                }).start();
                break;
        }
    }

    /**
     * 更新设备
     *
     * @param device
     * @return void
     * @author HIPAA
     * @date 2021/1/7 10:27
     */
    @SneakyThrows
    @Override
    public void updateDevice(BsCommonDevice device) {
        switch (device.getDeviceType()) {
            // 摄像头2
            case "2":
                // 获取盒子设备的设备id
                String realId = device.getRealId();
                BsCommonDevice parent = deviceService.selectBsCommonDeviceById(device.getParentId().intValue());
                DeviceApi deviceApi = retrofitService.getApiByIPService(parent.getDeviceIp(),DeviceApi.class);
                ChannelConfigDto configDto = deviceApi.channelConfig().execute().body();
                List<VideoChannel> lists = configDto.getChannel_config().getVideo_channels();
                if(CollectionUtils.isEmpty(lists))
                    return;
                // 删除摄像头
                for (int i = 0; i < lists.size(); i++) {
                    if(lists.get(i).getChannel_id().equals(realId)) {
                        VideoChannel videoChannel =  lists.get(i);
                        videoChannel.setChannel_name(device.getDeviceName());
                        videoChannel.setChannel_url(RtspUrlUtil.getRtspByIpAndAccount(device.getDeviceIp(),device.getAccount(),device.getPassword()));
                    }
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            deviceApi.updateChannelConfig(configDto).execute().body();
                        }catch (Exception e) {
                            //这里的异常不处理
                        }
                    }
                }).start();
                break;
            // 摄像哦图3
            case "3":
                String prealId = device.getRealId();
                BsCommonDevice p = deviceService.selectBsCommonDeviceById(device.getParentId().intValue());
                DeviceApi pdeviceApi = retrofitService.getApiByIPService(p.getDeviceIp(),DeviceApi.class);
                CaptureChannelsConfig captrueConfig = pdeviceApi.channelCaptrueConfig().execute().body();
                List<CaptureChannel> plists = captrueConfig.getCapture_channels();
                for (int i = 0; i < plists.size(); i++) {
                    if(plists.get(i).getChannel_id().equals(prealId)) {
                       CaptureChannel cc = plists.get(i);
                       cc.setChannel_ip(device.getDeviceIp());
                       cc.setUsername(device.getAccount());
                       cc.setPassword(device.getPassword());
                       cc.setChannel_name(device.getDeviceName());
                    }
                    plists.get(i).getTarget_repo().add("1");
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            pdeviceApi.updateCaptureCamera(captrueConfig).execute().body();
                        }catch (Exception e) {
                            //这里的异常不处理
                        }
                    }
                }).start();
                break;
        }
    }

    private List<BsStaffCaptureHistory> listStaffByYthzDevice(BsCommonDevice device) {
        FaceRecordApi faceRecordApi = retrofitService.getApiByIPService(device.getDeviceIp(),FaceRecordApi.class);
        Map<String,Object> param = pullFaceRecordForm();
        try {

            List<BsStaffCaptureHistory> staffCaptureHistories = new ArrayList<>();
            RetrievalRecordDto retrievalRecordDto = faceRecordApi.retrievalRecordList(param).execute().body();
            List<RetrievalResult> retrievalItems = retrievalRecordDto.getRecords();



            if (CollectionUtils.isEmpty(retrievalItems))
                return null;
            retrievalItems.stream().forEach(retrievalItem -> {
                long captureTime = retrievalItem.getUnix_timestamp_ms();
                Date captureDate = new Date(captureTime);

                String channelName = retrievalItem.getCapture_result().getChannel_name();
                String faceUrl = retrievalItem.getCapture_result().getFace_image_url();
                String sceneUrl = retrievalItem.getCapture_result().getScene_image_url();
                String name = retrievalItem.getHit_person().getName();

//                String id = retrievalItem.getHit_person().getId();
                List<VisionAttrItem> visionAttrItems =
                        JsonMapper.string2Obj(retrievalItem.getCapture_result().getVision_attributes(), new TypeReference<List<VisionAttrItem>>(){} );

                FaceMetaDto faceMetaDto = JsonUtil.toObject(retrievalItem.getHit_person().getExtra_meta(),FaceMetaDto.class);
                String card = faceMetaDto.getId();// 这个是依图系统的卡号

                List<String> labelList = new ArrayList<>();
                for (VisionAttrItem visionAttrItem : visionAttrItems) {
                    if(visionAttrItem.getType_().equals(Constant.GenderType.key)) {
                        labelList.add(Constant.GenderType.getLabel( visionAttrItem.getValue()));
                    }
                    if (visionAttrItem.getType_().equals(Constant.AgeType.key)) {
                        labelList.add(Constant.AgeType.getLabel( visionAttrItem.getValue()));
                    }
                }
                FaceApi faceApi = retrofitService.getApiByIPService(HeSerice.ip,FaceApi.class);
                LocalDate localDate = captureDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();;
                String faceDirHome = VistConfig.getUploadPath()+"/"+ DateUtils.datePath() +"/face";
                String sceneDirHome = VistConfig.getUploadPath()+"/"+ DateUtils.datePath()+"/scene";

                BsStaffCaptureHistory history = new BsStaffCaptureHistory();

                history.setPictureId("/profile/upload/"+DateUtils.datePath() + "/face/"+faceUrl+".jpg");
                history.setCaptureId("/profile/upload/"+DateUtils.datePath() +"/scene/"+sceneUrl+".jpg");
                history.setRemark(device.getDeviceName() +"->"+channelName);
                history.setStaffName(name);
                // 获取比对中的访客信息
                BsStaff staff = staffService.selectBsStaffByCardId(card);
                if(staff!=null) {
                    history.setStaffName(staff.getStaffName());
                    history.setStaffCard(staff.getStaffCard());
                    history.setImageId(staff.getImageId());
                    history.setStaffId(staff.getStaffId());
                    // 后面会根据realId 来指定当前的设备
                    history.setDeviceId(device.getDeviceId());
                    history.setCreateTime(captureDate);
                    // 只有有这个员工的时候才拉取照片
                    downlowdImg(faceDirHome,faceUrl,faceApi);
                    downlowdImg(sceneDirHome,sceneUrl,faceApi);
                    staffCaptureHistories.add(history);
//                    captureHistoryService.insertBsStaffCaptureHistory(history);
                }else {
//                    System.out.println("--------------不存在的访客id和name");
//                    System.out.println("----------------不处理-----------");
//                    System.out.println(card);
//                    System.out.println(name);
                }
            });
            return  staffCaptureHistories;
        }catch (Exception e) {
            return null;
        }
    }

    private Map<String, Object> pullFaceRecordForm() {
        PullFaceRecordForm param = new PullFaceRecordForm();
        // 获取今天和昨天的记录
        LocalDateTime endDate = LocalDate.now().plusDays(1).atStartOfDay();
        //测试暂时100张
        LocalDateTime startDate = LocalDate.now().minusDays(30).atStartOfDay();
        Long startTime = startDate.toEpochSecond(ZoneOffset.of("+8"));
        Long endTime = endDate.toEpochSecond(ZoneOffset.of("+8"));
        //只查询昨天的数据
        param.setLimit(10000);
        param.setStart_timestamp_ms(startTime*1000);
        param.setEnd_timestamp_ms(endTime*1000);
        param.setMode(Constant.SearchFaceType.RETRIEVAL.getValue());
        return MapUtil.objectToMap(param);
    }

    private void downlowdImg(String dir,String imageId,FaceApi faceApi) {
        try {
            //转换下时间
            File imgFileDir = new File(dir);
            if(!imgFileDir.exists()) {
                imgFileDir.mkdirs();
            }
            String filePath = dir+"/"+imageId+".jpg";
            FileOutputStream fos = new FileOutputStream(filePath);
            InputStream in = faceApi.downloadPicWithUrl(imageId).execute().body().byteStream();
            int count = 0;
            byte[] buffer = new byte[1024];
            while ((count = in.read(buffer)) != -1) {
                fos.write(buffer, 0, count);
            }
            fos.flush();
            fos.close();

//            saveFileImagePath(imageId,filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private BsCommonDevice commonDevice(Integer parentId,VideoChannel vdevice) {
        BsCommonDevice device = new BsCommonDevice();
        device.setDeviceType("2");
        device.setDeviceName(vdevice.getChannel_name());
        device.setAccount(RtspUrlUtil.getAccountByRtspUrl(vdevice.getChannel_url()));
        device.setDeviceIp("rtsp://"+RtspUrlUtil.getIpByRtspUrl(vdevice.getChannel_url()));
        device.setPassword(RtspUrlUtil.getPasswordByRtspUrl(vdevice.getChannel_url()));
        device.setParentId(parentId);
        device.setRealId(vdevice.getChannel_id());
        return  device;
    }

    private FaceInsertForm faceInsertStaffForm(BsStaff visitor) {
        String imageId = visitor.getImageId().replaceAll("/profile", "");
        String imagePath = VistConfig.getProfile() +"/"+ imageId;
        String imgBase64 = FileToBase64.encodeBase64File(imagePath);
        FaceImageDto faceImageDto = new FaceImageDto();
        faceImageDto.setContent(imgBase64);
        faceImageDto.setContent_type("JPEG");
        FaceInsertForm result = new FaceInsertForm();
        result.setFace_image(faceImageDto);
        Map<String,String> meta = new HashMap<String,String>();
        meta.put("name",visitor.getStaffName());
        meta.put("id",String.valueOf(visitor.getStaffId()));
        result.setExtra_meta(JsonUtil.toJsonString(meta));
        return result;
    }

    private VideoChannel videoChannel(BsCommonDevice device) {
        VideoChannel vd = new VideoChannel();
        vd.setChannel_id(String.valueOf(device.getDeviceId()));
        vd.setChannel_url(RtspUrlUtil.getRtspByIpAndAccount(device.getDeviceIp(),device.getAccount(),device.getPassword()));
        vd.setChannel_name(device.getDeviceName());
        vd.setChannel_protocol("RTSP");
        //默认增加人脸库 1 设置人脸比对模式
        vd.setChannel_type("FaceRetrieval");
        vd.getTarget_repo().add("1");
        vd.setChannel_format("H264");
        vd.setTargetRepositoryNum(1);
        vd.setVendor("YITU");
        vd.setExtra_meta("{\"device_id\":\"\",\"place_code\":\"0\",\"camera_path\":\"\",\"longitude\":0,\"latitude\":0}");
        return vd;
    }

    public CaptureChannel captureChannel(BsCommonDevice device) {
        CaptureChannel cc = new CaptureChannel();
        cc.getTarget_repo().add("1");
        cc.setChannel_id(String.valueOf(device.getDeviceId()));
        cc.setChannel_name(device.getDeviceName());
        cc.setChannel_ip(device.getDeviceIp());
        cc.setUsername(device.getAccount());
        cc.setPassword(device.getPassword());
        cc.setChannel_port(80);
        cc.setChannel_type("FaceRetrieval");
        return cc;
    }

}
