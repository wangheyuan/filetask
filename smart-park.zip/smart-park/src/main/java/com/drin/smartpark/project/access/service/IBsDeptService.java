package com.drin.smartpark.project.access.service;

import com.drin.smartpark.project.access.entity.BsDept;
import com.drin.smartpark.project.system.model.TreeSelect;

import java.util.List;

/**
 * 门禁系统部门管理Service接口
 *
 * @author ruoyi
 * @date 2020-09-03
 */
public interface IBsDeptService
{
    /**
     * 查询门禁系统部门管理
     *
     * @param deptId 门禁系统部门管理ID
     * @return 门禁系统部门管理
     */
    public BsDept selectBsDeptById(Long deptId);

    /**
     * 查询门禁系统部门管理列表
     *
     * @param bsDept 门禁系统部门管理
     * @return 门禁系统部门管理集合
     */
    public List<BsDept> selectBsDeptList(BsDept bsDept);

    /**
     * 新增门禁系统部门管理
     *
     * @param bsDept 门禁系统部门管理
     * @return 结果
     */
    public int insertBsDept(BsDept bsDept);

    /**
     * 修改门禁系统部门管理
     *
     * @param bsDept 门禁系统部门管理
     * @return 结果
     */
    public int updateBsDept(BsDept bsDept);

    /**
     * 批量删除门禁系统部门管理
     *
     * @param deptIds 需要删除的门禁系统部门管理ID
     * @return 结果
     */
    public int deleteBsDeptByIds(Long[] deptIds);

    /**
     * 删除门禁系统部门管理信息
     *
     * @param deptId 门禁系统部门管理ID
     * @return 结果
     */
    public int deleteBsDeptById(Long deptId);
    
    /**
     * 获取树状设备列表
     * @param depts
     * @return java.util.List<com.drin.smartpark.project.system.model.TreeSelect>
     * @author HIPAA
     * @date 2020/9/8 15:11
     */
    public List<TreeSelect> buildDeptTreeSelect(List<BsDept> depts);


}