package com.drin.smartpark.project.access.controller;

import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.framework.page.TableDataInfo;
import com.drin.smartpark.project.access.entity.BsDevice;
import com.drin.smartpark.project.access.entity.BsPassPlicy;
import com.drin.smartpark.project.access.service.IBsDeviceService;
import com.drin.smartpark.project.access.service.IBsPassPlicyService;
import com.drin.smartpark.project.system.service.SysPostService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 策略列Controller
 *
 * @author wangheyuan
 * @date 2020-09-03
 */
@RestController
@RequestMapping("/access/plicy")
public class BsPassPlicyController extends BaseController
{
    @Autowired
    private IBsPassPlicyService bsPassPlicyService;

    @Autowired
    private SysPostService postService;

    @Autowired
    private IBsDeviceService deviceService;

    /**
     * 查询策略列列表
     */
    @RequiresPermissions("access:plicy:list")
    @GetMapping("/list")
    public TableDataInfo list(BsPassPlicy bsPassPlicy)
    {
        startPage();
        List<BsPassPlicy> list = bsPassPlicyService.selectBsPassPlicyList(bsPassPlicy);
        return getDataTable(list);
    }

    /**
     * 获取策略列详细信息
     */
    @RequiresPermissions("access:plicy:query")
    @GetMapping(value = {"/","/{plicyId}"})
    public RestResp getInfo(@PathVariable(value = "plicyId", required = false) Long plicyId)
    {
        RestResp restResp = RestResp.success();
        restResp.put("posts", postService.selectPostAll());
        restResp.put("devices",deviceService.selectBsDeviceList(new BsDevice()));
        if (StringUtils.isNotNull(plicyId))
        {
            restResp.put(RestResp.DATA_TAG, bsPassPlicyService.selectBsPassPlicyById(plicyId));
            restResp.put("postIds", postService.selectPostListByPlicyId(plicyId));
            restResp.put("deviceIds",deviceService.selectDeviceIdListByPlicyId(plicyId));

        }

        return restResp;
    }

    /**
     * 新增策略列
     */
    @RequiresPermissions("access:plicy:add")
    @Log(title = "策略列", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsPassPlicy bsPassPlicy)
    {
        return toAjax(bsPassPlicyService.insertBsPassPlicy(bsPassPlicy).intValue());
    }

    /**
     * 修改策略列
     */
    @RequiresPermissions("access:plicy:edit")
    @Log(title = "策略列", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsPassPlicy bsPassPlicy)
    {
        return toAjax(bsPassPlicyService.updateBsPassPlicy(bsPassPlicy));
    }

    /**
     * 删除策略列
     */
    @RequiresPermissions("access:plicy:remove")
    @Log(title = "策略列", businessType = BusinessType.DELETE)
    @DeleteMapping("/{plicyIds}")
    public RestResp remove(@PathVariable Long[] plicyIds)
    {
        return toAjax(bsPassPlicyService.deleteBsPassPlicyByIds(plicyIds));
    }
}