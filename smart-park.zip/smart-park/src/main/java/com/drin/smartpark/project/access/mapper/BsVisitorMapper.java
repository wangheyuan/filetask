package com.drin.smartpark.project.access.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.access.entity.BsVisitor;

import java.util.List;

/**
 * 访客信息管理Mapper接口
 *
 * @author wangheyuan
 * @date 2020-09-02
 */
public interface BsVisitorMapper  extends BaseMapper<BsVisitor>
{
    /**
     * 查询访客信息管理
     *
     * @param visitorId 访客信息管理ID
     * @return 访客信息管理
     */
    public BsVisitor selectBsVisitorById(Long visitorId);

    /**
     * 查询访客信息管理列表
     *
     * @param bsVisitor 访客信息管理
     * @return 访客信息管理集合
     */
    public List<BsVisitor> selectBsVisitorList(BsVisitor bsVisitor);

    /**
     * 新增访客信息管理
     *
     * @param bsVisitor 访客信息管理
     * @return 结果
     */
    public int insertBsVisitor(BsVisitor bsVisitor);

    /**
     * 修改访客信息管理
     *
     * @param bsVisitor 访客信息管理
     * @return 结果
     */
    public int updateBsVisitor(BsVisitor bsVisitor);

    /**
     * 删除访客信息管理
     *
     * @param visitorId 访客信息管理ID
     * @return 结果
     */
    public int deleteBsVisitorById(Long visitorId);

    /**
     * 批量删除访客信息管理
     *
     * @param visitorIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsVisitorByIds(Long[] visitorIds);

    /**
     * 通过策略id
     * @param postIds
     * @return java.util.List<com.drin.smartpark.project.access.entity.BsVisitor>
     * @author HIPAA
     * @date 2020/9/8 10:39
     */
    public List<BsVisitor> selectVisitorListByPostIds(List<Long> postIds);

    /**
     * 通过策略id返回访客列表
     * @param plicyId
     * @return java.util.List<com.drin.smartpark.project.access.entity.BsVisitor>
     * @author HIPAA
     * @date 2020/9/8 10:41
     */
    public List<BsVisitor> selectVisitorListByPlicyId(Long plicyId);
}