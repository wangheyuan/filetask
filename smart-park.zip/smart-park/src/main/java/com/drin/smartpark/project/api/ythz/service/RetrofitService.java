/**
 * 文件名称:          	RetrofitFactory
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.service;

import com.drin.smartpark.common.tool.Md5Utils;
import com.drin.smartpark.project.api.ythz.LoginApi;
import com.drin.smartpark.project.api.ythz.dto.LoginRespDto;
import com.drin.smartpark.project.api.ythz.form.HzLoginForm;
import com.drin.smartpark.project.api.ytyx.YtyxLoginApi;
import com.drin.smartpark.project.api.ytyx.dto.YtyxRestResp;
import com.drin.smartpark.project.api.ytyx.model.login.YtyxUserLoginForm;
import com.drin.smartpark.project.api.ytyx.model.login.UserLoginResp;
import com.drin.smartpark.project.api.zdzj.net.SSLTool;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.mapper.BsCommonDeviceMapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import okhttp3.logging.HttpLoggingInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import javax.annotation.PostConstruct;
import javax.net.ssl.*;
import java.io.IOException;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * 初始化需要调用的请求
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/24 14:56
 */
@Slf4j
@Service
public class RetrofitService {

//    @Autowired
//    HeziDeviceConfig deviceConfig;

    @Value("${httpLogFlag}")
    private Boolean httpLogFlag;

    @Autowired
    private BsCommonDeviceMapper commonDeviceMapper;

    @Autowired
    SyncEhcacheService ehcacheService;

    private Map<String,OkHttpClient> httpClientMap = new HashMap<>();

    private Map<String,Retrofit> retrofitMap = new HashMap<>();

    private Map<String,Retrofit> tempRetrofitMap = new HashMap<>();


    @PostConstruct
    private void initDeviceList() {
        // 清理缓存初始化信息
        tempRetrofitMap.clear();
        List<BsCommonDevice> deviceList  = commonDeviceMapper.selectBsCommonDeviceList(new BsCommonDevice());
        if(!CollectionUtils.isEmpty(deviceList)) {
            deviceList.stream().forEach(device->{
                if(retrofitMap.get(device.getDeviceIp())==null && "1".equals(device.getDeviceType())) {
                    retrofitMap.put(device.getDeviceIp(),retrofitByCommonDevice(device));
                }else  if(retrofitMap.get(device.getDeviceIp())==null && "4".equals(device.getDeviceType())) {
                    retrofitMap.put(device.getDeviceIp(),retrofitByYtyxDevice(device));
                }
            });
        }
    }

    /**
     * 获取token
     * @param 
     * @return java.lang.String
     * @author HIPAA
     * @date 2020/7/30 11:34
     */
    private String token(String ip) {
        if(ehcacheService.getCode(ip) == null) {
            LoginApi loginApi = getApiByIPService(ip, LoginApi.class);
            HzLoginForm param = new HzLoginForm();
            try {
                LoginRespDto loginRespDto = loginApi.login(param).execute().body();
                String token = loginRespDto.getToken();
                ehcacheService.putCode(ip, token);
                return token;
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }else {
            return ehcacheService.getCode(ip);
        }
    }



    private String token(String ip,String username,String password) {
        if(ehcacheService.getCode(ip) == null) {
            LoginApi loginApi = getApiByIPService(ip, LoginApi.class);
            HzLoginForm param = new HzLoginForm();
            param.setUsername(username);
            param.setPassword(Md5Utils.encryption(password));
            try {
                LoginRespDto loginRespDto = loginApi.login(param).execute().body();
                String token = loginRespDto.getToken();
                ehcacheService.putCode(ip, token);
                return token;
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }else {
            return ehcacheService.getCode(ip);
        }
    }



    /**
     * 根据设备ip返回设备retrofit实例对象
     * @param ip
     * @return retrofit2.Retrofit
     * @author HIPAA
     * @date 2020/7/28 15:20
     */
    public Retrofit getRetrofitByIp(String ip) {
        return retrofitMap.get(ip);
    }

    /**
     *  根据ip和对应apiService返回对应的实体类
     * @param ip
     * @param serviceClass
     * @return T
     * @author HIPAA
     * @date 2020/7/29 0:25
     */
    public <T> T getApiByIPService(String ip,Class<T> serviceClass){
        // 如果hashmap没有初始化，需要初始化
        Retrofit retrofit =getRetrofitByIp(ip);
        if(retrofit==null) {
            retrofit = tempRetrofitMap.get(ip);
        }
        return retrofit.create(serviceClass);
    }


    public void tempInitDeviceService(BsCommonDevice device) {
        switch (device.getDeviceType()) {
            case "1":
                tempRetrofitMap.put(device.getDeviceIp(),retrofitByCommonDevice(device));
                break;
            case "4":
                tempRetrofitMap.put(device.getDeviceIp(),retrofitByYtyxDevice(device));
                break;
        }

    }

    @SneakyThrows
    private Retrofit retrofitByCommonDevice(BsCommonDevice device) {
        TrustManagerFactory trustManagerFactory = null;
        trustManagerFactory = TrustManagerFactory.getInstance(
                TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init((KeyStore) null);
        TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
        if (trustManagers.length != 1 || !(trustManagers[0] instanceof X509TrustManager)) {
            throw new IllegalStateException("Unexpected default trust managers:"
                    + Arrays.toString(trustManagers));
        }
        X509TrustManager trustManager = (X509TrustManager) trustManagers[0];
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{trustManager}, null);
        SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

        HttpLoggingInterceptor logInterceptor = new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
            @Override
            public void log(String message) {
                if(httpLogFlag && !message.contains("----------------------")) {
                    log.info("盒子第三方请求：{}",message);
                }
            }
        });
        logInterceptor.setLevel( HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client=  new OkHttpClient.Builder().connectTimeout(50L, TimeUnit.SECONDS)
                .sslSocketFactory(sslSocketFactory, trustManager)
//                .sslSocketFactory(SSLTool.createSSLSocketFactory())
                .hostnameVerifier(new SSLTool.TrustAllHostnameVerifier())
                .addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request originalRequest = chain.request();
                        String url = originalRequest.url().toString();
                        Request.Builder requestBuilder = originalRequest
                                .newBuilder();
                        if(!url.contains("token") && device.getAccount()!=null && device.getPassword()!=null) {
                            String token = token(device.getDeviceIp(),device.getAccount(),device.getPassword());
                            requestBuilder.addHeader("token",token);
                        }
                        Request original = chain.request();
                        Request request = requestBuilder.header("Content-Type","application/json")
                                .header("Accept","application/json")
                                .method(original.method(), original.body()).build();
                        return chain.proceed(request);
                    }
                })
                .addInterceptor(logInterceptor)
                .build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(device.getDeviceIp())
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        return retrofit;
    }
    private static class TrustAllManager implements X509TrustManager {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType)
                throws CertificateException {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType)
                throws CertificateException {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }


    // 云悉初始化retrofit
    @SneakyThrows
    private Retrofit retrofitByYtyxDevice(BsCommonDevice device) {
        X509TrustManager trustManager = new TrustAllManager();
                //(X509TrustManager) trustManagers[0];
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{trustManager}, new SecureRandom());
        SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

        HttpLoggingInterceptor logInterceptor = new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
            @Override
            public void log(String message) {
                if(httpLogFlag && !message.contains("----------------------")) {
                    log.info("第三方请求：{}",message);
                }
            }
        });
        logInterceptor.setLevel( HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client=  new OkHttpClient.Builder().connectTimeout(5L, TimeUnit.SECONDS)
                .sslSocketFactory(sslSocketFactory, trustManager)
//                .sslSocketFactory(SSLTool.createSSLSocketFactory())
                .hostnameVerifier(new SSLTool.TrustAllHostnameVerifier())
                .addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request originalRequest = chain.request();
                        String url = originalRequest.url().toString();
                        Request.Builder requestBuilder = originalRequest
                                .newBuilder();
                        if(!url.contains("login") && device.getAccount()!=null && device.getPassword()!=null) {
                            Map<String,String> header = ytyxTokenHeader(device);
                            if(header!= null && !header.isEmpty()) {
                                header.forEach((k, v) -> {
                                    requestBuilder.addHeader(k, v);
                                });
                            }
                        }
                        Request original = chain.request();
                        Request request = requestBuilder.header("Content-Type","application/json")
                                .header("Accept","application/json")
                                .method(original.method(), original.body()).build();
                        return chain.proceed(request);
                    }
                })
                .addInterceptor(logInterceptor)
                .build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(device.getDeviceIp())
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        return retrofit;
    }

    /**
     * 获取token
     *
     * @param
     * @return java.lang.String
     * @author HIPAA
     * @date 2020/7/30 11:34
     */
    private Map<String, String> ytyxTokenHeader(BsCommonDevice device) {
        Map<String, String> header = new HashMap<>();
        if (ehcacheService.getCode(device.getDeviceIp()) == null) {
            YtyxLoginApi loginApi = getApiByIPService(device.getDeviceIp(),YtyxLoginApi.class);
            YtyxUserLoginForm param = new YtyxUserLoginForm();
            param.setUsername(device.getAccount());
            param.setPassword(Md5Utils.encryption(device.getPassword()));
            try {
                YtyxRestResp<UserLoginResp> loginRespDto = loginApi.login(param).execute().body();
                String btoken = loginRespDto.getResult().getBackend_authorization();
                String wtoken = loginRespDto.getResult().getWeb_authorization();
                ehcacheService.putCode(device.getDeviceIp() + "b", btoken);
                ehcacheService.putCode(device.getDeviceIp() + "w", wtoken);
                header.put("Authorization", "Bearer " + wtoken);
                header.put("Backend-Authorization", btoken);
                return header;
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        } else {
            String btoken = ehcacheService.getCode(device.getDeviceIp() + "b");
            String wtoken = ehcacheService.getCode(device.getDeviceIp() + "w");
            header.put("Authorization", wtoken);
            header.put("Backend-Authorization", btoken);
            return header;
        }
    }
}
