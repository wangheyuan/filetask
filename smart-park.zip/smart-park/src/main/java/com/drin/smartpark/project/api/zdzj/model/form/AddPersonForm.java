package com.drin.smartpark.project.api.zdzj.model.form;

import com.drin.smartpark.project.api.zdzj.model.form.sub.AddPersonFormSub;
import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/8/31 10:29
 * @描述: 闸机名单实体类
 */
@Data
public class AddPersonForm {
    //AddPerson: 往名单库添加名单
    //EditPerson: 修改名单库里的人员信息
    private String operator;
    //人员具体内容
    private AddPersonFormSub info;
    //人员图片base64
    private String picinfo;
}
