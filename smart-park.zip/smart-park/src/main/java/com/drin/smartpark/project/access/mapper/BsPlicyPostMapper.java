/**
 * 文件名称:          	BsPlicyPostMapper
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.access.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.access.entity.BsPlicyPost;

import java.util.List;

/**
 * 策略标签mapper
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/4 1:42
 */
public interface BsPlicyPostMapper extends BaseMapper<BsPlicyPost> {

    /**
     * 通过策略ID删除策略和标签关联
     *
     * @param plicyId 策略ID
     * @return 结果
     */
    public int deletePlicyPostByPlicyId(Long plicyId);

    /**
     * 通过标签ID查询标签使用数量
     *
     * @param postId 标签ID
     * @return 结果
     */
    public int countPlicyPostById(Long postId);

    /**
     * 批量删除策略和标签关联
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deletePlicyPost(Long[] ids);

    /**
     * 批量新增策略标签信息
     *
     * @param plicyPostList 策略角色列表
     * @return 结果
     */
    public int batchPlicyPost(List<BsPlicyPost> plicyPostList);
    
}