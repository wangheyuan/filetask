/**
 * 文件名称:          	BsVisitorPostMapper
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.access.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.access.entity.BsVisitorPost;

import java.util.List;

/**
 * 访客标签管理
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/2 13:41
 */
public interface BsVisitorPostMapper  extends BaseMapper<BsVisitorPost> {
    /**
     * 通过访客ID删除访客和标签关联
     *
     * @param userId 访客ID
     * @return 结果
     */
    public int deleteVisitorPostByVisitorId(Long userId);

    /**
     * 通过标签ID查询标签使用数量
     *
     * @param postId 标签ID
     * @return 结果
     */
    public int countVisitorPostById(Long postId);

    /**
     * 批量删除访客和标签关联
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteVisitorPost(Long[] ids);

    /**
     * 批量新增访客标签信息
     *
     * @param userPostList 访客角色列表
     * @return 结果
     */
    public int batchVisitorPost(List<BsVisitorPost> userPostList);
}
