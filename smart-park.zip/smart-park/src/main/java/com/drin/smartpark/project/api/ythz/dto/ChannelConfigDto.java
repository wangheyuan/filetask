/**
 * 文件名称:          	ChannelConfigForm
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.dto;

import com.drin.smartpark.project.api.ythz.form.video.AlgorithmConfig;
import com.drin.smartpark.project.api.ythz.form.video.ChannelConfig;
import com.drin.smartpark.project.api.ythz.form.video.ReleaseConfiguration;
import com.drin.smartpark.project.api.ythz.form.video.StorageConfig;
import lombok.Data;

import java.util.Map;

/**
 * 获取摄像头配置
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 16:56
 */
@Data
public class ChannelConfigDto {
    private ChannelConfig channel_config;
    private String retrieve_upload_address;
    private AlgorithmConfig algorithm_config;
    private StorageConfig storage_config;
    private ReleaseConfiguration release_configuration;
    private String upload_format="json";
    private boolean background_retrieve=false;
}
