/**
 * 文件名称:          	AddDevice
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.form;

import com.drin.smartpark.project.api.ytyx.model.device.YtyxDevice;
import lombok.Data;

import java.util.List;

/**
 * 新增设备
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/4 16:00
 */
@Data
public class AddDevice {
    private List<YtyxDevice> device_list;
}
