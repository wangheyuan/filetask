package com.drin.smartpark.project.access.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.access.entity.BsDevice;

import java.util.List;

/**
 * 门禁设备Mapper接口
 *
 * @author wangheyuan
 * @date 2020-09-01
 */
public interface BsDeviceMapper  extends BaseMapper<BsDevice>
{
    /**
     * 查询门禁设备
     *
     * @param deviceId 门禁设备ID
     * @return 门禁设备
     */
    public BsDevice selectBsDeviceById(Integer deviceId);

    /**
     * 查询门禁设备列表
     *
     * @param bsDevice 门禁设备
     * @return 门禁设备集合
     */
    public List<BsDevice> selectBsDeviceList(BsDevice bsDevice);

    /**
     * 新增门禁设备
     *
     * @param bsDevice 门禁设备
     * @return 结果
     */
    public int insertBsDevice(BsDevice bsDevice);

    /**
     * 根据策略ID获取岗位选择框列表
     *
     * @param plicyId 策略ID
     * @return 选中岗位ID列表
     */
    public List<Long> selectDeviceIdListByPlicyId(Long plicyId);

    /**
     * 修改门禁设备
     *
     * @param bsDevice 门禁设备
     * @return 结果
     */
    public int updateBsDevice(BsDevice bsDevice);

    /**
     * 删除门禁设备
     *
     * @param deviceId 门禁设备ID
     * @return 结果
     */
    public int deleteBsDeviceById(Integer deviceId);

    /**
     * 批量删除门禁设备
     *
     * @param deviceIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsDeviceByIds(Integer[] deviceIds);

    /**
     * 根据策略ID获取岗位选择框列表
     *
     * @param plicyId 策略ID
     * @return 选中岗位ID列表
     */
    public List<BsDevice> selectDeviceListByPlicyId(Long plicyId);
}