/**
 * 文件名称:          	BsCheckCheckPlicyDeviceMapper
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.check.entity.BsCheckPlicyDevice;


import java.util.List;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/11/25 11:52
 */
public interface BsCheckPlicyDeviceMapper extends BaseMapper<BsCheckPlicyDevice> {
    /**
     * 通过策略ID删除策略和标签关联
     *
     * @param plicyId 策略ID
     * @return 结果
     */
    public int deleteCheckPlicyDeviceByPlicyId(Long plicyId);

    /**
     * 通过标签ID查询标签使用数量
     *
     * @param deviceId 标签ID
     * @return 结果
     */
    public int countCheckPlicyDeviceById(Long deviceId);

    /**
     * 批量删除策略和标签关联
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteCheckPlicyDevice(Long[] ids);

    /**
     * 批量新增策略标签信息
     *
     * @param plicyDeviceList 策略角色列表
     * @return 结果
     */
    public int batchCheckPlicyDevice(List<BsCheckPlicyDevice> plicyDeviceList);


}