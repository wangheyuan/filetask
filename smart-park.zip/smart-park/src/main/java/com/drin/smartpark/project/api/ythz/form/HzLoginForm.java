/**
 * 文件名称:          	HzLoginForm
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form;

import lombok.Data;

/**
 * 登录体
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/24 16:39
 */
@Data
public class HzLoginForm {

    private String audience="token";
    private Integer not_before = 0;
    private String password = "bc79cf32e1f9d19fa3812adcbf7b94bd";
    private String subject = "website api call";
    private String username = "admin";

}
