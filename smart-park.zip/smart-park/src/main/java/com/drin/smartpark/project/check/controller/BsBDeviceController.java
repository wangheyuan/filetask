/**
 * 文件名称:          	BsBDeviceController
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.drin.smartpark.project.system.entity.SysDictData;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.service.IBsCommonDeviceService;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.page.TableDataInfo;

/**
 * 后端设备Controller
 *
 * @author wangheyuan
 * @date 2021-01-06
 */
@RestController
@RequestMapping("/check/bdevice")
public class BsBDeviceController extends BaseController
{
    @Autowired
    private IBsCommonDeviceService bsCommonDeviceService;

    /**
     * 查询后端设备列表
     */
    @RequiresPermissions("check:device:list")
    @GetMapping("/list")
    public TableDataInfo list(BsCommonDevice bsCommonDevice)
    {
        startPage();
        // 0表示只查询中心设备
        bsCommonDevice.setType("0");
        List<BsCommonDevice> list = bsCommonDeviceService.selectBsCommonDeviceList(bsCommonDevice);
        return getDataTable(list);
    }

    @RequiresPermissions("check:device:list")
    @GetMapping("/combolist")
    public RestResp comboBDeviceList() {
        BsCommonDevice bsCommonDevice = new BsCommonDevice();
        bsCommonDevice.setType("0");
        List<BsCommonDevice> dlist = bsCommonDeviceService.selectBsCommonDeviceList(bsCommonDevice);
        if(!CollectionUtils.isEmpty(dlist)) {
            List<SysDictData> dictDatas =  dlist.stream().map(d->{
                SysDictData data = new SysDictData();
                data.setDictLabel(d.getDeviceName());
                data.setDictValue(String.valueOf(d.getDeviceId()));
                return data;
            }).collect(Collectors.toList());
            return RestResp.success(dictDatas);
        }
        return RestResp.success(new ArrayList<>());
    }

    /**
     * 查询对应类型的平台列表
     */
    @RequiresPermissions("check:device:list")
    @GetMapping("/platlist")
    public RestResp platlist()
    {
        
        return RestResp.success(null);
    }

    /**
     * 查询对应类型的平台列表
     */
    @RequiresPermissions("check:device:list")
    @GetMapping("/manulist")
    public RestResp manulist()
    {

        return RestResp.success(null);
    }
    

    /**
     * 导出后端设备列表
     */
    @RequiresPermissions("check:device:export")
    @Log(title = "后端设备", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsCommonDevice bsCommonDevice)
    {
        List<BsCommonDevice> list = bsCommonDeviceService.selectBsCommonDeviceList(bsCommonDevice);
        ExcelUtil<BsCommonDevice> util = new ExcelUtil<BsCommonDevice>(BsCommonDevice.class);
        return util.exportExcel(list, "bdevice");
    }

    /**
     * 获取后端设备详细信息
     */
    @RequiresPermissions("check:device:query")
    @GetMapping(value = "/{deviceId}")
    public RestResp getInfo(@PathVariable("deviceId") Integer deviceId)
    {
        return RestResp.success(bsCommonDeviceService.selectBsCommonDeviceById(deviceId));
    }

    /**
     * 新增后端设备
     */
    @RequiresPermissions("check:device:add")
    @Log(title = "后端设备", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsCommonDevice bsCommonDevice)
    {
        // 新增的中心设备的parentId 必须为0
        bsCommonDevice.setParentId(0);
        // 创建的中心设备 状态 默认为启用
        bsCommonDevice.setStatus("0");
        return toAjax(bsCommonDeviceService.insertBsCommonDevice(bsCommonDevice));
    }

    /**
     * 修改后端设备
     */
    @RequiresPermissions("check:device:edit")
    @Log(title = "后端设备", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsCommonDevice bsCommonDevice)
    {
        return toAjax(bsCommonDeviceService.updateBsCommonDevice(bsCommonDevice));
    }

    /**
     * 删除后端设备
     */
    @RequiresPermissions("check:device:remove")
    @Log(title = "后端设备", businessType = BusinessType.DELETE)
    @DeleteMapping("/{deviceIds}")
    public RestResp remove(@PathVariable Integer[] deviceIds)
    {
        return toAjax(bsCommonDeviceService.deleteBsCommonDeviceByIds(deviceIds));
    }


}
