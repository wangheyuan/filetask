package com.drin.smartpark.project.api.zdzj.model.resp.sub;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/9/9 13:40
 * @描述: 身份证信息返回info
 */
@Data
public class SubscribeIDCardSubResp {

    //设备ID
    @JsonProperty("DeviceID")
    private String DeviceID;
    //身份证号码
    @JsonProperty("IDCard_Idno")
    private String IDCard_Idno;
    //姓名
    @JsonProperty("IDCard_Name")
    private String IDCard_Name;
    //性别
    @JsonProperty("IDCard_Gender")
    private Integer IDCard_Gender;
    //民族
    @JsonProperty("IDCard_Nation")
    private Integer IDCard_Nation;
    //生日
    @JsonProperty("IDCard_Birthday")
    private String IDCard_Birthday;
    //地址
    @JsonProperty("IDCard_Address")
    private String IDCard_Address;
    //发证机关
    @JsonProperty("IDCard_Idissue")
    private String IDCard_Idissue;
    //身份证有效期
    @JsonProperty("IDCard_Idperiod")
    private String IDCard_Idperiod;
}
