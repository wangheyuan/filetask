package com.drin.smartpark.project.check.service;

import java.util.List;

import com.drin.smartpark.project.access.entity.BsDept;
import com.drin.smartpark.project.access.entity.BsDevice;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.system.model.TreeSelect;

/**
 * 通用设备Service接口
 *
 * @author wangheyuan
 * @date 2020-11-23
 */
public interface IBsCommonDeviceService
{
    /**
     * 查询通用设备
     *
     * @param deviceId 通用设备ID
     * @return 通用设备
     */
    public BsCommonDevice selectBsCommonDeviceById(Integer deviceId);

    /**
     * 查询通用设备
     *
     * @param realId 第三方平台设备ID
     * @return 通用设备
     */
    public BsCommonDevice selectBsCommonDeviceByRealId(String realId);


    /**
     * 查询通用设备列表
     *
     * @param bsCommonDevice 通用设备
     * @return 通用设备集合
     */
    public List<BsCommonDevice> selectBsCommonDeviceList(BsCommonDevice bsCommonDevice);

    /**
     * 新增通用设备
     *
     * @param bsCommonDevice 通用设备
     * @return 结果
     */
    public int insertBsCommonDevice(BsCommonDevice bsCommonDevice);

    /**
     * 修改通用设备
     *
     * @param bsCommonDevice 通用设备
     * @return 结果
     */
    public int updateBsCommonDevice(BsCommonDevice bsCommonDevice);

    /**
     * 批量删除通用设备
     *
     * @param deviceIds 需要删除的通用设备ID
     * @return 结果
     */
    public int deleteBsCommonDeviceByIds(Integer[] deviceIds);

    /**
     * 删除通用设备信息
     *
     * @param deviceId 通用设备ID
     * @return 结果
     */
    public int deleteBsCommonDeviceById(Integer deviceId);


    /**
     * 设备构建成树状列表
     * @param deceives
     * @return java.util.List<com.drin.smartpark.project.system.model.TreeSelect>
     * @author HIPAA
     * @date 2020/11/25 10:09
     */
    public List<TreeSelect> buildDeviceTreeSelect(List<BsCommonDevice> deceives);


    /**
     * 根据策略ID获取设备选择框列表
     *
     * @param plicyId 用户ID
     * @return 选中设备ID列表
     */
    public List<Long> selectCommonDeviceIdListByPlicyId(Long plicyId);

    /**
     * 根据策略ID获取设备选择框列表详细数据
     *
     * @param plicyId 用户ID
     * @return 选中设备实体列表
     */
    public List<BsDevice> selectCommonDeviceListByPlicyId(Long plicyId);


}