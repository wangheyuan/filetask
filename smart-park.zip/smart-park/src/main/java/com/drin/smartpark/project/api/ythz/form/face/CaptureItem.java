/**
 * 文件名称:          	CaptureItem
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.face;

import lombok.Data;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 14:42
 */
@Data
public class CaptureItem {
    private CaptureResult capture_result;
    private Double similarity;
    private Long unix_timestamp_ms;
}
