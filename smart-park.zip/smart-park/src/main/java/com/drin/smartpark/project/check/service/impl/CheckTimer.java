/**
 * 文件名称:          	CheckTimer
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.service.impl;

import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.framework.util.DateUtil;
import com.drin.smartpark.project.api.common.service.CommonFaceDeviceService;
import com.drin.smartpark.project.check.dto.CheckTime;
import com.drin.smartpark.project.check.entity.*;
import com.drin.smartpark.project.check.mapper.BsStaffCaptureDayMapper;
import com.drin.smartpark.project.check.mapper.BsStaffCaptureHistoryMapper;
import com.drin.smartpark.project.check.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 负责考勤的统计
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/11/26 13:12
 */
@Component
public class CheckTimer {

    @Autowired
    private CommonFaceDeviceService faceDeviceService;

    @Autowired
    private IBsStaffCaptureHistoryService captureHistoryService;

    @Autowired
    private IBsStaffService staffService;

    @Autowired
    private BsStaffCaptureHistoryMapper staffCaptureHistoryMapper;

    @Autowired
    private IBsCheckPlicyService checkPlicyService;

    @Autowired
    private IBsStaffCaptureDayService staffCaptureDayService;

    @Autowired
    private IBsStaffCaptureMonthService staffCaptureMonthService;


    /**
     * 用于每天凌晨创建所有员工的每天考勤记录,后期放入到和策略同步的定时任务当中
     * @param
     * @return void
     * @author HIPAA
     * @date 2020/12/7 11:57
     */
//    @Scheduled(cron = "0 0 0 */1 * ?")
    @Scheduled(fixedRate = 1000*60*60,initialDelay = 5000)
    public void initCheckTodayStaffCheck() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String checkDay = sdf.format(Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()));
        Calendar cal = Calendar.getInstance();
        // 星期一为2
        int dow = cal.get(Calendar.DAY_OF_WEEK)-1;
        // 暂时设置为周末两天不统计，后面会添加对应的节假日
        if(dow == 0|| dow==6) {
            return;
        }
        // 查询所有的策略
        List<BsCheckPlicy> plicies =  checkPlicyService.selectBsCheckPlicyList(new BsCheckPlicy());
        if (CollectionUtils.isEmpty(plicies))
            return;
        plicies = plicies.stream().filter(p->{
            // 全时段的和选择的周几的需要进行考勤
            if("0".equals(p.getPlicyType())){
                return true;
            }else {
                switch (dow) {
                    case 0:
                        // 只有策略对应的天才需要处理
                        if("1".equals(p.getSunday())) {
                           return true;
                        }
                        break;
                    case 1:
                        if("1".equals(p.getMonday())) {
                            return true;
                        }
                        break;
                    case 2:
                        if("1".equals(p.getTuesday())) {
                            return true;
                        }
                        break;
                    case 3:
                        if("1".equals(p.getWednesday())) {
                            return true;
                        }
                        break;
                    case 4:
                        if("1".equals(p.getThursday())) {
                            return true;
                        }
                        break;
                    case 5:
                        if("1".equals(p.getFriday())) {
                            return true;
                        }
                        break;
                    case 6:
                        if("1".equals(p.getSaturday())) {
                            return true;
                        }
                        break;
                }
                return false;
            }

        }).collect(Collectors.toList());

        if(CollectionUtils.isEmpty(plicies))
            return;
        // 获取当天有效策略包含的员工 set 会自动去重
        Set<Long> postIdSet = new HashSet<>();
        plicies.stream().forEach(p->{
            List<Long> postIds= Arrays.asList(p.getPostIds());
            postIdSet.addAll(postIds);
        });

        if(CollectionUtils.isEmpty(postIdSet))
            return;

        List<Long> postIdList = new ArrayList<>(postIdSet);
        List<BsStaff> staffList = staffService.selectBsStaffListByPostIds(postIdList);
        if(CollectionUtils.isEmpty(staffList))
            return;

        staffList.stream().forEach(s->{
            BsStaffCaptureDay param = new BsStaffCaptureDay();
            param.setDeptId(s.getDeptId());
            param.setStaffId(s.getStaffId());
            param.setCheckDay(checkDay);
            List<BsStaffCaptureDay> days = staffCaptureDayService.selectBsStaffCaptureDayList(param);
            // 只有每天的记录没有插入的时候，才会插入，防止多次生成
            if(CollectionUtils.isEmpty(days)) {
              BsStaffCaptureDay day=  BsStaffCaptureDayByStaff(s);
              day.setCheckDay(checkDay);
              day.setNormalHour(0);
              staffCaptureDayService.insertBsStaffCaptureDay(day);
            }
        });


    }


    /**
     * 每天更新前一天的数据统计 ，定在每日凌晨
     * @param 
     * @return void
     * @author HIPAA
     * @date 2020/11/26 13:15
     */
//    @Scheduled(fixedRate = 24*60*60*1000,initialDelay = 5000)
    public void initTodayCaptureHistory() {
        // 获取当前系统所有设备
        List<BsStaffCaptureHistory> staffCaptureHistories = faceDeviceService.listStaffCaptureHistoryFromAllDevice();

        if(CollectionUtils.isEmpty(staffCaptureHistories))
            return;

        staffCaptureHistories.stream().forEach(c->{
            captureHistoryService.insertBsStaffCaptureHistory(c);
        });
    }



    /**
     * 根据抓怕记录统计每日考情的数据，
     * @param 
     * @return void
     * @author HIPAA
     * @date 2020/11/27 11:19
     */
//    @Scheduled(fixedRate = 24*60*60*1000,initialDelay = 5000)
    public void initTodayStaffCheck() {
        Calendar cal = Calendar.getInstance();
        // 星期一为2
        int dow = cal.get(Calendar.DAY_OF_WEEK);
        // 暂时设置为周末两天不统计，后面会添加对应的节假日
        if(dow == 1|| dow==2) {
            return;
        }

        System.out.println("-----------------开始执行昨天的考勤任务-----------------------------");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String checkDay = sdf.format(Date.from(LocalDate.now().minusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant()));

        List<BsCheckPlicy> plicies =  checkPlicyService.selectBsCheckPlicyList(new BsCheckPlicy());
        if (CollectionUtils.isEmpty(plicies))
            return;

        Map<Long, CheckTime> labelTimeMap = new HashMap<>();

        Map<Long,List<Long>> labelDeviceMap = new HashMap<>();

        // 初始化标签  设备  上班时间  下班时间之间的关联
        plicies.stream().forEach(p->{
            Long[] labels = p.getPostIds();
            Long[] devices = p.getDeviceIds();
            if(labels!=null&& labels.length>0) {
                for (int i = 0; i < labels.length; i++) {
                    long label = labels[i];
                    // 防止策略中 出现一个标签  在两个考勤里面，取范围最大的考勤
                    if(labelTimeMap.containsKey(label)) {
                        CheckTime old =  labelTimeMap.get(label);
                        if(p.getStartTime().isAfter(old.getStartTime())){
                            p.setStartTime(old.getStartTime());
                        }
                        if(p.getFinishTime().isBefore(old.getFinishTime())) {
                            p.setFinishTime(old.getFinishTime());
                        }
                    }

                    CheckTime checkTime = new CheckTime();
                    checkTime.setStartTime(p.getStartTime());
                    checkTime.setFinishTime(p.getFinishTime());
                    labelTimeMap.put(label,checkTime);

                    // 每个标签把对应的设备添加
                    if(devices!=null && devices.length>0) {
                        List<Long> deviceIds = Arrays.asList(devices);
                        labelDeviceMap.put(label,deviceIds);
                    }
                }
            }
        });


        System.out.println(labelTimeMap);

        List<BsStaff> staffList = staffService.selectBsStaffList(new BsStaff());
        if(CollectionUtils.isEmpty(staffList))
            return;
        staffList.stream().forEach(s->{

            //插入每日考勤记录
            BsStaffCaptureDay  day = new BsStaffCaptureDay();
            day.setImageId(s.getImageId());
            day.setStaffCard(s.getStaffCard());
            day.setStaffId(s.getStaffId());
            day.setStaffName(s.getStaffName());
           //
            day.setCheckDay(checkDay);

            // 获取员工抓拍记录
            List<BsStaffCaptureHistory>  histories = getYesterdayStaffCaptureHistory(s.getStaffId());
            if(CollectionUtils.isEmpty(histories))
                return;

            // 统计抓拍的第一张照片 和 最后一张照片
            BsStaffCaptureHistory first = histories.get(0);
            day.setInTime(first.getCreateTime());

            LocalTime firstTime = DateUtils.getLocalTimeByDate(first.getCreateTime());

            LocalTime endTime = null;
                    BsStaffCaptureHistory end = null;
            if(histories.size()>1) {
                end = histories.get(histories.size()-1);
                day.setOutTime(end.getCreateTime());
                endTime = DateUtils.getLocalTimeByDate(end.getCreateTime());
            }

            if(firstTime!=null && endTime !=null) {
                int hour = endTime.getHour() - firstTime.getHour();
                day.setNormalHour(hour);
            }

            Long[] labels = s.getPostIds();
            if(labels!=null && labels.length>0) {
                for (int i = 0; i < labels.length; i++) {
                    // 每个人只允许拥有一个考勤标签
                    System.out.println(labels[i]);
                    if(labelTimeMap.containsKey(labels[i])) {
                        System.out.println("----------------enter----------------");
                        CheckTime checkTime = labelTimeMap.get(labels[i]);
                        LocalTime checkStartTime = checkTime.getStartTime();
                        LocalTime checkFinishTime  = checkTime.getFinishTime();
                        StringBuffer sb = new StringBuffer();
                        day.setStatus("0");
                        if(firstTime.isAfter(checkStartTime)) {
                            // 早退或者迟到都是异常
                            day.setStatus("1");
                            sb.append("迟到 ");
                        }
                        if(endTime.isBefore(checkFinishTime)) {
                            day.setStatus("1");
                            sb.append("早退 ");
                        }
                        day.setRemark(sb.toString());
                        break;
                    }
                }

                System.out.println("开始录入考勤");
                staffCaptureDayService.insertBsStaffCaptureDay(day);
            }
        });

    }

    // 每月末。晚上 11点进行处理月报表
    //@Scheduled(fixedRate = 24*60*60*1000,initialDelay = 30000)
    public void initMonthStaffCheck() {

        List<BsStaff> staffList = staffService.selectBsStaffList(new BsStaff());
        if(CollectionUtils.isEmpty(staffList))
            return;

        Calendar cal = Calendar.getInstance();
        // 当前月，当前月月进行处理
        int month = cal.get(Calendar.MONTH) + 1;
        int year = cal.get(Calendar.YEAR);
        String mon = String.format("%02d", month);
        String dateStr =  year+"-"+month;

       // 遍历所有员工进行统计月报表
        staffList.stream().forEach(s->{
            BsStaffCaptureDay param  = new BsStaffCaptureDay();
            //时间字符串的查询是模糊查询
            param.setCheckDay(dateStr);
            param.setStaffId(s.getStaffId());
            List<BsStaffCaptureDay> allday = staffCaptureDayService.selectBsStaffCaptureDayList(param);
            BsStaffCaptureMonth captureMonth = staffCaptureMonth(allday,s);
            captureMonth.setCheckMonth(dateStr);

            // 新增一个月的的记录
            staffCaptureMonthService.insertBsStaffCaptureMonth(captureMonth);

        });

    }

    /**
     * 根据当月的日统计进行统计一个月的考勤结果
     * @return com.drin.smartpark.project.check.entity.BsStaffCaptureMonth
     * @author HIPAA
     * @date 2020/11/30 10:14
     */
    private BsStaffCaptureMonth staffCaptureMonth(List<BsStaffCaptureDay> allDay,BsStaff staff) {
        Calendar cal = Calendar.getInstance();
        int dom = cal.get(Calendar.DAY_OF_MONTH);
        BsStaffCaptureMonth captureMonth = new BsStaffCaptureMonth();
        captureMonth.setStaffId(staff.getStaffId());
        captureMonth.setImageId(staff.getImageId());
        captureMonth.setStaffCard(staff.getStaffCard());
        captureMonth.setStaffName(staff.getStaffName());
        if (CollectionUtils.isEmpty(allDay)) {
            // 如果一天都没有说明是新入职员工，现实中正常
            captureMonth.setErrorDay(0);
            captureMonth.setStatus("0");
            return null;
        }
        int nomalDays = 0;
        int errorDays = 0;
        for (int i = 0; i < allDay.size(); i++) {
            BsStaffCaptureDay day = allDay.get(i);
            if("0".equals(day.getStatus())) {
                nomalDays++;
            }else {
                errorDays++;
            }
        }
        if (errorDays==0) {
            captureMonth.setStatus("0");
        }else{
            captureMonth.setStatus("1");
        }
        captureMonth.setErrorDay(errorDays);
        captureMonth.setNormalDay(nomalDays);

        return captureMonth;
    }


    /**
     * 根据员工id获取抓拍记录列表
     * @param staffId
     * @return java.util.List<com.drin.smartpark.project.check.entity.BsStaffCaptureHistory>
     * @author HIPAA
     * @date 2020/11/27 13:37
     */
    private List<BsStaffCaptureHistory> getYesterdayStaffCaptureHistory(Long staffId) {
        BsStaffCaptureHistory param = new BsStaffCaptureHistory();
        param.setStaffId(staffId);
        // 取昨天的日期
        LocalDate localDate = LocalDate.now().minusDays(1);
        Date now = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        param.setCreateTime(now);
        List<BsStaffCaptureHistory> histories = staffCaptureHistoryMapper.selectBsStaffCaptureHistoryList(param);
        if(!CollectionUtils.isEmpty(histories)) {
            histories.sort(new Comparator<BsStaffCaptureHistory>() {
                @Override
                public int compare(BsStaffCaptureHistory o1, BsStaffCaptureHistory o2) {
                    if(o2.getCreateTime().after(o1.getCreateTime())){
                        return -1;
                    }else {
                        return 1;
                    }

                }
            });
        }
        return histories;
    }


    private BsStaffCaptureDay BsStaffCaptureDayByStaff(BsStaff staff) {
        BsStaffCaptureDay day = new BsStaffCaptureDay();
        day.setStaffId(staff.getStaffId());
        day.setImageId(staff.getImageId());
        day.setStaffCard(staff.getStaffCard());
        day.setStaffName(staff.getStaffName());
        day.setDeptId(staff.getDeptId());
        // 默认考勤状态为异常
        day.setStatus("1");
        return day;

    }

    
}
