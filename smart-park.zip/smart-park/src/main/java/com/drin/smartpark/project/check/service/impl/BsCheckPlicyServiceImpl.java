/**
 * 文件名称:          	BsCheckPlicyServiceImpl
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.service.impl;

import com.drin.smartpark.common.exception.job.TaskException;
import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.common.tool.SecurityUtils;
import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.project.access.entity.*;
import com.drin.smartpark.project.access.mapper.BsPlicyDeviceMapper;
import com.drin.smartpark.project.access.mapper.BsPlicyPostMapper;
import com.drin.smartpark.project.access.service.IBsDeviceService;
import com.drin.smartpark.project.access.service.IBsVisitorService;
import com.drin.smartpark.project.api.zdzj.service.FaceService;
import com.drin.smartpark.project.check.dto.QueryCheckPlicyParam;
import com.drin.smartpark.project.check.entity.BsCheckPlicy;
import com.drin.smartpark.project.check.entity.BsCheckPlicyDept;
import com.drin.smartpark.project.check.entity.BsCheckPlicyDevice;
import com.drin.smartpark.project.check.mapper.BsCheckPlicyDeptMapper;
import com.drin.smartpark.project.check.mapper.BsCheckPlicyDeviceMapper;
import com.drin.smartpark.project.check.mapper.BsCheckPlicyMapper;
import com.drin.smartpark.project.check.mapper.BsCheckPlicyPostMapper;
import com.drin.smartpark.project.check.service.IBsCheckPlicyService;
import com.drin.smartpark.project.check.service.IBsCommonDeviceService;
import com.drin.smartpark.project.check.service.IBsStaffDeptService;
import com.drin.smartpark.project.check.service.IBsStaffPostService;
import com.drin.smartpark.project.system.service.SysPostService;
import com.drin.smartpark.quartz.entity.SysJob;
import com.drin.smartpark.quartz.mapper.SysJobMapper;
import com.drin.smartpark.quartz.service.impl.SysJobServiceImpl;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 策略列Service业务层处理
 * <p>
 * Version		1.0.0
 *
 * @author wangheyuan
 * <p>
 * Date	      2020/11/25 14:04
 */
@Service
public class BsCheckPlicyServiceImpl implements IBsCheckPlicyService
{
    @Autowired
    private BsCheckPlicyMapper bsCheckPlicyMapper;

    @Autowired
    private BsCheckPlicyPostMapper plicyPostMapper;

    @Autowired
    private BsCheckPlicyDeviceMapper plicyDeviceMapper;

    @Autowired
    private IBsStaffPostService postService;

    @Autowired
    private IBsCommonDeviceService deviceService;

    @Autowired
    private SysJobServiceImpl sysJobService;

    @Autowired
    private IBsVisitorService visitorService;

    @Autowired
    private FaceService faceService;

    @Autowired
    private SysJobMapper jobMapper;

    @Autowired
    private BsCheckPlicyDeptMapper plicyDeptMapper;

    @Autowired
    private IBsStaffDeptService deptService;

    /**
     * 查询策略列
     *
     * @param plicyId 策略列ID
     * @return 策略列
     */
    @Override
    public BsCheckPlicy selectBsCheckPlicyById(Long plicyId)
    {
        return bsCheckPlicyMapper.selectBsCheckPlicyById(plicyId);
    }

    /**
     * 查询策略列列表
     *
     * @param bsCheckPlicy 策略列
     * @return 策略列
     */
    @Override
    public List<BsCheckPlicy> selectBsCheckPlicyList(BsCheckPlicy bsCheckPlicy)
    {
        List<BsCheckPlicy> list = bsCheckPlicyMapper.selectBsCheckPlicyList(bsCheckPlicy);
        if(!CollectionUtils.isEmpty(list)) {
            list.stream().forEach(p->{
                //初始化标签信息
                List<Long> postIds = postService.selectStaffPostListByPlicyId(p.getPlicyId());
                if(!CollectionUtils.isEmpty(postIds)) {
                    Long[] posts = new Long[postIds.size()];
                    postIds.toArray(posts);
                    p.setPostIds(posts);
                }
                // 初始化设备信息
                List<Long> deviceIds = deviceService.selectCommonDeviceIdListByPlicyId(p.getPlicyId());
                if(!CollectionUtils.isEmpty(deviceIds)) {
                    Long[] devices = new Long[deviceIds.size()];
                    deviceIds.toArray(devices);
                    p.setDeviceIds(devices);
                }
                // 初始化部门信息
                List<Long> deptIds = deptService.selectBsCheckPlicyDeptListByPlicyId(p.getPlicyId());
                if(!CollectionUtils.isEmpty(deptIds)) {
                    Long[] depts = new Long[deptIds.size()];
                    deptIds.toArray(depts);
                    p.setDeptIds(depts);
                }

            });

        }
        return list;
    }

    /**
     * 查询策略列
     *
     * @param param
     * @return 策略列
     */
    @Override
    public List<BsCheckPlicy> selectBsCheckPlicyByParam(QueryCheckPlicyParam param) {
        // 考虑到现在distinct性能比较差，所以用两部分查询
        List<Long> plicyIds = bsCheckPlicyMapper.selectBsCheckPlicyByParam(param);
        List<BsCheckPlicy> checkPlicies = bsCheckPlicyMapper.selectBsCheckPlicyListByIds(plicyIds);
        return checkPlicies;
    }

    /**
     * 新增策略列  （新增策略添加，并增加对应的定时任务）
     *
     * @param bsCheckPlicy 策略列
     * @return 结果
     */
    @Override
    public Long insertBsCheckPlicy(BsCheckPlicy bsCheckPlicy)
    {
        bsCheckPlicy.setCreateTime(DateUtils.getNowDate());
        bsCheckPlicyMapper.insertBsCheckPlicy(bsCheckPlicy);
        //插入标签
        insertPlicyPost(bsCheckPlicy);
        //插入设备
        insertPlicyDevice(bsCheckPlicy);
        //插入部门
        insertPlicyDept(bsCheckPlicy);
        // 增加定时任务 只有按照周进行设置的，需要更换白名单的内容
        // 需要增加两个定时任务，一个是导入图片一个是删除图片
        createJobByPlicy(bsCheckPlicy);
        startJobPlicy(bsCheckPlicy);
        return bsCheckPlicy.getPlicyId();
    }

    private void createJobByPlicy(BsCheckPlicy plicy) {
        if("1".equals(plicy.getPlicyType())) {
            SysJob startJob = importVisitorJob(plicy);
            SysJob finishJob = clearVisitorJob(plicy);
            try {
                // 创建任务
                sysJobService.insertJob(startJob);
                sysJobService.insertJob(finishJob);
                //只有策略是启动的时候才可以把任务的状态更新
                if("0".equals(plicy.getPlicyStatus())) {
                    // 更新任务状态
                    SysJob newJob1 = sysJobService.selectJobById(startJob.getJobId());
                    newJob1.setStatus("0");
                    sysJobService.changeStatus(newJob1);
                    SysJob newJob2 = sysJobService.selectJobById(finishJob.getJobId());
                    newJob1.setStatus("0");
                    sysJobService.changeStatus(newJob2);
                }
            } catch (SchedulerException e) {
                e.printStackTrace();
            } catch (TaskException e) {
                e.printStackTrace();
            }
        }
    }

    private void startJobPlicy(BsCheckPlicy plicy) {
        // 查询策略对应的访客 和 设备
        List<BsVisitor> visitors = visitorService.selectBsVisitorListByPlicyId(plicy.getPlicyId());
        List<BsDevice> devices = deviceService.selectCommonDeviceListByPlicyId(plicy.getPlicyId());
        // 只有策略是启动的时候才进行导入操作
        if( "0".equals(plicy.getPlicyStatus()) && isValidToday(plicy)){
            //全局的job 直接创建对应的白名单 如果名单不存在导入到对应的
            faceService.addVisitorListToDevice(visitors,devices);
        }else {
            faceService.deleteVisitorListFormDevice(visitors,devices);
        }
    }

    private String cronStartStr(BsCheckPlicy plicy) {
        LocalTime startTime = plicy.getStartTime();
        int hour = startTime.get(ChronoField.HOUR_OF_DAY);
        int minute = startTime.getMinute();
        int second = startTime.getSecond();
        StringBuilder sb = new StringBuilder();
        if("1".equals(plicy.getMonday())) {
            sb.append("1,");
        }
        if("1".equals(plicy.getTuesday())) {
            sb.append("2,");
        }
        if("1".equals(plicy.getWednesday())) {
            sb.append("3,");
        }
        if("1".equals(plicy.getThursday())) {
            sb.append("4,");
        }
        if("1".equals(plicy.getFriday())) {
            sb.append("5,");
        }
        if("1".equals(plicy.getSaturday())) {
            sb.append("6,");
        }
        if("1".equals(plicy.getSunday())) {
            sb.append("7,");
        }
        String week = sb.toString().substring(0,sb.toString().length()-1);
        String cron = second+" "+minute+" "+hour+" "+"?"+" "+"*"+" "+week+" "+"*";
        System.out.println(cron);
        return cron;
    }

    private String cronFinishStr(BsCheckPlicy plicy) {
        LocalTime finishTime = plicy.getFinishTime();
        int hour = finishTime.get(ChronoField.HOUR_OF_DAY);
        int minute = finishTime.getMinute();
        int second = finishTime.getSecond();
        StringBuilder sb = new StringBuilder();
        if("1".equals(plicy.getMonday())) {
            sb.append("1,");
        }
        if("1".equals(plicy.getTuesday())) {
            sb.append("2,");
        }
        if("1".equals(plicy.getWednesday())) {
            sb.append("3,");
        }
        if("1".equals(plicy.getThursday())) {
            sb.append("4,");
        }
        if("1".equals(plicy.getFriday())) {
            sb.append("5,");
        }
        if("1".equals(plicy.getSaturday())) {
            sb.append("6,");
        }
        if("1".equals(plicy.getSunday())) {
            sb.append("7,");
        }
        String week = sb.toString().substring(0,sb.toString().length()-1);
        String cron = second+" "+minute+" "+hour+" "+"?"+" "+"*"+" "+week+" "+"*";
        System.out.println(cron);
        return cron;
    }

    private SysJob importVisitorJob(BsCheckPlicy plicy) {
        SysJob job =new SysJob();
        // 0 为运行中  1 为停用
        job.setStatus("0");
        job.setJobName(plicy.getPlicyName());
        job.setJobGroup(String.valueOf(plicy.getPlicyId()));
        job.setInvokeTarget("ryTask.vistImportPerson("+plicy.getPlicyId()+"L)");
        job.setCronExpression(cronStartStr(plicy));
        // 1位立即执行 2 为执行一次 3为放弃执行
        job.setMisfirePolicy("3");
        //0 允许并发  1 为 禁止并发
        job.setConcurrent("0");
        //
        job.setCreateBy(SecurityUtils.getUsername());
        job.setCreateTime(new Date());
        job.setRemark(plicy.getRemark());
        return job;
    }

    private SysJob clearVisitorJob(BsCheckPlicy plicy) {
        SysJob job =new SysJob();
        // 0 为运行中  1 为停用
        job.setStatus("0");
        job.setJobName(plicy.getPlicyName());
        job.setJobGroup(String.valueOf(plicy.getPlicyId()));
        job.setInvokeTarget("ryTask.vistRemovePerson("+plicy.getPlicyId()+"L)");
        job.setCronExpression(cronFinishStr(plicy));
        // 1位立即执行 2 为执行一次 3为放弃执行
        job.setMisfirePolicy("3");
        //0 允许并发  1 为 禁止并发
        job.setConcurrent("0");
        //
        job.setCreateBy(SecurityUtils.getUsername());
        job.setCreateTime(new Date());
        job.setRemark(plicy.getRemark());

        return job;
    }

    /**
     * 插入策略设备
     * @param bsCheckPlicy
     * @return void
     * @author HIPAA
     * @date 2020/9/4 4:43
     */
    private void insertPlicyDevice(BsCheckPlicy bsCheckPlicy) {
        Long[] devices = bsCheckPlicy.getDeviceIds();
        if(StringUtils.isNotNull(devices)) {
            List<BsCheckPlicyDevice> list = new ArrayList<>();
            for (Long deviceId : devices) {
                BsCheckPlicyDevice up = new BsCheckPlicyDevice();
                up.setPlicyId(bsCheckPlicy.getPlicyId());
                up.setDeviceId(deviceId);
                list.add(up);
            }
            if(list.size()>0) {
                plicyDeviceMapper.batchCheckPlicyDevice(list);
            }
        }
    }

    /**
     * 插入策略标签
     * @param bsCheckPlicy
     * @return void
     * @author HIPAA
     * @date 2020/9/4 4:42
     */
    private void insertPlicyPost(BsCheckPlicy bsCheckPlicy) {
        Long[] posts = bsCheckPlicy.getPostIds();
        if(StringUtils.isNotNull(posts)) {
            List<BsPlicyPost> list = new ArrayList<>();
            for (Long postId : posts) {
                BsPlicyPost up = new BsPlicyPost();
                up.setPlicyId(bsCheckPlicy.getPlicyId());
                up.setPostId(postId);
                list.add(up);
            }
            if(list.size()>0) {
                plicyPostMapper.batchCheckPlicyPost(list);
            }
        }
    }

    private void insertPlicyDept(BsCheckPlicy bsCheckPlicy) {
        Long[] depts = bsCheckPlicy.getDeptIds();
        if(depts!=null) {
            List<BsCheckPlicyDept> list = new ArrayList<>();
            for(Long deptId:depts) {
                BsCheckPlicyDept up = new BsCheckPlicyDept();
                up.setPlicyId(bsCheckPlicy.getPlicyId());
                up.setDeptId(deptId);
                list.add(up);
            }
            if(!CollectionUtils.isEmpty(list)) {
                plicyDeptMapper.batchCheckPlicyDept(list);
            }
        }
    }

    /**
     * 修改策略列
     *
     * @param bsCheckPlicy 策略列
     * @return 结果
     */
    @Override
    public int updateBsCheckPlicy(BsCheckPlicy bsCheckPlicy)
    {
        Long plicyId = bsCheckPlicy.getPlicyId();
        // 删除标签和设备
        plicyPostMapper.deleteCheckPlicyPostByPlicyId(plicyId);
        plicyDeviceMapper.deleteCheckPlicyDeviceByPlicyId(plicyId);
        plicyDeptMapper.deleteCheckPlicyDeptByPlicyId(plicyId);
        // 新增标签和设备
        insertPlicyPost(bsCheckPlicy);
        insertPlicyDevice(bsCheckPlicy);
        insertPlicyDept(bsCheckPlicy);
        bsCheckPlicy.setUpdateTime(DateUtils.getNowDate());
        // 执行策略
        startJobPlicy(bsCheckPlicy);
        return bsCheckPlicyMapper.updateBsCheckPlicy(bsCheckPlicy);
    }

    /**
     * 批量删除策略列
     *
     * @param plicyIds 需要删除的策略列ID
     * @return 结果
     */
    @Override
    public int deleteBsCheckPlicyByIds(Long[] plicyIds)
    {
        // 删除标签和设备和部门
        plicyPostMapper.deleteCheckPlicyPost(plicyIds);
        plicyDeviceMapper.deleteCheckPlicyDevice(plicyIds);
        plicyDeptMapper.deleteCheckPlicyDeptByPlicyIds(plicyIds);
        // 删除定时任务
        List<String> plicyStrIds = new ArrayList<>();
        for (Long plicyId : plicyIds) {
            plicyStrIds.add(String.valueOf(plicyId));
        }
        jobMapper.deleteJobByGroupNames(plicyStrIds);
        // 清理定时任务对应的人员
        List<BsVisitor> visitors = visitorService.selectAllValidVisitorList();
        //获取系统的当前人员，然后做筛选，将对应的人删除
        return bsCheckPlicyMapper.deleteBsCheckPlicyByIds(plicyIds);
    }

    /**
     * 删除策略列信息
     *
     * @param plicyId 策略列ID
     * @return 结果
     */
    @Override
    public int deleteBsCheckPlicyById(Long plicyId)
    {
        // 删除标签和设备
        plicyPostMapper.deleteCheckPlicyPostByPlicyId(plicyId);
        plicyDeviceMapper.deleteCheckPlicyDeviceByPlicyId(plicyId);
        plicyDeptMapper.deleteCheckPlicyDeptByPlicyId(plicyId);
        // 删除定时任务
        jobMapper.deleteJobByGroupName(String.valueOf(plicyId));
        // 清理定时任务对应的人员
        List<BsVisitor> visitors = visitorService.selectAllValidVisitorList();

        return bsCheckPlicyMapper.deleteBsCheckPlicyById(plicyId);
    }

    /**
     * 判断当天是否是在政策内，是否需要导入新的人员，删除对应的人员
     *
     * @param plicy
     * @return boolean
     * @author HIPAA
     * @date 2020/9/8 10:55
     */
    @Override
    public boolean isValidToday(BsCheckPlicy plicy) {
        //0 为全天制，直接导入，1为周制，需要判断当天是否合理
        if(plicy.getPlicyType()=="0") {
            return  true;
        }
        LocalDateTime localDateTime = LocalDateTime.now();
        if(plicy.getStartTime()!=null && plicy.getEndTime()!=null) {
            if(localDateTime.toLocalTime().compareTo(plicy.getStartTime())>0 && localDateTime.toLocalTime().compareTo(plicy.getFinishTime())<0) {
                //时间在通行时间内就导入
                if(isValidWeek(localDateTime.getDayOfWeek(),plicy)){
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isValidWeek(DayOfWeek week, BsCheckPlicy plicy) {
        boolean flag = false;
        switch (week) {
            case MONDAY:
                if("1".equals(plicy.getMonday())) {
                    flag = true;
                }
                break;
            case TUESDAY:
                if("1".equals(plicy.getTuesday())) {
                    flag = true;
                }
                break;
            case WEDNESDAY:
                if("1".equals(plicy.getWednesday())) {
                    flag = true;
                }
                break;
            case THURSDAY:
                if("1".equals(plicy.getThursday())) {
                    flag = true;
                }
                break;
            case FRIDAY:
                if("1".equals(plicy.getFriday())) {
                    flag = true;
                }
                break;
            case SATURDAY:
                if("1".equals(plicy.getSaturday())) {
                    flag = true;
                }
                break;
            case SUNDAY:
                if("1".equals(plicy.getSunday())) {
                    flag = true;
                }
                break;
        }
        return flag;
    }

}