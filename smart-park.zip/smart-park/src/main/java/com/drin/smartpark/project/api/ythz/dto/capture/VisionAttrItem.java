/**
 * 文件名称:          	VisionAttrItem
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.dto.capture;

import lombok.Data;

/**
 * 记录抓拍的特征项
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/31 10:52
 */
@Data
public class VisionAttrItem {
    private String type_;
    private String value;
    private Double confidence;
}
