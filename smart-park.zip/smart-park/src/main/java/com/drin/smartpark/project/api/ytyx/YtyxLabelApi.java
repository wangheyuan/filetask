/**
 * 文件名称:          	LabelApi
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx;


import com.drin.smartpark.project.api.ytyx.dto.YtyxRestResp;
import com.drin.smartpark.project.api.ytyx.model.label.LabelForm;
import com.drin.smartpark.project.api.ytyx.model.label.LabelModel;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

import java.util.List;

/**
 * 标签相关api
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/17 13:28
 */
public interface YtyxLabelApi {

    //获取标签
    @GET("park/website/tags?page=0&size=0")
    Call<YtyxRestResp<List<LabelModel>>> labels();

    //添加标签
    @POST("park/website/tags")
    Call<YtyxRestResp<List<LabelModel>>> addLabels(@Body LabelForm param);


}