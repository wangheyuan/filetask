package com.drin.smartpark.project.check.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.drin.smartpark.common.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.drin.smartpark.framework.excel.annotation.Excel;

import java.util.ArrayList;
import java.util.List;

/**
 * 通用设备对象 bs_common_device
 *
 * @author wangheyuan
 * @date 2020-11-23
 */
public class BsCommonDevice extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    @TableField(exist = false)
    //type =0 为平台设备， type =1 为前端设备
    private String type;
    /** 编码 */
    private Integer deviceId;

    /** 名称 */
    @Excel(name = "名称")
    private String deviceName;

    /** 设备ip */
    @Excel(name = "设备ip")
    private String deviceIp;

    /** 设备账号 */
    @Excel(name = "设备账号")
    private String account;

    /** 设备密码 */
    @Excel(name = "设备密码")
    private String password;

    /** 设备类型 */
    @Excel(name = "设备类型")
    private String deviceType;

    /** 设备状态 */
    @Excel(name = "设备状态")
    private String status;

    /** 第三方设备id */
    private String realId;

    /** 父设备ID */
    private Integer parentId;

    /** 子设备 */
    private List<BsCommonDevice> children = new ArrayList<>();

    /** 显示顺序 */
    private String orderNum;

    public void setDeviceId(Integer deviceId)
    {
        this.deviceId = deviceId;
    }

    public Integer getDeviceId()
    {
        return deviceId;
    }
    public void setDeviceName(String deviceName)
    {
        this.deviceName = deviceName;
    }

    public String getDeviceName()
    {
        return deviceName;
    }
    public void setDeviceIp(String deviceIp)
    {
        this.deviceIp = deviceIp;
    }

    public String getDeviceIp()
    {
        return deviceIp;
    }
    public void setAccount(String account)
    {
        this.account = account;
    }

    public String getAccount()
    {
        return account;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }

    public String getPassword()
    {
        return password;
    }
    public void setDeviceType(String deviceType)
    {
        this.deviceType = deviceType;
    }

    public String getDeviceType()
    {
        return deviceType;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }
    public void setRealId(String realId)
    {
        this.realId = realId;
    }

    public String getRealId()
    {
        return realId;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public List<BsCommonDevice> getChildren() {
        return children;
    }

    public void setChildren(List<BsCommonDevice> children) {
        this.children = children;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("deviceId", getDeviceId())
                .append("deviceName", getDeviceName())
                .append("parentId", getParentId())
                .append("deviceIp", getDeviceIp())
                .append("account", getAccount())
                .append("password", getPassword())
                .append("deviceType", getDeviceType())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("realId", getRealId())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("remark", getRemark())
                .toString();
    }
}