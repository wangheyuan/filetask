package com.drin.smartpark.framework.shiro.service;

import com.drin.smartpark.common.constant.Constants;
import com.drin.smartpark.common.service.RedisCache;
import com.drin.smartpark.framework.manager.AsyncManager;
import com.drin.smartpark.framework.manager.factory.AsyncFactory;
import com.drin.smartpark.framework.util.MessageUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 登录校验方法
 * 
 * @author wangheyuan
 */
@Component
public class SysLoginService
{
    @Autowired
    private TokenService tokenService;

    @Autowired
    private RedisCache redisCache;

    /**
     * 登录验证
     * 
     * @param username 用户名
     * @param password 密码
     * @param code 验证码
     * @param uuid 唯一标识
     * @return 结果
     */
    public String login(String username, String password, String code, String uuid)
    {
        // 用户验证
        String epassword = new Md5Hash(password,username,3).toString();  //1.密码，盐，加密次数
        UsernamePasswordToken upToken = new UsernamePasswordToken(username,epassword);
        //2.获取subject
        Subject subject = SecurityUtils.getSubject();
        //3.调用login方法，进入realm完成认证
        subject.login(upToken);
        //4.获取sessionId
        String token = (String)subject.getSession().getId();

        AsyncManager.me().execute(AsyncFactory.recordLogininfor(username, Constants.LOGIN_SUCCESS, MessageUtils.message("user.login.success")));
//        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        return token;
    }
}
