package com.drin.smartpark.project.access.service.impl;

import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.project.access.entity.BsDevice;
import com.drin.smartpark.project.access.mapper.BsDeviceMapper;
import com.drin.smartpark.project.access.service.IBsDeviceService;
import com.drin.smartpark.project.api.zdzj.service.FaceRetrofitService;
import com.drin.smartpark.project.api.zdzj.service.FaceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * 门禁设备Service业务层处理
 *
 * @author wangheyuan
 * @date 2020-09-01
 */
@Slf4j
@Service
public class BsDeviceServiceImpl implements IBsDeviceService
{
    @Autowired
    private BsDeviceMapper bsDeviceMapper;

    @Autowired
    private FaceService faceService;

    @Autowired
    private FaceRetrofitService retrofitService;

    /**
     * 查询门禁设备
     *
     * @param deviceId 门禁设备ID
     * @return 门禁设备
     */
    @Override
    public BsDevice selectBsDeviceById(Integer deviceId)
    {
        return bsDeviceMapper.selectBsDeviceById(deviceId);
    }

    /**
     * 查询门禁设备列表
     *
     * @param bsDevice 门禁设备
     * @return 门禁设备
     */
    @Override
    public List<BsDevice> selectBsDeviceList(BsDevice bsDevice)
    {
        List<BsDevice> result = bsDeviceMapper.selectBsDeviceList(bsDevice);
        //每次刷新判断设备信息是否正确
        if(!CollectionUtils.isEmpty(result)) {
            result.stream().forEach(device -> {
                String realId = faceService.getDeviceId(device);
                //闸机对应的id变化
                if(!device.getRealId().equals(realId)) {
                    device.setRealId(realId);
                    bsDeviceMapper.updateBsDevice(device);
                }
            });
        }
        //输出最终的设备状态
        result = bsDeviceMapper.selectBsDeviceList(bsDevice);
        return result;
    }

    /**
     * 新增门禁设备
     *
     * @param bsDevice 门禁设备
     * @return 结果
     */
    @Override
    public int insertBsDevice(BsDevice bsDevice)
    {
        bsDevice.setCreateTime(DateUtils.getNowDate());
        int result = bsDeviceMapper.insertBsDevice(bsDevice);
        refreshDeviceRealId(bsDevice);
        return result;
    }

    /**
     * 修改门禁设备
     *
     * @param bsDevice 门禁设备
     * @return 结果
     */
    @Override
    public int updateBsDevice(BsDevice bsDevice)
    {
        //修改设备需要重新初始化设备信息
        retrofitService.clearReftrofitByBsDevice(bsDevice);
        bsDevice.setUpdateTime(DateUtils.getNowDate());
        int result = bsDeviceMapper.updateBsDevice(bsDevice);
        refreshDeviceRealId(bsDevice);
        return result;
    }

    /**
     * 批量删除门禁设备
     *
     * @param deviceIds 需要删除的门禁设备ID
     * @return 结果
     */
    @Override
    public int deleteBsDeviceByIds(Integer[] deviceIds)
    {
        //删除设备移除retrofit信息
        for (int i = 0; i < deviceIds.length; i++) {
            BsDevice device = bsDeviceMapper.selectBsDeviceById(deviceIds[i]);
            retrofitService.clearReftrofitByBsDevice(device);
        }
        return bsDeviceMapper.deleteBsDeviceByIds(deviceIds);
    }

    /**
     * 删除门禁设备信息
     *
     * @param deviceId 门禁设备ID
     * @return 结果
     */
    @Override
    public int deleteBsDeviceById(Integer deviceId)
    {
        BsDevice device = bsDeviceMapper.selectBsDeviceById(deviceId);
        retrofitService.clearReftrofitByBsDevice(device);
        return bsDeviceMapper.deleteBsDeviceById(deviceId);
    }

    /**
     * 根据策略ID获取设备选择框列表
     *
     * @param plicyId 用户ID
     * @return 选中设备ID列表
     */
    @Override
    public List<Long> selectDeviceIdListByPlicyId(Long plicyId)
    {
        return bsDeviceMapper.selectDeviceIdListByPlicyId(plicyId);
    }

    @Override
    public List<BsDevice> selectDeviceListByPlicyId(Long plicyId) {
        List<BsDevice> bsDevices = bsDeviceMapper.selectDeviceListByPlicyId(plicyId);
        return bsDevices;
    }
    
    /**
     * 根据设备信息更新realId
     * @param bsDevice
     * @return void
     * @author HIPAA
     * @date 2020/9/9 23:49
     */
    private void refreshDeviceRealId(BsDevice bsDevice) {
        //创建设备完成后，需要初始化设备信息
        retrofitService.tempInitDeviceService(bsDevice);
        String realId = faceService.getDeviceId(bsDevice);
        bsDevice.setRealId(realId);
        bsDeviceMapper.updateBsDevice(bsDevice);
        retrofitService.init();
    }
}