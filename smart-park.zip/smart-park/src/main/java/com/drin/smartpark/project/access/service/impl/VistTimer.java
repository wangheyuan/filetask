/**
 * 文件名称:          	VistTimer
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.access.service.impl;

import com.drin.smartpark.common.config.VistConfig;
import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.framework.config.ServerConfig;
import com.drin.smartpark.framework.util.JsonMapper;
import com.drin.smartpark.framework.util.MapUtil;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.access.entity.BsVisitorHistory;
import com.drin.smartpark.project.api.ythz.FaceApi;
import com.drin.smartpark.project.api.ythz.FaceRecordApi;
import com.drin.smartpark.project.api.ythz.config.Constant;
import com.drin.smartpark.project.api.ythz.dto.RetrievalRecordDto;
import com.drin.smartpark.project.api.ythz.dto.capture.VisionAttrItem;
import com.drin.smartpark.project.api.ythz.form.PullFaceRecordForm;
import com.drin.smartpark.project.api.ythz.form.face.RetrievalResult;
import com.drin.smartpark.project.api.ythz.service.HeSerice;
import com.drin.smartpark.project.api.ythz.service.RetrofitService;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/10 1:12
 */
@Component
public class VistTimer {

    @Autowired
    private ServerConfig serverConfig;

    @Autowired
    private RetrofitService retrofitService;

    @Autowired
    private BsVisitorServiceImpl bsVisitorService;

    @Autowired
    private BsVisitorHistoryServiceImpl bsVisitorHistoryService;

    // 每天凌晨定时删除所有的访客信息
//    @Scheduled(fixedRate = 24*60*60*1000,initialDelay = 1000)
    private void init() {
        FaceRecordApi faceRecordApi = retrofitService.getApiByIPService(HeSerice.ip,FaceRecordApi.class);
        Map<String,Object> param = pullFaceRecordForm();
        try {
            RetrievalRecordDto retrievalRecordDto = faceRecordApi.retrievalRecordList(param).execute().body();
            List<RetrievalResult> retrievalItems = retrievalRecordDto.getRecords();
            if (CollectionUtils.isEmpty(retrievalItems))
                return;

            retrievalItems.stream().forEach(retrievalItem -> {
                long captureTime = retrievalItem.getUnix_timestamp_ms();
                Date captureDate = new Date(captureTime);

                String channelName = retrievalItem.getCapture_result().getChannel_name();
                String faceUrl = retrievalItem.getCapture_result().getFace_image_url();
                String sceneUrl = retrievalItem.getCapture_result().getScene_image_url();
                String name = retrievalItem.getHit_person().getName();
                String id = retrievalItem.getHit_person().getId();
                List<VisionAttrItem> visionAttrItems =
                        JsonMapper.string2Obj(retrievalItem.getCapture_result().getVision_attributes(), new TypeReference<List<VisionAttrItem>>(){} );

                List<String> labelList = new ArrayList<>();
                for (VisionAttrItem visionAttrItem : visionAttrItems) {
                    if(visionAttrItem.getType_().equals(Constant.GenderType.key)) {
                        labelList.add(Constant.GenderType.getLabel( visionAttrItem.getValue()));
                    }
                    if (visionAttrItem.getType_().equals(Constant.AgeType.key)) {
                        labelList.add(Constant.AgeType.getLabel( visionAttrItem.getValue()));
                    }
                }
                FaceApi faceApi = retrofitService.getApiByIPService(HeSerice.ip,FaceApi.class);
                LocalDate localDate = captureDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();;
                String faceDirHome = VistConfig.getUploadPath()+"/"+ DateUtils.datePath() +"/face";
                downlowdImg(faceDirHome,faceUrl,faceApi);
                String sceneDirHome = VistConfig.getUploadPath()+"/"+ DateUtils.datePath()+"/scene";
                downlowdImg(sceneDirHome,sceneUrl,faceApi);

                BsVisitorHistory history = new BsVisitorHistory();
                history.setImageId("/profile/upload/"+DateUtils.datePath() + "/face/"+faceUrl+".jpg");
                history.setCaptureId("/profile/upload/"+DateUtils.datePath() +"/scene/"+sceneUrl+".jpg");
                history.setRemark(channelName);
                history.setVisitorName(name);
                // 获取比对中的访客信息
                BsVisitor visitor = bsVisitorService.selectBsVisitorById(Long.valueOf(id));
                if(visitor!=null) {
                    System.out.println("--------------新增的访客id和name");
                    System.out.println(id);
                    System.out.println(name);
                    history.setVisitorName(visitor.getVisitorName());
                    history.setVisitorCard(visitor.getVisitorCard());
                    history.setPictureId(visitor.getImageId());
                    history.setStatus("1");
                    history.setInTime(captureDate);
                    history.setVisitorId(Long.valueOf(id));
                    bsVisitorHistoryService.insertBsVisitorHistory(history);
                }else {
//                    System.out.println("--------------不存在的访客id和name");
//                    System.out.println(id);
//                    System.out.println(name);
                }








            });

        }catch (IOException e) {

        }
    }

    private void downlowdImg(String dir,String imageId,FaceApi faceApi) {
        try {
            //转换下时间
            File imgFileDir = new File(dir);
            if(!imgFileDir.exists()) {
                imgFileDir.mkdirs();
            }
            String filePath = dir+"/"+imageId+".jpg";
            FileOutputStream fos = new FileOutputStream(filePath);
            InputStream in = faceApi.downloadPicWithUrl(imageId).execute().body().byteStream();
            int count = 0;
            byte[] buffer = new byte[1024];
            while ((count = in.read(buffer)) != -1) {
                fos.write(buffer, 0, count);
            }
            fos.flush();
            fos.close();

//            saveFileImagePath(imageId,filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    private Map<String, Object> pullFaceRecordForm() {
        PullFaceRecordForm param = new PullFaceRecordForm();
        // 获取今天和昨天的记录
        LocalDateTime endDate = LocalDate.now().plusDays(1).atStartOfDay();
        LocalDateTime startDate = LocalDate.now().atStartOfDay();
        Long startTime = startDate.toEpochSecond(ZoneOffset.of("+8"));
        Long endTime = endDate.toEpochSecond(ZoneOffset.of("+8"));
        //只查询昨天的数据
        param.setStart_timestamp_ms(startTime*1000);
        param.setEnd_timestamp_ms(endTime*1000);
        param.setMode(Constant.SearchFaceType.RETRIEVAL.getValue());
        return MapUtil.objectToMap(param);
    }



}
