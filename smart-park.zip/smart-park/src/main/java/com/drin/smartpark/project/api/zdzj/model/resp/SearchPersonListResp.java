package com.drin.smartpark.project.api.zdzj.model.resp;

import com.drin.smartpark.project.api.zdzj.model.resp.sub.SearchPersonListSubResp;
import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/9/8 11:47
 * @描述: 查询多个名单返回对象
 */
@Data
public class SearchPersonListResp {
    // 返回468 没有返回人员列表
    private Integer code;
    private String operator;
    private SearchPersonListSubResp info;

}
