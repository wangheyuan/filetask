package com.drin.smartpark.project.check.service.impl;

import java.util.List;
import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.common.tool.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.drin.smartpark.project.check.mapper.BsQueryRecordMapper;
import com.drin.smartpark.project.check.entity.BsQueryRecord;
import com.drin.smartpark.project.check.service.IBsQueryRecordService;

/**
 * 考勤管理Service业务层处理
 *
 * @author kano
 * @date 2020-12-25
 */
@Service
public class BsQueryRecordServiceImpl implements IBsQueryRecordService
{
    @Autowired
    private BsQueryRecordMapper bsQueryRecordMapper;

    /**
     * 查询考勤管理
     *
     * @param recordId 考勤管理ID
     * @return 考勤管理
     */
    @Override
    public BsQueryRecord selectBsQueryRecordById(Long recordId)
    {
        return bsQueryRecordMapper.selectBsQueryRecordById(recordId);
    }

    /**
     * 查询考勤管理列表
     *
     * @param bsQueryRecord 考勤管理
     * @return 考勤管理
     */
    @Override
    public List<BsQueryRecord> selectBsQueryRecordList(BsQueryRecord bsQueryRecord)
    {
        return bsQueryRecordMapper.selectBsQueryRecordList(bsQueryRecord);
    }

    /**
     * 新增考勤管理
     *
     * @param bsQueryRecord 考勤管理
     * @return 结果
     */
    @Override
    public int insertBsQueryRecord(BsQueryRecord bsQueryRecord)
    {
        bsQueryRecord.setCreateTime(DateUtils.getNowDate());
        bsQueryRecord.setCreateBy(SecurityUtils.getUsername());
        return bsQueryRecordMapper.insertBsQueryRecord(bsQueryRecord);
    }

    /**
     * 修改考勤管理
     *
     * @param bsQueryRecord 考勤管理
     * @return 结果
     */
    @Override
    public int updateBsQueryRecord(BsQueryRecord bsQueryRecord)
    {
        return bsQueryRecordMapper.updateBsQueryRecord(bsQueryRecord);
    }

    /**
     * 批量删除考勤管理
     *
     * @param recordIds 需要删除的考勤管理ID
     * @return 结果
     */
    @Override
    public int deleteBsQueryRecordByIds(Long[] recordIds)
    {
        return bsQueryRecordMapper.deleteBsQueryRecordByIds(recordIds);
    }

    /**
     * 删除考勤管理信息
     *
     * @param recordId 考勤管理ID
     * @return 结果
     */
    @Override
    public int deleteBsQueryRecordById(Long recordId)
    {
        return bsQueryRecordMapper.deleteBsQueryRecordById(recordId);
    }
}