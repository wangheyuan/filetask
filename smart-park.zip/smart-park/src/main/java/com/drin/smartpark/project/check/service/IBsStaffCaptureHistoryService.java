package com.drin.smartpark.project.check.service;

import java.util.List;
import com.drin.smartpark.project.check.entity.BsStaffCaptureHistory;

/**
 * 员工抓拍历史Service接口
 *
 * @author wangheyuan
 * @date 2020-11-26
 */
public interface IBsStaffCaptureHistoryService
{
    /**
     * 查询员工抓拍历史
     *
     * @param historyId 员工抓拍历史ID
     * @return 员工抓拍历史
     */
    public BsStaffCaptureHistory selectBsStaffCaptureHistoryById(Long historyId);

    /**
     * 查询员工抓拍历史列表
     *
     * @param bsStaffCaptureHistory 员工抓拍历史
     * @return 员工抓拍历史集合
     */
    public List<BsStaffCaptureHistory> selectBsStaffCaptureHistoryList(BsStaffCaptureHistory bsStaffCaptureHistory);

    /**
     * 新增员工抓拍历史
     *
     * @param bsStaffCaptureHistory 员工抓拍历史
     * @return 结果
     */
    public int insertBsStaffCaptureHistory(BsStaffCaptureHistory bsStaffCaptureHistory);

    /**
     * 修改员工抓拍历史
     *
     * @param bsStaffCaptureHistory 员工抓拍历史
     * @return 结果
     */
    public int updateBsStaffCaptureHistory(BsStaffCaptureHistory bsStaffCaptureHistory);

    /**
     * 批量删除员工抓拍历史
     *
     * @param historyIds 需要删除的员工抓拍历史ID
     * @return 结果
     */
    public int deleteBsStaffCaptureHistoryByIds(Long[] historyIds);

    /**
     * 删除员工抓拍历史信息
     *
     * @param historyId 员工抓拍历史ID
     * @return 结果
     */
    public int deleteBsStaffCaptureHistoryById(Long historyId);

    /**
     *
     * @param staffId 获取当天的历史记录
     * @return java.util.List<com.drin.smartpark.project.check.entity.BsStaffCaptureHistory>
     * @author HIPAA
     * @date 2020/12/4 13:42
     */
    public List<BsStaffCaptureHistory> getTodayStaffCaptureHistory(Long staffId);
}