package com.drin.smartpark.project.check.entity;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.drin.smartpark.framework.excel.annotation.Excel;
import com.drin.smartpark.common.BaseEntity;

/**
 * 每日考勤对象 bs_staff_capture_day
 *
 * @author wangheyuan
 * @date 2020-11-27
 */
public class BsStaffCaptureDay extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 部门ID */
    @TableField(exist = false)
    private Long deptId;

    /** 历史抓拍主键 */
    private Long historyDayId;

    /** 员工编码 */
    @Excel(name = "员工编码")
    private Long staffId;

    /** 名称 */
    @Excel(name = "名称")
    private String staffName;

    /** 工号 */
    @Excel(name = "工号")
    private String staffCard;

    /** 照片 */
    @Excel(name = "照片")
    private String imageId;

    /** 日期 */
    @Excel(name = "日期")
    private String checkDay;

    /** 状态 */
    @Excel(name = "状态")
    private String status;

    /** 工时 */
    @Excel(name = "工时")
    private Integer normalHour;

    /** 上班时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "上班时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date inTime;

    /** 下班时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "下班时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date outTime;



    public void setHistoryDayId(Long historyDayId)
    {
        this.historyDayId = historyDayId;
    }

    public Long getHistoryDayId()
    {
        return historyDayId;
    }
    public void setStaffId(Long staffId)
    {
        this.staffId = staffId;
    }

    public Long getStaffId()
    {
        return staffId;
    }
    public void setStaffName(String staffName)
    {
        this.staffName = staffName;
    }

    public String getStaffName()
    {
        return staffName;
    }
    public void setStaffCard(String staffCard)
    {
        this.staffCard = staffCard;
    }

    public String getStaffCard()
    {
        return staffCard;
    }
    public void setImageId(String imageId)
    {
        this.imageId = imageId;
    }

    public String getImageId()
    {
        return imageId;
    }
    public void setCheckDay(String checkDay)
    {
        this.checkDay = checkDay;
    }

    public String getCheckDay()
    {
        return checkDay;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }
    public void setNormalHour(Integer normalHour)
    {
        this.normalHour = normalHour;
    }

    public Integer getNormalHour()
    {
        return normalHour;
    }
    public void setInTime(Date inTime)
    {
        this.inTime = inTime;
    }

    public Date getInTime()
    {
        return inTime;
    }
    public void setOutTime(Date outTime)
    {
        this.outTime = outTime;
    }

    public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }

    public Date getOutTime()
    {
        return outTime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("historyDayId", getHistoryDayId())
                .append("staffId", getStaffId())
                .append("staffName", getStaffName())
                .append("staffCard", getStaffCard())
                .append("imageId", getImageId())
                .append("checkDay", getCheckDay())
                .append("status", getStatus())
                .append("remark", getRemark())
                .append("normalHour", getNormalHour())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("inTime", getInTime())
                .append("outTime", getOutTime())
                .append("deptId", getDeptId())
                .toString();
    }
}