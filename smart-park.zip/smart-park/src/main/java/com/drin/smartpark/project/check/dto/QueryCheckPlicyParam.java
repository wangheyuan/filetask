/**
 * 文件名称:          	QueryCheckPlicyParam
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.dto;

import lombok.Data;

/**
 * 查询策略参数
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/12/4 15:31
 */
@Data
public class QueryCheckPlicyParam {

    // 设备id（本系统）
    private Integer  deviceId;
    // 员工标签
    private Long[] postIds;
    // 部门id
    private Long deptId;

}
