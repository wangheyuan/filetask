package com.drin.smartpark.project.check.service.impl;

import java.util.List;
import com.drin.smartpark.common.tool.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.drin.smartpark.project.check.mapper.BsStaffPostMapper;
import com.drin.smartpark.project.check.entity.BsStaffPost;
import com.drin.smartpark.project.check.service.IBsStaffPostService;

/**
 * 标签信息Service业务层处理
 *
 * @author wangheyuan
 * @date 2020-11-20
 */
@Service
public class BsStaffPostServiceImpl implements IBsStaffPostService
{
    @Autowired
    private BsStaffPostMapper bsStaffPostMapper;

    /**
     * 查询标签信息
     *
     * @param postId 标签信息ID
     * @return 标签信息
     */
    @Override
    public BsStaffPost selectBsStaffPostById(Long postId)
    {
        return bsStaffPostMapper.selectBsStaffPostById(postId);
    }

    /**
     * 查询标签信息列表
     *
     * @param bsStaffPost 标签信息
     * @return 标签信息
     */
    @Override
    public List<BsStaffPost> selectBsStaffPostList(BsStaffPost bsStaffPost)
    {
        return bsStaffPostMapper.selectBsStaffPostList(bsStaffPost);
    }

    /**
     * 新增标签信息
     *
     * @param bsStaffPost 标签信息
     * @return 结果
     */
    @Override
    public int insertBsStaffPost(BsStaffPost bsStaffPost)
    {
        bsStaffPost.setCreateTime(DateUtils.getNowDate());
        return bsStaffPostMapper.insertBsStaffPost(bsStaffPost);
    }

    /**
     * 修改标签信息
     *
     * @param bsStaffPost 标签信息
     * @return 结果
     */
    @Override
    public int updateBsStaffPost(BsStaffPost bsStaffPost)
    {
        bsStaffPost.setUpdateTime(DateUtils.getNowDate());
        return bsStaffPostMapper.updateBsStaffPost(bsStaffPost);
    }

    /**
     * 批量删除标签信息
     *
     * @param postIds 需要删除的标签信息ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffPostByIds(Long[] postIds)
    {
        return bsStaffPostMapper.deleteBsStaffPostByIds(postIds);
    }

    /**
     * 删除标签信息信息
     *
     * @param postId 标签信息ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffPostById(Long postId)
    {
        return bsStaffPostMapper.deleteBsStaffPostById(postId);
    }

    /**
     * 查询所有标签
     *
     * @return 岗位列表
     */
    @Override
    public List<BsStaffPost> selectBsStaffPostAll() {
        return bsStaffPostMapper.selectStaffPostAll();
    }

    /**
     * 根据访客ID获取标签选择框列表
     *
     * @param staffId 用户ID
     * @return 选中岗位ID列表
     */
    @Override
    public List<Long> selectStaffPostListByStaffId(Long staffId) {
        return bsStaffPostMapper.selectStaffPostListByStaffId(staffId);
    }

    /**
     * 获取策略的标签
     *
     * @param plicyId
     * @return java.util.List<java.lang.Long>
     * @author HIPAA
     * @date 2020/11/25 15:54
     */
    @Override
    public List<Long> selectStaffPostListByPlicyId(Long plicyId) {
        return bsStaffPostMapper.selectStaffPostListByPlicyId(plicyId);
    }
}