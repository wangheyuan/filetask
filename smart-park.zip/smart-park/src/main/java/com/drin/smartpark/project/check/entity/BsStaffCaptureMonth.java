package com.drin.smartpark.project.check.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.drin.smartpark.framework.excel.annotation.Excel;
import com.drin.smartpark.common.BaseEntity;

/**
 * 员工每月考勤对象 bs_staff_capture_month
 *
 * @author wangheyuan
 * @date 2020-11-27
 */
public class BsStaffCaptureMonth extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 历史抓拍主键 */
    private Long historyMonthId;

    /** $column.columnComment */
    private Long staffId;

    /** 员工名称 */
    @Excel(name = "员工名称")
    private String staffName;

    /** 工号 */
    @Excel(name = "工号")
    private String staffCard;

    /** 照片 */
    @Excel(name = "照片")
    private String imageId;

    /** 月份 */
    @Excel(name = "月份")
    private String checkMonth;

    /** 工作天数 */
    @Excel(name = "工作天数")
    private Integer normalDay;

    /** 异常天数 */
    @Excel(name = "异常天数")
    private Integer errorDay;

    /** 状态 */
    @Excel(name = "状态")
    private String status;

    public void setHistoryMonthId(Long historyMonthId)
    {
        this.historyMonthId = historyMonthId;
    }

    public Long getHistoryMonthId()
    {
        return historyMonthId;
    }
    public void setStaffId(Long staffId)
    {
        this.staffId = staffId;
    }

    public Long getStaffId()
    {
        return staffId;
    }
    public void setStaffName(String staffName)
    {
        this.staffName = staffName;
    }

    public String getStaffName()
    {
        return staffName;
    }
    public void setStaffCard(String staffCard)
    {
        this.staffCard = staffCard;
    }

    public String getStaffCard()
    {
        return staffCard;
    }
    public void setImageId(String imageId)
    {
        this.imageId = imageId;
    }

    public String getImageId()
    {
        return imageId;
    }
    public void setCheckMonth(String checkMonth)
    {
        this.checkMonth = checkMonth;
    }

    public String getCheckMonth()
    {
        return checkMonth;
    }
    public void setNormalDay(Integer normalDay)
    {
        this.normalDay = normalDay;
    }

    public Integer getNormalDay()
    {
        return normalDay;
    }
    public void setErrorDay(Integer errorDay)
    {
        this.errorDay = errorDay;
    }

    public Integer getErrorDay()
    {
        return errorDay;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("historyMonthId", getHistoryMonthId())
                .append("staffId", getStaffId())
                .append("staffName", getStaffName())
                .append("staffCard", getStaffCard())
                .append("imageId", getImageId())
                .append("checkMonth", getCheckMonth())
                .append("normalDay", getNormalDay())
                .append("errorDay", getErrorDay())
                .append("status", getStatus())
                .append("remark", getRemark())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}