package com.drin.smartpark.project.access.controller;

import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.framework.page.TableDataInfo;
import com.drin.smartpark.project.access.entity.BsVisitorHistory;
import com.drin.smartpark.project.access.service.IBsVisitorHistoryService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 访客历史列表Controller
 *
 * @author ruoyi
 * @date 2020-09-07
 */
@RestController
@RequestMapping("/access/history")
public class BsVisitorHistoryController extends BaseController
{
    @Autowired
    private IBsVisitorHistoryService bsVisitorHistoryService;

    /**
     * 查询访客历史列表列表
     */
    @RequiresPermissions("access:history:list")
    @GetMapping("/list")
    public TableDataInfo list(BsVisitorHistory bsVisitorHistory)
    {
        startPage();
        List<BsVisitorHistory> list = bsVisitorHistoryService.selectBsVisitorHistoryList(bsVisitorHistory);
        return getDataTable(list);
    }

    /**
     * 导出访客历史列表列表
     */
    @RequiresPermissions("access:history:export")
    @Log(title = "访客历史列表", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsVisitorHistory bsVisitorHistory)
    {
        List<BsVisitorHistory> list = bsVisitorHistoryService.selectBsVisitorHistoryList(bsVisitorHistory);
        ExcelUtil<BsVisitorHistory> util = new ExcelUtil<BsVisitorHistory>(BsVisitorHistory.class);
        return util.exportExcel(list, "history");
    }

    /**
     * 获取访客历史列表详细信息
     */
    @RequiresPermissions("access:history:query")
    @GetMapping(value = "/{visitorId}")
    public RestResp getInfo(@PathVariable("visitorId") Long visitorId)
    {
        return RestResp.success(bsVisitorHistoryService.selectBsVisitorHistoryById(visitorId));
    }

    /**
     * 新增访客历史列表
     */
    @RequiresPermissions("access:history:add")
    @Log(title = "访客历史列表", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsVisitorHistory bsVisitorHistory)
    {
        return toAjax(bsVisitorHistoryService.insertBsVisitorHistory(bsVisitorHistory));
    }

    /**
     * 修改访客历史列表
     */
    @RequiresPermissions("access:history:edit")
    @Log(title = "访客历史列表", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsVisitorHistory bsVisitorHistory)
    {
        return toAjax(bsVisitorHistoryService.updateBsVisitorHistory(bsVisitorHistory));
    }

    /**
     * 删除访客历史列表
     */
    @RequiresPermissions("access:history:remove")
    @Log(title = "访客历史列表", businessType = BusinessType.DELETE)
    @DeleteMapping("/{visitorIds}")
    public RestResp remove(@PathVariable Long[] visitorIds)
    {
        return toAjax(bsVisitorHistoryService.deleteBsVisitorHistoryByIds(visitorIds));
    }
}