/**
 * 文件名称:          	CommonFaceServiceImpl
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.common.service.impl;

import com.drin.smartpark.common.config.VistConfig;
import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.common.tool.FileToBase64;
import com.drin.smartpark.common.tool.JsonUtil;
import com.drin.smartpark.framework.util.JsonMapper;
import com.drin.smartpark.framework.util.MapUtil;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.api.common.service.CommonFaceDeviceService;
import com.drin.smartpark.project.api.common.service.YthzService;
import com.drin.smartpark.project.api.common.service.YtyxService;
import com.drin.smartpark.project.api.common.util.RtspUrlUtil;
import com.drin.smartpark.project.api.ythz.DeviceApi;
import com.drin.smartpark.project.api.ythz.FaceApi;
import com.drin.smartpark.project.api.ythz.FaceRecordApi;
import com.drin.smartpark.project.api.ythz.config.Constant;
import com.drin.smartpark.project.api.ythz.dto.ChannelConfigDto;
import com.drin.smartpark.project.api.ythz.dto.RetrievalRecordDto;
import com.drin.smartpark.project.api.ythz.dto.capture.VisionAttrItem;
import com.drin.smartpark.project.api.ythz.dto.face.FaceImageDto;
import com.drin.smartpark.project.api.ythz.dto.face.FaceMetaDto;
import com.drin.smartpark.project.api.ythz.form.FaceInsertForm;
import com.drin.smartpark.project.api.ythz.form.PullFaceRecordForm;
import com.drin.smartpark.project.api.ythz.form.face.RetrievalResult;
import com.drin.smartpark.project.api.ythz.form.video.VideoChannel;
import com.drin.smartpark.project.api.ythz.service.HeSerice;
import com.drin.smartpark.project.api.ythz.service.RetrofitService;
import com.drin.smartpark.project.api.ytyx.YtyxDeviceApi;
import com.drin.smartpark.project.api.ytyx.dto.YtyxRestResp;
import com.drin.smartpark.project.api.ytyx.form.QueryDeviceListForm;
import com.drin.smartpark.project.api.ytyx.model.device.YtyxDevice;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.entity.BsStaff;
import com.drin.smartpark.project.check.entity.BsStaffCaptureHistory;
import com.drin.smartpark.project.check.mapper.BsCommonDeviceMapper;
import com.drin.smartpark.project.check.service.IBsStaffCaptureHistoryService;
import com.drin.smartpark.project.check.service.IBsStaffService;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.*;

/**
 * 对设备的所有操作，可以使用这个service
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/11/24 10:50
 */
@Slf4j
@Service
public class CommonFaceDeviceServiceImpl implements CommonFaceDeviceService {

    @Autowired
    private BsCommonDeviceMapper commonDeviceMapper;


    @Autowired
    private YthzService ythzService;

    @Autowired
    private YtyxService ytyxService;

    /**
     * 增加员工到设备
     *
     * @param device
     * @param staff
     * @date 2020/11/24 10:39
     */
    @Override
    public void addStaffToDevice(BsCommonDevice device, BsStaff staff) {
        switch (device.getDeviceType()) {
            //类型为盒子的时候，新增人员
            case "1":
                ythzService.addStaffToDevice(device,staff);
                break;
            case "4":
               // ytyxService.addStaffToDevice(device,staff);
                break;

        }


    }

    /**
     * 增加员工到所有设备
     *
     * @param staff
     * @date 2020/11/24 10:39
     */
    @Override
    public void addStaffToAllDevice(BsStaff staff) {
        List<BsCommonDevice> deviceList = commonDeviceMapper.selectBsCommonDeviceList(new BsCommonDevice());
        if(!CollectionUtils.isEmpty(deviceList)) {
            deviceList.stream().forEach(device -> {
                addStaffToDevice(device,staff);
            });
        }
    }

    /**
     * 移除员工到设备
     *
     * @param device
     * @param staffId
     * @date 2020/11/24 10:39
     */
    @Override
    public void removeStaffFromDevice(BsCommonDevice device, String staffId) {
        switch (device.getDeviceType()) {
            case "1":
                ythzService.removeStaffFromDevice(device,staffId);
                break;
            case "4":
               // ytyxService.removeStaffFromDevice(device,staffId);
                break;
        }
    }

    /**
     * 从设备移除员工
     *
     * @param staffId
     * @date 2020/11/24 10:39
     */
    @Override
    public void removeStaffFromAllDevice(String staffId) {
        List<BsCommonDevice> deviceList = commonDeviceMapper.selectBsCommonDeviceList(new BsCommonDevice());
        if(!CollectionUtils.isEmpty(deviceList)) {
            deviceList.stream().forEach(device -> {
                removeStaffFromDevice(device,staffId);
            });
        }
    }

    /**
     * 增加访客到设备
     *
     * @param device
     * @param visitor
     * @date 2020/11/24 10:39
     */
    @Override
    public void addVisitorToDevice(BsCommonDevice device, BsVisitor visitor) {

    }

    /**
     * 增加访客到所有设备
     *
     * @param visitor
     * @date 2020/11/24 10:39
     */
    @Override
    public void addVisitorToAllDevice(BsVisitor visitor) {

    }

    /**
     * 增加访客到所有设备
     *
     * @param device
     * @param visitor
     * @date 2020/11/24 10:39
     */
    @Override
    public void removeVisitorFromDevice(BsCommonDevice device, BsVisitor visitor) {

    }

    /**
     * 从设备移除所有的访客
     *
     * @param visitor
     * @date 2020/11/24 10:39
     */
    @Override
    public void removeVisitorFromAllDevice(BsVisitor visitor) {

    }

    /**
     * 增加设备
     *
     * @param device
     * @date 2020/11/24 10:45
     */
    @Override
    public void addDevice(BsCommonDevice device) {
        switch (device.getDeviceType()) {
            // 创建视频流
            case "2":
            case "3":
                ythzService.addDevice(device);
                break;
        }
    }

    /**
     * 更新设备
     *
     * @param device
     * @return void
     * @author HIPAA
     * @date 2021/1/7 11:09
     */
    @Override
    public void updateDevice(BsCommonDevice device) {
        BsCommonDevice tmp = commonDeviceMapper.selectBsCommonDeviceById(device.getDeviceId());
        switch (tmp.getDeviceType()) {
            // 创建视频流
            case "2":
            case "3":
                ythzService.updateDevice(tmp);
                break;
        }
    }

    /**
     * 移除设备
     *
     * @param deviceId
     * @date 2020/11/24 10:45
     */
    @Override
    public void removeDevice(Integer deviceId) {
        BsCommonDevice tmp = commonDeviceMapper.selectBsCommonDeviceById(deviceId);
        switch (tmp.getDeviceType()) {
            // 创建视频流
            case "2":
            case "3":
                ythzService.removeDevice(tmp);
                break;
        }
    }

    /**
     * 返回设备所有的人员信息
     *
     * @param device
     * @date 2020/11/24 10:45
     */
    @Override
    public List<BsStaffCaptureHistory> listStaffCaptureHistoryFromDevice(BsCommonDevice device) {
        List<BsStaffCaptureHistory> result = new ArrayList<>();
        switch (device.getDeviceType()) {
            case "1":
                result= ythzService.listStaffCaptureHistoryFromDevice(device);
                break;
        }
        return result;
    }


    /**
     * 返回所有的人员信息
     *
     * @date 2020/11/24 10:45
     */
    @Override
    public List<BsStaffCaptureHistory> listStaffCaptureHistoryFromAllDevice() {

        // 获取当前系统所有设备
        List<BsCommonDevice> allDevices = commonDeviceMapper.selectBsCommonDeviceList(new BsCommonDevice());
        if(CollectionUtils.isEmpty(allDevices))
            return null;

        List<BsStaffCaptureHistory> result = new ArrayList<>();
        if(!CollectionUtils.isEmpty(allDevices)){
            allDevices.stream().forEach(d->{
                List<BsStaffCaptureHistory>  temp = listStaffCaptureHistoryFromDevice(d);
                if(!CollectionUtils.isEmpty(temp)) {
                    result.addAll(temp);
                }
            });
        }
        return result;
    }

    /**
     * 根据人员id 返回人员信息
     *
     * @param device
     * @param personId
     * @date 2020/11/24 10:45
     */
    @Override
    public Map<String, Object> personFromDeviceById(BsCommonDevice device, String personId) {
        return null;
    }

    /**
     * 返回设备中的人员信息
     *
     * @param personId
     * @date 2020/11/24 10:45
     */
    @Override
    public Map<String, Object> personFromAllDeviceById(String personId) {
        return null;
    }



    /**
     * 初始化盒子的初始化状态
     *
     * @return void
     * @author HIPAA
     * @date 2021/1/4 13:32
     */
    @SneakyThrows
    @Override
    public List<BsCommonDevice> childDeviceList(BsCommonDevice parentDevice) {
        List<BsCommonDevice> devices = new ArrayList<>();
        switch (parentDevice.getDeviceType()) {
            case "1":
                devices = ythzService.childDeviceList(parentDevice);
                break;
            case "4":
                devices = ytyxService.childDeviceList(parentDevice);
                break;
        }
        return devices;
    }


}
