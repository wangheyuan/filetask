/**
 * 文件名称:          	IBsCheckPlicyService
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.service;

import com.drin.smartpark.project.check.dto.QueryCheckPlicyParam;
import com.drin.smartpark.project.check.entity.BsCheckPlicy;

import java.util.List;

/**
 * 考勤策略service
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/11/25 14:03
 */
public interface IBsCheckPlicyService {

    /**
     * 查询策略列
     *
     * @param plicyId 策略列ID
     * @return 策略列
     */
    public BsCheckPlicy selectBsCheckPlicyById(Long plicyId);

    /**
     * 查询策略列列表
     *
     * @param bsCheckPlicy 策略列
     * @return 策略列集合
     */
    public List<BsCheckPlicy> selectBsCheckPlicyList(BsCheckPlicy bsCheckPlicy);

    /**
     * 查询策略列
     *
     * @param param
     * @return 策略列
     */
    public List<BsCheckPlicy> selectBsCheckPlicyByParam(QueryCheckPlicyParam param);

    /**
     * 新增策略列
     *
     * @param bsCheckPlicy 策略列
     * @return 结果
     */
    public Long insertBsCheckPlicy(BsCheckPlicy bsCheckPlicy);

    /**
     * 修改策略列
     *
     * @param bsCheckPlicy 策略列
     * @return 结果
     */
    public int updateBsCheckPlicy(BsCheckPlicy bsCheckPlicy);

    /**
     * 批量删除策略列
     *
     * @param plicyIds 需要删除的策略列ID
     * @return 结果
     */
    public int deleteBsCheckPlicyByIds(Long[] plicyIds);

    /**
     * 删除策略列信息
     *
     * @param plicyId 策略列ID
     * @return 结果
     */
    public int deleteBsCheckPlicyById(Long plicyId);

    /**
     * 判断当天是否是在政策内，是否需要导入新的人员，删除对应的人员
     * @param plicy
     * @return boolean
     * @author HIPAA
     * @date 2020/9/8 10:56
     */
    public boolean isValidToday(BsCheckPlicy plicy);
    
}