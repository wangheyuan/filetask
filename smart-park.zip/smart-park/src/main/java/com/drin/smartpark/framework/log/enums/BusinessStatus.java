package com.drin.smartpark.framework.log.enums;

/**
 * 操作状态
 * 
 * @author wangheyuan
 *
 */
public enum BusinessStatus
{
    /**
     * 成功
     */
    SUCCESS,

    /**
     * 失败
     */
    FAIL,
}
