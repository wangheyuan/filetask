/**
 * 文件名称:          	BsCheckPlicyDept
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/12/2 14:04
 */
public class BsCheckPlicyDept {

    /** 策略ID */
    private Long plicyId;

    /** 岗位ID */
    private Long deptId;

    public Long getPlicyId()
    {
        return plicyId;
    }

    public void setPlicyId(Long plicyId)
    {
        this.plicyId = plicyId;
    }

    public Long getDeptId()
    {
        return deptId;
    }

    public void setDeptId(Long deptId)
    {
        this.deptId = deptId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("plicyId", getPlicyId())
                .append("deptId", getDeptId())
                .toString();
    }

}
