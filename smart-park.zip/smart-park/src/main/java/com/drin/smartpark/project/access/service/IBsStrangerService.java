package com.drin.smartpark.project.access.service;

import com.drin.smartpark.project.access.entity.BsStranger;

import java.util.List;

/**
 * 陌生人列表Service接口
 *
 * @author wangheyuan
 * @date 2020-09-09
 */
public interface IBsStrangerService
{
    /**
     * 查询陌生人列表
     *
     * @param strangerId 陌生人列表ID
     * @return 陌生人列表
     */
    public BsStranger selectBsStrangerById(Long strangerId);

    /**
     * 查询陌生人列表列表
     *
     * @param bsStranger 陌生人列表
     * @return 陌生人列表集合
     */
    public List<BsStranger> selectBsStrangerList(BsStranger bsStranger);

    /**
     * 新增陌生人列表
     *
     * @param bsStranger 陌生人列表
     * @return 结果
     */
    public int insertBsStranger(BsStranger bsStranger);

    /**
     * 修改陌生人列表
     *
     * @param bsStranger 陌生人列表
     * @return 结果
     */
    public int updateBsStranger(BsStranger bsStranger);
    
    /**
     * 将陌生人的信息进行删除
     * @param id
     * @return void
     * @author HIPAA
     * @date 2020/9/14 13:15
     */
    public void passStranger(Long id);

    /**
     * 批量删除陌生人列表
     *
     * @param strangerIds 需要删除的陌生人列表ID
     * @return 结果
     */
    public int deleteBsStrangerByIds(Long[] strangerIds);

    /**
     * 删除陌生人列表信息
     *
     * @param strangerId 陌生人列表ID
     * @return 结果
     */
    public int deleteBsStrangerById(Long strangerId);
}