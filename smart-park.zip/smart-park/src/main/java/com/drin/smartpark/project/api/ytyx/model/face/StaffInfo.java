/**
 * 文件名称:          	StaffInfo
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.face;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * 员工信息
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/18 3:46
 */
@Data
public class StaffInfo {

    private List<String> card_numbers = new ArrayList<>();

    private String dept_id;

    private List<String> face_image_content_list = new ArrayList<>();

    private PersonInfo person_information;

    private List<String> tag_id_list;
}
