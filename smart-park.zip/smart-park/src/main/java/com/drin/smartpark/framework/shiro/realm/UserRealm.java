package com.drin.smartpark.framework.shiro.realm;


import com.drin.smartpark.common.tool.spring.SpringUtils;
import com.drin.smartpark.framework.shiro.service.SysPermissionService;
import com.drin.smartpark.framework.shiro.service.TokenService;
import com.drin.smartpark.project.system.entity.SysUser;
import com.drin.smartpark.project.system.model.LoginUser;
import com.drin.smartpark.project.system.service.SysUserService;
import org.apache.shiro.authc.*;
import org.springframework.beans.factory.annotation.Autowired;

public class UserRealm extends DrinRealm {

    @Autowired
    private SysUserService userService;


    @Autowired
    private SysPermissionService permissionService;


    //认证方法
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        //1.获取用户的手机号和密码
        UsernamePasswordToken upToken = (UsernamePasswordToken) authenticationToken;
        String username = upToken.getUsername();
        String password = new String( upToken.getPassword());
        //2.根据手机号查询用户
        SysUser user = userService.selectUserByUserName(username);
        //3.判断用户是否存在，用户密码是否和输入密码一致
        if(user != null && user.getPassword().equals(password)) {
            //4.构造安全数据并返回（安全数据：用户基本数据，权限信息 profileResult）
            LoginUser userInfo =  new LoginUser(user, permissionService.getMenuPermission(user));
            SpringUtils.getBean(TokenService.class).setUserAgent(userInfo);;
//            userInfo.setUser(user);
//            userInfo.setPermissions(permissionService.getMenuPermission(user));
            //构造方法：安全数据，密码，realm域名
            SimpleAuthenticationInfo info = new SimpleAuthenticationInfo(userInfo,user.getPassword(),this.getName());
            return info;
        }
        //返回null，会抛出异常，标识用户名和密码不匹配
        return null;
    }
}
