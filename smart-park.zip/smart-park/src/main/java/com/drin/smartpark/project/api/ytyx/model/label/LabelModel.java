/**
 * 文件名称:          	LabelModel
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.label;

import lombok.Data;

import java.util.List;

/**
 * 标签实体
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/17 13:30
 */
@Data
public class LabelModel {

    public static final String STAFF_TYPE = "STAFF";
    public static final String VISITOR_TYPE = "VISITOR";

    private String tag_id;
    private String tag_container_id;
    private String tag_name;
    private Integer count;
    List<String> visible_identity;
}
