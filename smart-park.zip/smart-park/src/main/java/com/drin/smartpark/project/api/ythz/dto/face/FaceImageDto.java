/**
 * 文件名称:          	faceImageDto
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.dto.face;

import lombok.Data;

/**
 * 人脸图片信息
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 11:07
 */
@Data
public class FaceImageDto {

    /** 图片的base64 */
    private String content;
    /** 图片的类型 "jpeg" "png" */
    private String content_type;

}
