package com.drin.smartpark.project.api.ytyx.model.che;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @作者: Kano
 * @时间:2020/8/19 14:52
 * @描述:
 */
@Data
public class NewAccessPolicyDTO {
    public static final String STAFF = "STAFF";
    public static final String VISITOR = "VISITOR";
    public static final String CUSTOM = "CUSTOM";


    //允许通行部门
    private List<String> dept_id_list = new ArrayList<>();
    //可以通行的设备
    private List<String> device_id_list = new ArrayList<>();
    //是否启用该通行策略
    private boolean enabled;
    //id
    private String id;
    //允许通行的人员身份,仅限于：员工/访客
    private List<String> identity_list = new ArrayList<>();
    //策略名称
    private String name;
    //策略名称
    private List<String> tag_id_list = new ArrayList<>();
    //可以通行的时间
    private ValidTimeDTO valid_time;

}
