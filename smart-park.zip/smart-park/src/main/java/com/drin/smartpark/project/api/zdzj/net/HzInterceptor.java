/**
 * 文件名称:          	ImInterceptor
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj.net;

import com.drin.smartpark.common.constant.Constants;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;

/**
 * 请求头拦截器
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/24 15:01
 */
public class HzInterceptor implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {
        Request originalRequest = chain.request();
        // token 需要根据对应盒子进行取
        String token = "";
        Request request = originalRequest
                .newBuilder()
                .addHeader(Constants.JWT_AUTHORITIES,  token)
                .addHeader("Content_Type","application/json")
                .addHeader("charset","UTF-8")
                .addHeader("Accept","application/json")
                .build();
        return chain.proceed(request);
    }
}
