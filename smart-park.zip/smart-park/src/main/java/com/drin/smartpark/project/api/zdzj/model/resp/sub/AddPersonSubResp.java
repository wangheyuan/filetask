package com.drin.smartpark.project.api.zdzj.model.resp.sub;

import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/9/8 11:45
 * @描述:
 */
@Data
public class AddPersonSubResp {
    private String Result;
    private String Detail;
}
