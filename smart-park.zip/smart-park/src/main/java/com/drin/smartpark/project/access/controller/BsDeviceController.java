package com.drin.smartpark.project.access.controller;

import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.framework.page.TableDataInfo;
import com.drin.smartpark.project.access.entity.BsDevice;
import com.drin.smartpark.project.access.service.IBsDeviceService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 门禁设备Controller
 *
 * @author wangheyuan
 * @date 2020-09-01
 */
@RestController
@RequestMapping("/access/device")
public class BsDeviceController extends BaseController
{
    @Autowired
    private IBsDeviceService bsDeviceService;

    /**
     * 查询门禁设备列表
     */
    @RequiresPermissions("access:device:list")
    @GetMapping("/list")
    public TableDataInfo list(BsDevice bsDevice)
    {
        startPage();
        List<BsDevice> list = bsDeviceService.selectBsDeviceList(bsDevice);
        return getDataTable(list);
    }

    /**
     * 导出门禁设备列表
     */
    @RequiresPermissions("access:device:export")
    @Log(title = "门禁设备", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsDevice bsDevice)
    {
        List<BsDevice> list = bsDeviceService.selectBsDeviceList(bsDevice);
        ExcelUtil<BsDevice> util = new ExcelUtil<BsDevice>(BsDevice.class);
        return util.exportExcel(list, "device");
    }

    /**
     * 获取门禁设备详细信息
     */
    @RequiresPermissions("access:device:query")
    @GetMapping(value = "/{deviceId}")
    public RestResp getInfo(@PathVariable("deviceId") Integer deviceId)
    {
        return RestResp.success(bsDeviceService.selectBsDeviceById(deviceId));
    }

    /**
     * 新增门禁设备
     */
    @RequiresPermissions("access:device:add")
    @Log(title = "门禁设备", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsDevice bsDevice)
    {
        return toAjax(bsDeviceService.insertBsDevice(bsDevice));
    }

    /**
     * 修改门禁设备
     */
    @RequiresPermissions("access:device:edit")
    @Log(title = "门禁设备", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsDevice bsDevice)
    {
        return toAjax(bsDeviceService.updateBsDevice(bsDevice));
    }

    /**
     * 删除门禁设备
     */
    @RequiresPermissions("access:device:remove")
    @Log(title = "门禁设备", businessType = BusinessType.DELETE)
    @DeleteMapping("/{deviceIds}")
    public RestResp remove(@PathVariable Integer[] deviceIds)
    {
        return toAjax(bsDeviceService.deleteBsDeviceByIds(deviceIds));
    }
}