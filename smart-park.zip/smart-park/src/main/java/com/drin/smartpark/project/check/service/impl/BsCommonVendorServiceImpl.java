package com.drin.smartpark.project.check.service.impl;

import java.util.List;
import com.drin.smartpark.common.tool.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.drin.smartpark.project.check.mapper.BsCommonVendorMapper;
import com.drin.smartpark.project.check.entity.BsCommonVendor;
import com.drin.smartpark.project.check.service.IBsCommonVendorService;

/**
 * 平台类型厂商Service业务层处理
 *
 * @author wangheyuan
 * @date 2021-01-07
 */
@Service
public class BsCommonVendorServiceImpl implements IBsCommonVendorService
{
    @Autowired
    private BsCommonVendorMapper bsCommonVendorMapper;

    /**
     * 查询平台类型厂商
     *
     * @param vendorId 平台类型厂商ID
     * @return 平台类型厂商
     */
    @Override
    public BsCommonVendor selectBsCommonVendorById(Long vendorId)
    {
        return bsCommonVendorMapper.selectBsCommonVendorById(vendorId);
    }

    /**
     * 查询平台类型厂商列表
     *
     * @param bsCommonVendor 平台类型厂商
     * @return 平台类型厂商
     */
    @Override
    public List<BsCommonVendor> selectBsCommonVendorList(BsCommonVendor bsCommonVendor)
    {
        return bsCommonVendorMapper.selectBsCommonVendorList(bsCommonVendor);
    }

    /**
     * 新增平台类型厂商
     *
     * @param bsCommonVendor 平台类型厂商
     * @return 结果
     */
    @Override
    public int insertBsCommonVendor(BsCommonVendor bsCommonVendor)
    {
        bsCommonVendor.setCreateTime(DateUtils.getNowDate());
        return bsCommonVendorMapper.insertBsCommonVendor(bsCommonVendor);
    }

    /**
     * 修改平台类型厂商
     *
     * @param bsCommonVendor 平台类型厂商
     * @return 结果
     */
    @Override
    public int updateBsCommonVendor(BsCommonVendor bsCommonVendor)
    {
        bsCommonVendor.setUpdateTime(DateUtils.getNowDate());
        return bsCommonVendorMapper.updateBsCommonVendor(bsCommonVendor);
    }

    /**
     * 批量删除平台类型厂商
     *
     * @param vendorIds 需要删除的平台类型厂商ID
     * @return 结果
     */
    @Override
    public int deleteBsCommonVendorByIds(Long[] vendorIds)
    {
        return bsCommonVendorMapper.deleteBsCommonVendorByIds(vendorIds);
    }

    /**
     * 删除平台类型厂商信息
     *
     * @param vendorId 平台类型厂商ID
     * @return 结果
     */
    @Override
    public int deleteBsCommonVendorById(Long vendorId)
    {
        return bsCommonVendorMapper.deleteBsCommonVendorById(vendorId);
    }
}