package com.drin.smartpark.project.access.service.impl;

import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.project.access.entity.BsStranger;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.access.mapper.BsStrangerMapper;
import com.drin.smartpark.project.access.service.IBsStrangerService;
import com.drin.smartpark.project.access.service.IBsVisitorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * 陌生人列表Service业务层处理
 *
 * @author wangheyuan
 * @date 2020-09-09
 */
@Service
public class BsStrangerServiceImpl implements IBsStrangerService
{
    @Autowired
    private BsStrangerMapper bsStrangerMapper;

    @Autowired
    private IBsVisitorService visitorService;

    /**
     * 查询陌生人列表
     *
     * @param strangerId 陌生人列表ID
     * @return 陌生人列表
     */
    @Override
    public BsStranger selectBsStrangerById(Long strangerId)
    {
        return bsStrangerMapper.selectBsStrangerById(strangerId);
    }

    /**
     * 查询陌生人列表列表
     *
     * @param bsStranger 陌生人列表
     * @return 陌生人列表
     */
    @Override
    public List<BsStranger> selectBsStrangerList(BsStranger bsStranger)
    {
        return bsStrangerMapper.selectBsStrangerList(bsStranger);
    }

    /**
     * 新增陌生人列表
     *
     * @param bsStranger 陌生人列表
     * @return 结果
     */
    @Override
    public int insertBsStranger(BsStranger bsStranger)
    {
        bsStranger.setCreateTime(DateUtils.getNowDate());
        return bsStrangerMapper.insertBsStranger(bsStranger);
    }

    /**
     * 修改陌生人列表
     *
     * @param bsStranger 陌生人列表
     * @return 结果
     */
    @Override
    public int updateBsStranger(BsStranger bsStranger)
    {
        bsStranger.setUpdateTime(DateUtils.getNowDate());
        return bsStrangerMapper.updateBsStranger(bsStranger);
    }

    /**
     * 将陌生人的信息进行删除
     *
     * @param id
     * @return void
     * @author HIPAA
     * @date 2020/9/14 13:14
     */
    @Override
    public void passStranger(Long id) {
        BsStranger stranger = bsStrangerMapper.selectBsStrangerById(id);
        BsVisitor visitor = new BsVisitor();
        visitor.setVisitorName(stranger.getStrangerName());
        visitor.setVisitorCard(stranger.getStrangerCard());
        visitor.setImageId(stranger.getCaptureId());
        visitor.setStatus("0");
        // 设置员工类型为访客
        visitor.setVisitorType("1");
        visitor.setCreateTime(new Date());
        visitor.setRemark(stranger.getRemark()+"操作");
        // 录入访客白名单
        visitorService.insertBsVisitor(visitor);
        bsStrangerMapper.deleteBsStrangerById(id);
    }

    /**
     * 批量删除陌生人列表
     *
     * @param strangerIds 需要删除的陌生人列表ID
     * @return 结果
     */
    @Override
    public int deleteBsStrangerByIds(Long[] strangerIds)
    {
        return bsStrangerMapper.deleteBsStrangerByIds(strangerIds);
    }

    /**
     * 删除陌生人列表信息
     *
     * @param strangerId 陌生人列表ID
     * @return 结果
     */
    @Override
    public int deleteBsStrangerById(Long strangerId)
    {
        return bsStrangerMapper.deleteBsStrangerById(strangerId);
    }
}