/**
 * 文件名称:          	QueryDeviceList
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.form;

import lombok.Data;

import java.util.List;

/**
 * 查询设备列表的参数
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/4 10:55
 */
@Data
public class QueryDeviceListForm {
    private List<String> device_dept_id_list;
    private List<String> device_id_list;
    private Integer page;
    private Integer size;
}
