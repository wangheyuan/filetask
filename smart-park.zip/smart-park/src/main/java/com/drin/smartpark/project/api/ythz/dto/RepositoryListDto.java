/**
 * 文件名称:          	RepositoryListDto
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.dto;

import lombok.Data;

import java.util.List;

/**
 * 人脸库返回api
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 9:52
 */
@Data
public class RepositoryListDto {

    private List<String> repository_list;

}
