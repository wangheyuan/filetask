/**
 * 文件名称:          	YtyxDeviceApi
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx;

import com.drin.smartpark.project.api.ytyx.dto.YtyxRestResp;
import com.drin.smartpark.project.api.ytyx.form.AddDevice;
import com.drin.smartpark.project.api.ytyx.model.device.YtyxDevice;
import org.apache.ibatis.annotations.Delete;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.List;
import java.util.Map;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/4 10:11
 */
public interface YtyxDeviceApi {

    // 查询盒子的实体列表，需要实体类 QueryDeviceListForm
    @GET("park/website/devices")
    Call<YtyxRestResp<List<YtyxDevice>>> deviceList(@QueryMap Map<String,Object> param);

    // 新增设备
    @POST("park/website/devices")
    Call<YtyxRestResp> addDevice(@Body AddDevice param);

    // 移除设备
    @Delete("park/website/devices/{id}")
    Call<YtyxRestResp> removeDevice(@Path("id") String id);





}