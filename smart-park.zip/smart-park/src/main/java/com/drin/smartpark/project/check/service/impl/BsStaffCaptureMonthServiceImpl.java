package com.drin.smartpark.project.check.service.impl;

import java.util.List;
import com.drin.smartpark.common.tool.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.drin.smartpark.project.check.mapper.BsStaffCaptureMonthMapper;
import com.drin.smartpark.project.check.entity.BsStaffCaptureMonth;
import com.drin.smartpark.project.check.service.IBsStaffCaptureMonthService;

/**
 * 员工每月考勤Service业务层处理
 *
 * @author wangheyuan
 * @date 2020-11-27
 */
@Service
public class BsStaffCaptureMonthServiceImpl implements IBsStaffCaptureMonthService
{
    @Autowired
    private BsStaffCaptureMonthMapper bsStaffCaptureMonthMapper;

    /**
     * 查询员工每月考勤
     *
     * @param historyMonthId 员工每月考勤ID
     * @return 员工每月考勤
     */
    @Override
    public BsStaffCaptureMonth selectBsStaffCaptureMonthById(Long historyMonthId)
    {
        return bsStaffCaptureMonthMapper.selectBsStaffCaptureMonthById(historyMonthId);
    }

    /**
     * 查询员工每月考勤列表
     *
     * @param bsStaffCaptureMonth 员工每月考勤
     * @return 员工每月考勤
     */
    @Override
    public List<BsStaffCaptureMonth> selectBsStaffCaptureMonthList(BsStaffCaptureMonth bsStaffCaptureMonth)
    {
        return bsStaffCaptureMonthMapper.selectBsStaffCaptureMonthList(bsStaffCaptureMonth);
    }

    /**
     * 新增员工每月考勤
     *
     * @param bsStaffCaptureMonth 员工每月考勤
     * @return 结果
     */
    @Override
    public int insertBsStaffCaptureMonth(BsStaffCaptureMonth bsStaffCaptureMonth)
    {
        bsStaffCaptureMonth.setCreateTime(DateUtils.getNowDate());
        return bsStaffCaptureMonthMapper.insertBsStaffCaptureMonth(bsStaffCaptureMonth);
    }

    /**
     * 修改员工每月考勤
     *
     * @param bsStaffCaptureMonth 员工每月考勤
     * @return 结果
     */
    @Override
    public int updateBsStaffCaptureMonth(BsStaffCaptureMonth bsStaffCaptureMonth)
    {
        bsStaffCaptureMonth.setUpdateTime(DateUtils.getNowDate());
        return bsStaffCaptureMonthMapper.updateBsStaffCaptureMonth(bsStaffCaptureMonth);
    }

    /**
     * 批量删除员工每月考勤
     *
     * @param historyMonthIds 需要删除的员工每月考勤ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffCaptureMonthByIds(Long[] historyMonthIds)
    {
        return bsStaffCaptureMonthMapper.deleteBsStaffCaptureMonthByIds(historyMonthIds);
    }

    /**
     * 删除员工每月考勤信息
     *
     * @param historyMonthId 员工每月考勤ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffCaptureMonthById(Long historyMonthId)
    {
        return bsStaffCaptureMonthMapper.deleteBsStaffCaptureMonthById(historyMonthId);
    }
}