package com.drin.smartpark.project.access.service.impl;

import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.project.access.entity.BsPassPlicy;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.access.entity.BsVisitorPost;
import com.drin.smartpark.project.access.mapper.BsVisitorMapper;
import com.drin.smartpark.project.access.mapper.BsVisitorPostMapper;
import com.drin.smartpark.project.access.service.IBsPassPlicyService;
import com.drin.smartpark.project.access.service.IBsVisitorService;
import com.drin.smartpark.project.api.zdzj.service.FaceService;
import com.drin.smartpark.project.api.ythz.service.HeSerice;
import com.drin.smartpark.project.system.service.SysPostService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 访客信息管理Service业务层处理
 *
 * @author wangheyuan
 * @date 2020-09-02
 */
@Slf4j
@Service
public class BsVisitorServiceImpl implements IBsVisitorService
{
    @Autowired
    private BsVisitorMapper bsVisitorMapper;

    @Autowired
    private BsVisitorPostMapper visitorPostMapper;

    @Autowired
    private SysPostService postService;

    @Autowired
    private IBsPassPlicyService plicyService;

    @Autowired
    private FaceService faceService;

    @Autowired
    private HeSerice heSerice;

    /**
     * 查询访客信息管理
     *
     * @param visitorId 访客信息管理ID
     * @return 访客信息管理
     */
    @Override
    public BsVisitor selectBsVisitorById(Long visitorId)
    {
        return bsVisitorMapper.selectBsVisitorById(visitorId);
    }

    /**
     * 查询访客信息管理列表
     *
     * @param bsVisitor 访客信息管理
     * @return 访客信息管理
     */
    @Override
    public List<BsVisitor> selectBsVisitorList(BsVisitor bsVisitor)
    {
        List<BsVisitor> list = bsVisitorMapper.selectBsVisitorList(bsVisitor);
        if(!CollectionUtils.isEmpty(list)) {
            list.stream().forEach(t->{
                List<Integer> postIds = postService.selectPostListByVisitorId(t.getVisitorId());
                if(!CollectionUtils.isEmpty(postIds)) {
                   Long[] posts = new Long[postIds.size()];
                    for (int i = 0; i < postIds.size(); i++) {
                        posts[i] = Long.valueOf(postIds.get(i));
                    }
                    t.setPostIds(posts);
                }
            });
        }
        return list;
    }

    /**
     * 新增访客信息管理
     *
     * @param bsVisitor 访客信息管理
     * @return 结果
     */
    @Override
    public int insertBsVisitor(BsVisitor bsVisitor)
    {
        log.info("----------------新增员工信息");
        bsVisitor.setCreateTime(DateUtils.getNowDate());
        bsVisitorMapper.insertBsVisitor(bsVisitor);
        insertVisitorPost(bsVisitor);
        // 录入白名单信息
//        faceService.addVisitorToAllDevice(bsVisitor);
        heSerice.addVisitorFace(bsVisitor);
        return bsVisitor.getVisitorId().intValue();
    }

    /**
     * 修改访客信息管理
     *
     * @param bsVisitor 访客信息管理
     * @return 结果
     */
    @Override
    public int updateBsVisitor(BsVisitor bsVisitor)
    {
        Long visitorId = bsVisitor.getVisitorId();
        //删除访客标签的关联
        visitorPostMapper.deleteVisitorPostByVisitorId(visitorId);
        //新增访客和岗位管理
        insertVisitorPost(bsVisitor);
        bsVisitor.setUpdateTime(DateUtils.getNowDate());

        return bsVisitorMapper.updateBsVisitor(bsVisitor);
    }

    /**
     * 新增访客标签信息
     *
     * @param visitor 访客对象
     */
    public void insertVisitorPost(BsVisitor visitor)
    {
        Long[] posts = visitor.getPostIds();
        if (StringUtils.isNotNull(posts))
        {
            // 新增访客与标签管理
            List<BsVisitorPost> list = new ArrayList<BsVisitorPost>();
            for (Long postId : posts)
            {
                BsVisitorPost up = new BsVisitorPost();
                up.setVisitorId(visitor.getVisitorId());
                up.setPostId(postId);
                list.add(up);
            }
            if (list.size() > 0)
            {
                visitorPostMapper.batchVisitorPost(list);
            }
        }
    }

    /**
     * 批量删除访客信息管理
     *
     * @param visitorIds 需要删除的访客信息管理ID
     * @return 结果
     */
    @Override
    public int deleteBsVisitorByIds(Long[] visitorIds)
    {
        visitorPostMapper.deleteVisitorPost(visitorIds);
        List<Integer> ids =Arrays.asList(visitorIds).stream().map(t->{
            Integer id = t.intValue();
            heSerice.removeVisitorFace(String.valueOf(id));
            return id;
        }).collect(Collectors.toList());

//        faceService.deleteVisitorsByIds(ids);
        return bsVisitorMapper.deleteBsVisitorByIds(visitorIds);
    }

    /**
     * 删除访客信息管理信息
     *
     * @param visitorId 访客信息管理ID
     * @return 结果
     */
    @Override
    public int deleteBsVisitorById(Long visitorId)
    {
        //删除访客标签的关联
        visitorPostMapper.deleteVisitorPostByVisitorId(visitorId);
        List<Integer> ids = new ArrayList<>();
        ids.add(visitorId.intValue());
        faceService.deleteVisitorsByIds(ids);
        return bsVisitorMapper.deleteBsVisitorById(visitorId);
    }

    /**
     * 根据标签查询访客列表
     * @param postIds
     * @return java.util.List<com.drin.smartpark.project.access.entity.BsVisitor>
     * @author HIPAA
     * @date 2020/9/7 9:44
     */
    @Override
    public List<BsVisitor> selectBsVisitorListByPostIds(List<Long> postIds) {
        return bsVisitorMapper.selectVisitorListByPostIds(postIds);
    }

    /**
     * 通过策略id查询访客列表
     *
     * @param plicyId
     * @return java.util.List<com.drin.smartpark.project.access.entity.BsVisitor>
     * @author HIPAA
     * @date 2020/9/8 10:36
     */
    @Override
    public List<BsVisitor> selectBsVisitorListByPlicyId(Long plicyId) {
        return bsVisitorMapper.selectVisitorListByPlicyId(plicyId);
    }

    /**
     * 查询当前所有应该通过的访客信息
     *
     * @return java.util.List<com.drin.smartpark.project.access.entity.BsVisitor>
     * @author HIPAA
     * @date 2020/9/8 11:46
     */
    @Override
    public List<BsVisitor> selectAllValidVisitorList() {
        List<BsPassPlicy> allPlicy = plicyService.selectBsPassPlicyList(new BsPassPlicy());
        if(CollectionUtils.isEmpty(allPlicy))
            return null;
        List<BsPassPlicy> plicyList = allPlicy.stream().filter(t->{
            return "0".equals(t.getPlicyStatus());

        }).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(plicyList))
            return null;
        List<BsVisitor> visitors = new ArrayList<>();
        plicyList.stream().forEach(plicy -> {
            // 策略类型为0 的 是永久白名单
            if("0".equals(plicy.getPlicyType())) {
                visitors.addAll(selectBsVisitorListByPlicyId(plicy.getPlicyId()));
            }else {
                // 动态验证的需要判断是否对应访客在通行时间内
                if(plicyService.isValidToday(plicy)) {
                    visitors.addAll(selectBsVisitorListByPlicyId(plicy.getPlicyId()));
                }
            }
        });
        return visitors;
    }
}