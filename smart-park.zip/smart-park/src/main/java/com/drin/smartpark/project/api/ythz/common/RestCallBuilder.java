/**
 * 文件名称:          	RestCallBuilder
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.common;

/**
 * call生成器
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/28 17:22
 */
public class RestCallBuilder<T> {



}
