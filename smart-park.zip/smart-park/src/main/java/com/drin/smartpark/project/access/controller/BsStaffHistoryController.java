package com.drin.smartpark.project.access.controller;

import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.framework.page.TableDataInfo;
import com.drin.smartpark.project.access.entity.BsStaffHistory;
import com.drin.smartpark.project.access.service.IBsStaffHistoryService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 员工考勤历史列Controller
 *
 * @author wangheyuan
 * @date 2020-11-05
 */
@RestController
@RequestMapping("/staffHistory/history")
public class BsStaffHistoryController extends BaseController
{
    @Autowired
    private IBsStaffHistoryService bsStaffHistoryService;

    /**
     * 查询员工考勤历史列列表
     */
    @RequiresPermissions("staffHistory:history:list")
    @GetMapping("/list")
    public TableDataInfo list(BsStaffHistory bsStaffHistory)
    {
        startPage();
        List<BsStaffHistory> list = bsStaffHistoryService.selectBsStaffHistoryList(bsStaffHistory);
        return getDataTable(list);
    }

    /**
     * 导出员工考勤历史列列表
     */
    @RequiresPermissions("staffHistory:history:export")
    @Log(title = "员工考勤历史列", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsStaffHistory bsStaffHistory)
    {
        List<BsStaffHistory> list = bsStaffHistoryService.selectBsStaffHistoryList(bsStaffHistory);
        ExcelUtil<BsStaffHistory> util = new ExcelUtil<BsStaffHistory>(BsStaffHistory.class);
        return util.exportExcel(list, "history");
    }

    /**
     * 获取员工考勤历史列详细信息
     */
    @RequiresPermissions("staffHistory:history:query")
    @GetMapping(value = "/{visitorId}")
    public RestResp getInfo(@PathVariable("visitorId") Long visitorId)
    {
        return RestResp.success(bsStaffHistoryService.selectBsStaffHistoryById(visitorId));
    }

    /**
     * 新增员工考勤历史列
     */
    @RequiresPermissions("staffHistory:history:add")
    @Log(title = "员工考勤历史列", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsStaffHistory bsStaffHistory)
    {
        return toAjax(bsStaffHistoryService.insertBsStaffHistory(bsStaffHistory));
    }

    /**
     * 修改员工考勤历史列
     */
    @RequiresPermissions("staffHistory:history:edit")
    @Log(title = "员工考勤历史列", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsStaffHistory bsStaffHistory)
    {
        return toAjax(bsStaffHistoryService.updateBsStaffHistory(bsStaffHistory));
    }

    /**
     * 删除员工考勤历史列
     */
    @RequiresPermissions("staffHistory:history:remove")
    @Log(title = "员工考勤历史列", businessType = BusinessType.DELETE)
    @DeleteMapping("/{visitorIds}")
    public RestResp remove(@PathVariable Long[] visitorIds)
    {
        return toAjax(bsStaffHistoryService.deleteBsStaffHistoryByIds(visitorIds));
    }
}