/**
 * 文件名称:          	CaptureRecordConfig
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.video.config;

import lombok.Data;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/5 16:33
 */
@Data
public class CaptureRecordConfig {
    private boolean enable_save_capture_record;
    private Integer capture_record_expire_in_days;
    private Integer max_capture_record;
}
