/**
 * 文件名称:          	DeletePersonForm
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj.model.form;

import com.drin.smartpark.project.api.zdzj.model.form.sub.DeletePersonFormSub;
import lombok.Data;

import java.util.List;

/**
 * 删除人员表单
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/7 11:12
 */
@Data
public class DeletePersonForm {
    private String operator="DeletePerson";
    private DeletePersonFormSub info;
    public DeletePersonForm(Integer deviceId, List<Integer> visitorIds) {
        info = new DeletePersonFormSub();
        info.setDeviceID(deviceId);
        info.setCustomizeID(visitorIds);
        info.setIdType(0);
        info.setTotalNum(visitorIds.size());
    }
}
