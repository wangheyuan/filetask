package com.drin.smartpark.project.access.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.access.entity.BsStranger;

import java.util.List;

/**
 * 陌生人列表Mapper接口
 *
 * @author wangheyuan
 * @date 2020-09-09
 */
public interface BsStrangerMapper  extends BaseMapper<BsStranger>
{
    /**
     * 查询陌生人列表
     *
     * @param strangerId 陌生人列表ID
     * @return 陌生人列表
     */
    public BsStranger selectBsStrangerById(Long strangerId);

    /**
     * 查询陌生人列表列表
     *
     * @param bsStranger 陌生人列表
     * @return 陌生人列表集合
     */
    public List<BsStranger> selectBsStrangerList(BsStranger bsStranger);

    /**
     * 新增陌生人列表
     *
     * @param bsStranger 陌生人列表
     * @return 结果
     */
    public int insertBsStranger(BsStranger bsStranger);

    /**
     * 修改陌生人列表
     *
     * @param bsStranger 陌生人列表
     * @return 结果
     */
    public int updateBsStranger(BsStranger bsStranger);

    /**
     * 删除陌生人列表
     *
     * @param strangerId 陌生人列表ID
     * @return 结果
     */
    public int deleteBsStrangerById(Long strangerId);

    /**
     * 批量删除陌生人列表
     *
     * @param strangerIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsStrangerByIds(Long[] strangerIds);
}