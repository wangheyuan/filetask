package com.drin.smartpark.project.access.service.impl;

import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.project.access.entity.BsStaffHistory;
import com.drin.smartpark.project.access.mapper.BsStaffHistoryMapper;
import com.drin.smartpark.project.access.service.IBsStaffHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 员工考勤历史列Service业务层处理
 *
 * @author wangheyuan
 * @date 2020-11-05
 */
@Service
public class BsStaffHistoryServiceImpl implements IBsStaffHistoryService
{
    @Autowired
    private BsStaffHistoryMapper bsStaffHistoryMapper;

    /**
     * 查询员工考勤历史列
     *
     * @param visitorId 员工考勤历史列ID
     * @return 员工考勤历史列
     */
    @Override
    public BsStaffHistory selectBsStaffHistoryById(Long visitorId)
    {
        return bsStaffHistoryMapper.selectBsStaffHistoryById(visitorId);
    }

    /**
     * 查询员工考勤历史列列表
     *
     * @param bsStaffHistory 员工考勤历史列
     * @return 员工考勤历史列
     */
    @Override
    public List<BsStaffHistory> selectBsStaffHistoryList(BsStaffHistory bsStaffHistory)
    {
        return bsStaffHistoryMapper.selectBsStaffHistoryList(bsStaffHistory);
    }

    /**
     * 新增员工考勤历史列
     *
     * @param bsStaffHistory 员工考勤历史列
     * @return 结果
     */
    @Override
    public int insertBsStaffHistory(BsStaffHistory bsStaffHistory)
    {
        bsStaffHistory.setCreateTime(DateUtils.getNowDate());
        return bsStaffHistoryMapper.insertBsStaffHistory(bsStaffHistory);
    }

    /**
     * 修改员工考勤历史列
     *
     * @param bsStaffHistory 员工考勤历史列
     * @return 结果
     */
    @Override
    public int updateBsStaffHistory(BsStaffHistory bsStaffHistory)
    {
        bsStaffHistory.setUpdateTime(DateUtils.getNowDate());
        return bsStaffHistoryMapper.updateBsStaffHistory(bsStaffHistory);
    }

    /**
     * 批量删除员工考勤历史列
     *
     * @param visitorIds 需要删除的员工考勤历史列ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffHistoryByIds(Long[] visitorIds)
    {
        return bsStaffHistoryMapper.deleteBsStaffHistoryByIds(visitorIds);
    }

    /**
     * 删除员工考勤历史列信息
     *
     * @param visitorId 员工考勤历史列ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffHistoryById(Long visitorId)
    {
        return bsStaffHistoryMapper.deleteBsStaffHistoryById(visitorId);
    }
}