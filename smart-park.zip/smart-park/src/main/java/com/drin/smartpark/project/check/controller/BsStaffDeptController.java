package com.drin.smartpark.project.check.controller;

import java.util.List;

import com.drin.smartpark.project.access.entity.BsDept;
import com.drin.smartpark.project.check.entity.BsStaff;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.project.check.entity.BsStaffDept;
import com.drin.smartpark.project.check.service.IBsStaffDeptService;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;

/**
 * 员工部门管理Controller
 *
 * @author wangheyuan
 * @date 2020-11-19
 */
@RestController
@RequestMapping("/check/staffDept")
public class BsStaffDeptController extends BaseController
{
    @Autowired
    private IBsStaffDeptService bsStaffDeptService;

    /**
     * 查询员工部门管理列表
     */
    @RequiresPermissions("check:staffDept:list")
    @GetMapping("/list")
    public RestResp list(BsStaffDept bsStaffDept)
    {
        List<BsStaffDept> list = bsStaffDeptService.selectBsStaffDeptList(bsStaffDept);
        return RestResp.success(list);
    }

    /**
     * 导出员工部门管理列表
     */
    @RequiresPermissions("check:staffDept:export")
    @Log(title = "员工部门管理", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsStaffDept bsStaffDept)
    {
        List<BsStaffDept> list = bsStaffDeptService.selectBsStaffDeptList(bsStaffDept);
        ExcelUtil<BsStaffDept> util = new ExcelUtil<BsStaffDept>(BsStaffDept.class);
        return util.exportExcel(list, "staffDept");
    }

    /**
     * 获取员工部门管理详细信息
     */
    @RequiresPermissions("check:staffDept:query")
    @GetMapping(value = "/{deptId}")
    public RestResp getInfo(@PathVariable("deptId") Long deptId)
    {
        return RestResp.success(bsStaffDeptService.selectBsStaffDeptById(deptId));
    }

    /**
     * 新增员工部门管理
     */
    @RequiresPermissions("check:staffDept:add")
    @Log(title = "员工部门管理", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsStaffDept bsStaffDept)
    {
        return toAjax(bsStaffDeptService.insertBsStaffDept(bsStaffDept));
    }

    /**
     * 修改员工部门管理
     */
    @RequiresPermissions("check:staffDept:edit")
    @Log(title = "员工部门管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsStaffDept bsStaffDept)
    {
        return toAjax(bsStaffDeptService.updateBsStaffDept(bsStaffDept));
    }

    /**
     * 删除员工部门管理
     */
    @RequiresPermissions("check:staffDept:remove")
    @Log(title = "员工部门管理", businessType = BusinessType.DELETE)
    @DeleteMapping("/{deptIds}")
    public RestResp remove(@PathVariable Long[] deptIds)
    {
        return toAjax(bsStaffDeptService.deleteBsStaffDeptByIds(deptIds));
    }

    /**
     * 获取部门下拉树列表
     */
    @GetMapping("/treeselect")
    public RestResp treeselect(BsStaffDept dept)
    {
        List<BsStaffDept> depts = bsStaffDeptService.selectBsStaffDeptList(dept);
        return RestResp.success(bsStaffDeptService.buildDeptTreeSelect(depts));
    }
}