package com.drin.smartpark.project.access.controller;

import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.project.access.entity.BsDept;
import com.drin.smartpark.project.access.service.IBsDeptService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 门禁系统部门管理Controller
 *
 * @author ruoyi
 * @date 2020-09-03
 */
@RestController
@RequestMapping("/access/dept")
public class BsDeptController extends BaseController
{
    @Autowired
    private IBsDeptService bsDeptService;

    /**
     * 查询门禁系统部门管理列表
     */
    @RequiresPermissions("access:dept:list")
    @GetMapping("/list")
    public RestResp list(BsDept bsDept)
    {
        List<BsDept> list = bsDeptService.selectBsDeptList(bsDept);
        return RestResp.success(list);
    }

    /**
     * 导出门禁系统部门管理列表
     */
    @RequiresPermissions("access:dept:export")
    @Log(title = "门禁系统部门管理", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsDept bsDept)
    {
        List<BsDept> list = bsDeptService.selectBsDeptList(bsDept);
        ExcelUtil<BsDept> util = new ExcelUtil<BsDept>(BsDept.class);
        return util.exportExcel(list, "dept");
    }

    /**
     * 获取门禁系统部门管理详细信息
     */
    @RequiresPermissions("access:dept:query")
    @GetMapping(value = "/{deptId}")
    public RestResp getInfo(@PathVariable("deptId") Long deptId)
    {
        return RestResp.success(bsDeptService.selectBsDeptById(deptId));
    }

    /**
     * 新增门禁系统部门管理
     */
    @RequiresPermissions("access:dept:add")
    @Log(title = "门禁系统部门管理", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsDept bsDept)
    {
        return toAjax(bsDeptService.insertBsDept(bsDept));
    }

    /**
     * 修改门禁系统部门管理
     */
    @RequiresPermissions("access:dept:edit")
    @Log(title = "门禁系统部门管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsDept bsDept)
    {
        return toAjax(bsDeptService.updateBsDept(bsDept));
    }

    /**
     * 删除门禁系统部门管理
     */
    @RequiresPermissions("access:dept:remove")
    @Log(title = "门禁系统部门管理", businessType = BusinessType.DELETE)
    @DeleteMapping("/{deptIds}")
    public RestResp remove(@PathVariable Long[] deptIds)
    {
        return toAjax(bsDeptService.deleteBsDeptByIds(deptIds));
    }

    /**
     * 获取部门下拉树列表
     */
    @GetMapping("/treeselect")
    public RestResp treeselect(BsDept dept)
    {
        List<BsDept> depts = bsDeptService.selectBsDeptList(dept);
        return RestResp.success(bsDeptService.buildDeptTreeSelect(depts));
    }

}