package com.drin.smartpark.project.api.ytyx.model.che;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @作者: Kano
 * @时间:2020/8/19 14:59
 * @描述:
 */
@Data
public class ValidTimeDTO {

    //周期性策略结束日期(不含), 格式`YYYY-MM-DD`
    private String end_date;
    //周期性策略每天结束时间(不含), 格式`HH:MM:SS`
    private String end_time;
    //一次性策略结束时间, 单位秒
    private Integer end_timestamp;
    //有效时间类型, 1表示全时段，2表示单次，3表示周期
    private Integer mode;
    //周期性策略起始日期(包含), 格式`YYYY-MM-DD`
    private String start_date;
    //周期性策略每天开始时间(包含), 格式`HH:MM:SS`
    private String start_time;
    //一次性策略起始时间, 单位秒
    private Integer start_timestamp;
    //周期性策略每周生效时间, 接受1-7的整数,代表周一到周日
    private List<Integer> valid_weekday = new ArrayList<>();

}
