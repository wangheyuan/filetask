package com.drin.smartpark.project.api.zdzj.model.resp;

import com.drin.smartpark.project.api.zdzj.model.resp.sub.DeviceSubResp;
import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/8/31 10:27
 * @描述: 查询设备的响应体
 */
@Data
public class DeviceResp {
    private String operator;
    private DeviceSubResp info;
}




