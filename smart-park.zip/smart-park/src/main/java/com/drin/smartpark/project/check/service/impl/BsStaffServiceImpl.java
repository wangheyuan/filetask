package com.drin.smartpark.project.check.service.impl;

import java.util.ArrayList;
import java.util.List;
import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.common.tool.SecurityUtils;
import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.access.entity.BsVisitorPost;
import com.drin.smartpark.project.api.common.service.CommonFaceDeviceService;
import com.drin.smartpark.project.check.entity.BsStaffPost;
import com.drin.smartpark.project.check.entity.BsStaffStaffPost;
import com.drin.smartpark.project.check.mapper.BsStaffPostMapper;
import com.drin.smartpark.project.check.mapper.BsStaffStaffPostMapper;
import com.drin.smartpark.project.check.service.IBsStaffPostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.drin.smartpark.project.check.mapper.BsStaffMapper;
import com.drin.smartpark.project.check.entity.BsStaff;
import com.drin.smartpark.project.check.service.IBsStaffService;
import org.springframework.util.CollectionUtils;

/**
 * 员工Service业务层处理
 *
 * @author wangheyuan
 * @date 2020-11-20
 */
@Service
public class BsStaffServiceImpl implements IBsStaffService
{

    @Autowired
    private CommonFaceDeviceService faceDeviceService;

    @Autowired
    private BsStaffMapper bsStaffMapper;


    @Autowired
    private BsStaffStaffPostMapper bsStaffStaffPostMapper;

    @Autowired
    private IBsStaffPostService bsStaffPostService;

    /**
     * 查询员工
     *
     * @param staffId 员工ID
     * @return 员工
     */
    @Override
    public BsStaff selectBsStaffById(Long staffId)
    {
        return bsStaffMapper.selectBsStaffById(staffId);
    }

    /**
     * 查询员工
     *
     * @param cardId 员工ID
     * @return 员工
     */
    @Override
    public BsStaff selectBsStaffByCardId(String cardId) {
        return bsStaffMapper.selectBsStaffByCardId(cardId);
    }

    /**
     * 查询员工列表
     *
     * @param bsStaff 员工
     * @return 员工
     */
    @Override
    public List<BsStaff> selectBsStaffList(BsStaff bsStaff)
    {
        List<BsStaff> list = bsStaffMapper.selectBsStaffList(bsStaff);
        // 赋值对应的标签
        if(!CollectionUtils.isEmpty(list)) {
            list.stream().forEach(t->{
                List<Long> postIds = bsStaffPostService.selectStaffPostListByStaffId(t.getStaffId());
                if(!CollectionUtils.isEmpty(postIds)) {
                    Long[] posts = new Long[postIds.size()];
                    for (int i = 0; i < postIds.size(); i++) {
                        posts[i] = Long.valueOf(postIds.get(i));
                    }
                    t.setPostIds(posts);
                }
            });
        }
        return list;
    }

    /**
     * 新增员工
     *
     * @param bsStaff 员工
     * @return 结果
     */
    @Override
    public int insertBsStaff(BsStaff bsStaff)
    {
        bsStaff.setCreateBy(SecurityUtils.getUsername());
        bsStaff.setCreateTime(DateUtils.getNowDate());
        int flag = bsStaffMapper.insertBsStaff(bsStaff);
        insertStaffStaffPost(bsStaff);
        faceDeviceService.addStaffToAllDevice(bsStaff);
        return flag;
    }

    /**
     * 修改员工
     *
     * @param bsStaff 员工
     * @return 结果
     */
    @Override
    public int updateBsStaff(BsStaff bsStaff)
    {
        Long staffId = bsStaff.getStaffId();
        // 删除员工和员工标签的关联
        bsStaffStaffPostMapper.deleteStaffStaffPostByStaffId(staffId);
        // 新增员工和标签中间表
        insertStaffStaffPost(bsStaff);
        bsStaff.setUpdateBy(SecurityUtils.getUsername());
        bsStaff.setUpdateTime(DateUtils.getNowDate());
        return bsStaffMapper.updateBsStaff(bsStaff);
    }

    /**
     * 批量删除员工
     *
     * @param staffIds 需要删除的员工ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffByIds(Long[] staffIds)
    {
        bsStaffStaffPostMapper.deleteStaffStaffPost(staffIds);
        // 删除设备中的人脸信息
        if(staffIds!=null && staffIds.length>0) {
            for (int i = 0; i < staffIds.length; i++) {
                faceDeviceService.removeStaffFromAllDevice(String.valueOf(staffIds[i]));
            }
        }
        // 删除人脸底库
        return bsStaffMapper.deleteBsStaffByIds(staffIds);
    }

    /**
     * 删除员工信息
     *
     * @param staffId 员工ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffById(Long staffId)
    {
        // 删除员工标签的关联
        bsStaffStaffPostMapper.deleteStaffStaffPostByStaffId(staffId);
        // 从设备移除人脸像
        faceDeviceService.removeStaffFromAllDevice(String.valueOf(staffId));
        // 删除人脸库
        return bsStaffMapper.deleteBsStaffById(staffId);
    }

    /**
     * 根据标签列表查询员工列表
     *
     * @param postIds
     * @return 员工集合
     */
    @Override
    public List<BsStaff> selectBsStaffListByPostIds(List<Long> postIds) {
        return bsStaffMapper.selectBsStaffListByPostIds(postIds);
    }

    /**
     * 新增员工标签信息
     *
     * @param staff 访客对象
     */
    public void insertStaffStaffPost(BsStaff staff)
    {
        Long[] posts = staff.getPostIds();
        if (StringUtils.isNotNull(posts))
        {
            // 新增访客与标签管理
            List<BsStaffStaffPost> list = new ArrayList<BsStaffStaffPost>();
            for (Long postId : posts)
            {
                BsStaffStaffPost up = new BsStaffStaffPost();
                up.setStaffId(staff.getStaffId());
                up.setPostId(postId);
                list.add(up);
            }
            if (list.size() > 0)
            {
                bsStaffStaffPostMapper.batchStaffStaffPost(list);
            }
        }
    }


}