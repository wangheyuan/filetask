package com.drin.smartpark.project.access.controller;

import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.common.tool.SecurityUtils;
import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.framework.page.TableDataInfo;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.access.service.IBsVisitorService;
import com.drin.smartpark.project.system.service.SysPostService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 访客信息管理Controller
 *
 * @author wangheyuan
 * @date 2020-09-02
 */
@RestController
@RequestMapping("/access/visitor")
public class BsVisitorController extends BaseController
{
    @Autowired
    private IBsVisitorService bsVisitorService;

    @Autowired
    private SysPostService postService;

    /**
     * 查询访客信息管理列表
     */
    @RequiresPermissions("access:visitor:list")
    @GetMapping("/list")
    public TableDataInfo list(BsVisitor bsVisitor)
    {
        startPage();
        // 访客类型为1
        bsVisitor.setVisitorType("1");
        List<BsVisitor> list = bsVisitorService.selectBsVisitorList(bsVisitor);
        return getDataTable(list);
    }

    /**
     * 导出访客信息管理列表
     */
    @RequiresPermissions("access:visitor:export")
    @Log(title = "访客信息管理", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsVisitor bsVisitor)
    {
        // 访客类型为1
        bsVisitor.setVisitorType("1");
        List<BsVisitor> list = bsVisitorService.selectBsVisitorList(bsVisitor);
        ExcelUtil<BsVisitor> util = new ExcelUtil<BsVisitor>(BsVisitor.class);
        return util.exportExcel(list, "visitor");
    }

    /**
     * 根据访客编号获取详细标签信息
     */
    @RequiresPermissions("access:visitor:query")
    @GetMapping(value = { "/", "/{visitorId}" })
    public RestResp getPost(@PathVariable(value = "visitorId", required = false) Long visitorId)
    {
        RestResp ajax = RestResp.success();
        ajax.put("posts", postService.selectPostAll());
        if (StringUtils.isNotNull(visitorId))
        {
            ajax.put(RestResp.DATA_TAG, bsVisitorService.selectBsVisitorById(visitorId));
            ajax.put("postIds", postService.selectPostListByVisitorId(visitorId));
        }
        return ajax;
    }


    /**
     * 新增访客信息管理
     */
    @RequiresPermissions("access:visitor:add")
    @Log(title = "访客信息管理", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsVisitor bsVisitor)
    {
        // 访客类型为1
        bsVisitor.setVisitorType("1");
        return toAjax(bsVisitorService.insertBsVisitor(bsVisitor));
    }

    /**
     * 修改访客信息管理
     */
    @RequiresPermissions("access:visitor:edit")
    @Log(title = "访客信息管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsVisitor bsVisitor)
    {
        bsVisitor.setUpdateBy(SecurityUtils.getUsername());
        return toAjax(bsVisitorService.updateBsVisitor(bsVisitor));
    }

    /**
     * 删除访客信息管理
     */
    @RequiresPermissions("access:visitor:remove")
    @Log(title = "访客信息管理", businessType = BusinessType.DELETE)
    @DeleteMapping("/{visitorIds}")
    public RestResp remove(@PathVariable Long[] visitorIds)
    {
        // 这里需要加安全判断，防止删除访客的时候删除掉了用户
        return toAjax(bsVisitorService.deleteBsVisitorByIds(visitorIds));
    }
}