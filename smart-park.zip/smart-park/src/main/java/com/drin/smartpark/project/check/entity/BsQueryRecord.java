package com.drin.smartpark.project.check.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.drin.smartpark.framework.excel.annotation.Excel;
import com.drin.smartpark.common.BaseEntity;

/**
 * 考勤管理对象 bs_query_record
 *
 * @author kano
 * @date 2020-12-25
 */
public class BsQueryRecord extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 查询记录ID */
    private Long recordId;

    /** 操作者 */
    @Excel(name = "操作者")
    private String operatorName;

    /** 查询姓名 */
    @Excel(name = "查询姓名")
    private String queryName;

    /** 查询员工的id */
    @Excel(name = "查询员工的id")
    private Long queryId;

    /** 查询开始时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "查询开始时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date queryBeginTime;

    /** 查询结束时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "查询结束时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date queryEndTime;

    public void setRecordId(Long recordId)
    {
        this.recordId = recordId;
    }

    public Long getRecordId()
    {
        return recordId;
    }
    public void setOperatorName(String operatorName)
    {
        this.operatorName = operatorName;
    }

    public String getOperatorName()
    {
        return operatorName;
    }
    public void setQueryName(String queryName)
    {
        this.queryName = queryName;
    }

    public String getQueryName()
    {
        return queryName;
    }
    public void setQueryId(Long queryId)
    {
        this.queryId = queryId;
    }

    public Long getQueryId()
    {
        return queryId;
    }
    public void setQueryBeginTime(Date queryBeginTime)
    {
        this.queryBeginTime = queryBeginTime;
    }

    public Date getQueryBeginTime()
    {
        return queryBeginTime;
    }
    public void setQueryEndTime(Date queryEndTime)
    {
        this.queryEndTime = queryEndTime;
    }

    public Date getQueryEndTime()
    {
        return queryEndTime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("recordId", getRecordId())
                .append("operatorName", getOperatorName())
                .append("queryName", getQueryName())
                .append("queryId", getQueryId())
                .append("queryBeginTime", getQueryBeginTime())
                .append("queryEndTime", getQueryEndTime())
                .append("createTime", getCreateTime())
                .append("createBy", getCreateBy())
                .toString();
    }
}