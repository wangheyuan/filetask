package com.drin.smartpark.project.check.service;

import java.util.List;

import com.drin.smartpark.project.access.entity.BsDept;
import com.drin.smartpark.project.check.entity.BsStaffDept;
import com.drin.smartpark.project.system.model.TreeSelect;

/**
 * 员工部门管理Service接口
 *
 * @author wangheyuan
 * @date 2020-11-19
 */
public interface IBsStaffDeptService
{
    /**
     * 查询员工部门管理
     *
     * @param deptId 员工部门管理ID
     * @return 员工部门管理
     */
    public BsStaffDept selectBsStaffDeptById(Long deptId);

    /**
     * 查询员工部门管理列表
     *
     * @param bsStaffDept 员工部门管理
     * @return 员工部门管理集合
     */
    public List<BsStaffDept> selectBsStaffDeptList(BsStaffDept bsStaffDept);

    /**
     * 新增员工部门管理
     *
     * @param bsStaffDept 员工部门管理
     * @return 结果
     */
    public int insertBsStaffDept(BsStaffDept bsStaffDept);

    /**
     * 修改员工部门管理
     *
     * @param bsStaffDept 员工部门管理
     * @return 结果
     */
    public int updateBsStaffDept(BsStaffDept bsStaffDept);

    /**
     * 批量删除员工部门管理
     *
     * @param deptIds 需要删除的员工部门管理ID
     * @return 结果
     */
    public int deleteBsStaffDeptByIds(Long[] deptIds);

    /**
     * 删除员工部门管理信息
     *
     * @param deptId 员工部门管理ID
     * @return 结果
     */
    public int deleteBsStaffDeptById(Long deptId);


    /**
     * 把部门列表转换成树状列表
     *
     * @param depts 员工部门管理ID
     * @return 结果
     */
    public List<TreeSelect> buildDeptTreeSelect(List<BsStaffDept> depts);

    /**
     * 通过策略id获取绑定的部门
     * @param plicyId
     * @return java.util.List<java.lang.Long>
     *
     * @date 2020/12/2 14:15
     */
    public List<Long> selectBsCheckPlicyDeptListByPlicyId(Long plicyId);
}