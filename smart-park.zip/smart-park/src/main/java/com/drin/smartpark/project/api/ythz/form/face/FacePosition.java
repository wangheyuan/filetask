/**
 * 文件名称:          	FacePosition
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.face;

import lombok.Data;

/**
 * 人脸框
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 14:29
 */
@Data
public class FacePosition {
    private Integer height;
    private Integer width;
    private Integer x;
    private Integer y;
}
