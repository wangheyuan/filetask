package com.drin.smartpark.project.api.zdzj.model.resp;

import com.drin.smartpark.project.api.zdzj.model.resp.sub.AddPersonSubResp;
import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/8/31 14:35
 * @描述: 添加人员的响应体
 */
@Data
public class AddPersonResp {
    private String operator;
    private Integer code;
    private AddPersonSubResp info;
}
