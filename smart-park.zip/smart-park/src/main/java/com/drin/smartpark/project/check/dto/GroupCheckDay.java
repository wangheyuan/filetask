/**
 * 文件名称:          	GroupCheckDay
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.dto;

import com.drin.smartpark.framework.excel.annotation.Excel;
import lombok.Data;

/**
 * 每日考勤分组
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/12/29 14:04
 */
@Data
public class GroupCheckDay {

    private Long staffId;

    /** 员工名称 */
    @Excel(name = "员工名称")
    private String staffName;

    /** 工号 */
    @Excel(name = "工号")
    private String staffCard;

    /** 照片 */
    @Excel(name = "照片")
    private String imageId;

    /** 工作天数 */
    @Excel(name = "工作天数")
    private Integer normalDay;

    /** 异常天数 */
    @Excel(name = "异常天数")
    private Integer errorDay;

    /** 状态 */
    @Excel(name = "状态")
    private String status;

}
