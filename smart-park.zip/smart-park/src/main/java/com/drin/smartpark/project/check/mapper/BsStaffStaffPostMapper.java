/**
 * 文件名称:          	BsStaffStaffPostMapper
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.check.entity.BsStaffStaffPost;

import java.util.List;

/**
 * 处理员工与标签直接的关联
 * <p>
 * Version		1.0.0
 *
 * @author wangheyuan
 * <p>
 * Date	      2020/11/21 21:47
 */
public interface BsStaffStaffPostMapper extends BaseMapper<BsStaffStaffPost> {

    /**
     * 通过访客ID删除员工和标签关联
     *
     * @param staffId 访客ID
     * @return 结果
     */
    public int deleteStaffStaffPostByStaffId(Long staffId);

    /**
     * 通过标签ID查询标签使用数量
     *
     * @param postId 标签ID
     * @return 结果
     */
    public int countStaffStaffPostById(Long postId);

    /**
     * 批量删除员工和标签关联
     *
     * @param ids 需要删除的数据员工ID
     * @return 结果
     */
    public int deleteStaffStaffPost(Long[] ids);

    /**
     * 批量新增员工标签信息
     *
     * @param staffPostList 访客角色列表
     * @return 结果
     */
    public int batchStaffStaffPost(List<BsStaffStaffPost> staffPostList);


}