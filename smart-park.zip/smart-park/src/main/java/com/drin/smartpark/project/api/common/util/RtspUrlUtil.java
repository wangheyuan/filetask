/**
 * 文件名称:          	RtspUrlUtil
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.common.util;

import com.drin.smartpark.common.tool.StringUtils;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/4 15:41
 */
public class RtspUrlUtil {

    public static String getIpByRtspUrl(String url) {
        if(url!=null) {
            String[] str = url.split("@");
            if(str.length==2) {
                return str[1];
            }
        }
        return null;
    }

    public static String getPasswordByRtspUrl(String url) {
        if(url!=null) {
            String[] str = url.split("@");
            if(str.length==2) {
                String pre = str[0];
                String[] pres = pre.split(":");
                if(pres.length == 3) {
                    return pres[2];
                }
            }
        }
        return null;
    }

    public  static String getAccountByRtspUrl(String url) {
        if(url!=null) {
            String[] str = url.split("@");
            if(str.length==2) {
                String pre = str[0];
                String[] pres = pre.split(":");
                if(pres.length == 3) {
                    String host=  pres[1];
                    if(host.length()>=3) {
                        return host.substring(2);
                    }
                }
            }
        }
        return null;
    }

    public static String getRtspByIpAndAccount(String ip,String account,String password) {
        if(!StringUtils.isEmpty(ip)&& ip.contains("rtsp://")) {
            String[] ipStr = ip.split("rtsp://");
            if(ipStr.length==2) {
                return "rtsp://"+account+":"+password+"@"+ipStr[1];
            }
        }
        return ip;
    }
}
