/**
 * 文件名称:          	DeviceService
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj.service;

import com.drin.smartpark.project.access.entity.BsDevice;
import com.drin.smartpark.project.access.service.IBsDeviceService;
import com.drin.smartpark.project.api.zdzj.DeviceApi;
import com.drin.smartpark.project.api.zdzj.model.resp.DeviceResp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.List;

/**
 * 设备的业务信息
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/3 9:34
 */
@Service
public class DeviceService {

    @Autowired
    private FaceRetrofitService faceRetrofitService;

    @Autowired
    private IBsDeviceService bsDeviceService;

    //获取设备ID
    public Integer getDeviceID() {
        List<BsDevice> bsDevices = bsDeviceService.selectBsDeviceList(new BsDevice());
        if (!CollectionUtils.isEmpty(bsDevices)) {
            for (int i = 0; i < bsDevices.size(); i++) {
                DeviceApi deviceApi = faceRetrofitService.getApiByIPService(bsDevices.get(i).getDeviceIp(), DeviceApi.class);
                Integer deviceID = null;
                try {
                    DeviceResp result = deviceApi.getDeviceInfo().execute().body();
                    deviceID = result.getInfo().getDeviceID();
                    return deviceID;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

}
