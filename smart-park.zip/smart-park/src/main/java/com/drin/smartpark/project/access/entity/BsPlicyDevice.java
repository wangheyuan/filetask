/**
 * 文件名称:          	BsPlicyDevice
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.access.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 策略设备表
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/4 1:39
 */
public class BsPlicyDevice {

    /** 策略ID */
    private Long plicyId;

    /** 岗位ID */
    private Long deviceId;

    public Long getPlicyId()
    {
        return plicyId;
    }

    public void setPlicyId(Long plicyId)
    {
        this.plicyId = plicyId;
    }

    public Long getDeviceId()
    {
        return deviceId;
    }

    public void setDeviceId(Long deviceId)
    {
        this.deviceId = deviceId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("plicyId", getPlicyId())
                .append("deviceId", getDeviceId())
                .toString();
    }

}
