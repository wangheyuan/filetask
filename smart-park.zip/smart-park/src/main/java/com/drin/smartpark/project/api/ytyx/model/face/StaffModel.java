/**
 * 文件名称:          	StaffModel
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.face;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * 员工实体
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/18 2:22
 */
@Data
public class StaffModel {

    private List<String> card_numbers = new ArrayList<>();
    private String dept_id;
    private List<FaceInfo> face_list;
    private String identity;
    private PersonInfo person_information;
    private String staff_id;
    private List<String> tag_id_list;
    private Integer upload_time;

}
