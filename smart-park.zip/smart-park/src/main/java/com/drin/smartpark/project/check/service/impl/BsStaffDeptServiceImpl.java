package com.drin.smartpark.project.check.service.impl;

import java.util.*;
import java.util.stream.Collectors;

import com.drin.smartpark.common.constant.UserConstants;
import com.drin.smartpark.common.exception.CustomException;
import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.common.tool.SecurityUtils;
import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.project.access.entity.BsDept;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.entity.BsStaff;
import com.drin.smartpark.project.check.mapper.BsCheckPlicyDeptMapper;
import com.drin.smartpark.project.system.entity.SysDept;
import com.drin.smartpark.project.system.model.TreeSelect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.drin.smartpark.project.check.mapper.BsStaffDeptMapper;
import com.drin.smartpark.project.check.entity.BsStaffDept;
import com.drin.smartpark.project.check.service.IBsStaffDeptService;
import org.springframework.util.CollectionUtils;

/**
 * 员工部门管理Service业务层处理
 *
 * @author wangheyuan
 * @date 2020-11-19
 */
@Service
public class BsStaffDeptServiceImpl implements IBsStaffDeptService
{
    @Autowired
    private BsStaffDeptMapper bsStaffDeptMapper;

    /**
     * 查询员工部门管理
     *
     * @param deptId 员工部门管理ID
     * @return 员工部门管理
     */
    @Override
    public BsStaffDept selectBsStaffDeptById(Long deptId)
    {
        return bsStaffDeptMapper.selectBsStaffDeptById(deptId);
    }

    /**
     * 查询员工部门管理列表
     *
     * @param bsStaffDept 员工部门管理
     * @return 员工部门管理
     */
    @Override
    public List<BsStaffDept> selectBsStaffDeptList(BsStaffDept bsStaffDept)
    {
        return bsStaffDeptMapper.selectBsStaffDeptList(bsStaffDept);
    }

    /**
     * 新增员工部门管理
     *
     * @param bsStaffDept 员工部门管理
     * @return 结果
     */
    @Override
    public int insertBsStaffDept(BsStaffDept bsStaffDept)
    {
        BsStaffDept info = bsStaffDeptMapper.selectBsStaffDeptById(bsStaffDept.getParentId());
        if(info ==null ) {
            bsStaffDept.setAncestors("");
        }else {
            bsStaffDept.setAncestors(info.getAncestors() + "," + bsStaffDept.getParentId());
        }
        bsStaffDept.setCreateBy(SecurityUtils.getUsername());
        bsStaffDept.setCreateTime(DateUtils.getNowDate());
        return bsStaffDeptMapper.insertBsStaffDept(bsStaffDept);
    }

    /**
     * 修改员工部门管理
     *
     * @param bsStaffDept 员工部门管理
     * @return 结果
     */
    @Override
    public int updateBsStaffDept(BsStaffDept bsStaffDept)
    {
        BsStaffDept newParentDept = bsStaffDeptMapper.selectBsStaffDeptById(bsStaffDept.getParentId());
        BsStaffDept oldDept = bsStaffDeptMapper.selectBsStaffDeptById(bsStaffDept.getDeptId());
        if (StringUtils.isNotNull(newParentDept) && StringUtils.isNotNull(oldDept))
        {
            String newAncestors = newParentDept.getAncestors() + "," + newParentDept.getDeptId();
            String oldAncestors = oldDept.getAncestors();
            bsStaffDept.setAncestors(newAncestors);
        }
        bsStaffDept.setUpdateBy(SecurityUtils.getUsername());
        bsStaffDept.setUpdateTime(DateUtils.getNowDate());
        return bsStaffDeptMapper.updateBsStaffDept(bsStaffDept);
    }

    /**
     * 批量删除员工部门管理
     *
     * @param deptIds 需要删除的员工部门管理ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffDeptByIds(Long[] deptIds)
    {
        // 循环删除
        Set<Long> idSet = new HashSet<>();
        List<TreeSelect> trees = buildDeptTreeSelect(bsStaffDeptMapper.selectBsStaffDeptList(new BsStaffDept()));
        if(deptIds!=null && deptIds.length>0) {
            for (int i = 0; i < deptIds.length; i++) {
                Long deptId = deptIds[i];
                TreeSelect dept = findTreeSelectById(trees,deptId);
                Long[] ids = getAllChildDeptIdByTreeSelect(dept);
                for (int i1 = 0; i1 < ids.length; i1++) {
                    idSet.add(ids[i1]);
                }

            }
        }
        // 利用set去重
        Long[] resultIds = new Long[idSet.size()];
        idSet.toArray(resultIds);
        return bsStaffDeptMapper.deleteBsStaffDeptByIds(resultIds);
    }

    /**
     * 删除员工部门管理信息
     *
     * @param deptId 员工部门管理ID
     * @return 结果
     */
    @Override
    public int deleteBsStaffDeptById(Long deptId)
    {
        List<TreeSelect> trees = buildDeptTreeSelect(bsStaffDeptMapper.selectBsStaffDeptList(new BsStaffDept()));
        TreeSelect dept = findTreeSelectById(trees,deptId);
        Long[] ids = getAllChildDeptIdByTreeSelect(dept);
        int flag = bsStaffDeptMapper.deleteBsStaffDeptByIds(ids);
        return flag;
    }

    /**
     * 递归查询树状表中的设备位置
     * @param trees
     * @return com.drin.smartpark.project.system.model.TreeSelect
     * @date 2020/11/25 10:21
     */
    private TreeSelect findTreeSelectById(List<TreeSelect> trees,Long deptId) {
        while(!CollectionUtils.isEmpty(trees)) {
            for (int i = 0; i < trees.size(); i++) {
                if(trees.get(i).getId().equals(deptId)) {
                    return trees.get(i);
                }
            }

            List<TreeSelect> childrens = new ArrayList<>();
            for (int i = 0; i < trees.size(); i++) {
                if(!CollectionUtils.isEmpty(trees.get(i).getChildren())) {
                    trees.get(i).getChildren().forEach(c->{
                        childrens.add(c);
                    });
                }
            }
            //重置当前寻找的列表
            trees = childrens;
        }
        return null;
    }


    /**
     * 获取树状设备列表
     *
     * @param depts
     * @return java.util.List<com.drin.smartpark.project.system.model.TreeSelect>
     * @author HIPAA
     * @date 2020/9/8 15:11
     */
    @Override
    public List<TreeSelect> buildDeptTreeSelect(List<BsStaffDept> depts) {
        List<BsStaffDept> deptTrees = buildDeptTree(depts);
        return deptTrees.stream().map(TreeSelect::new).collect(Collectors.toList());
    }

    /**
     * 通过策略id获取绑定的部门
     *
     * @param plicyId
     * @return java.util.List<java.lang.Long>
     * @date 2020/12/2 14:15
     */
    @Override
    public List<Long> selectBsCheckPlicyDeptListByPlicyId(Long plicyId) {

        return bsStaffDeptMapper.selectBsStaffDeptIdListByPlicyId(plicyId);
    }

    /**
     * 构建前端所需要树结构
     *
     * @param depts 部门列表
     * @return 树结构列表
     */
    public List<BsStaffDept> buildDeptTree(List<BsStaffDept> depts)
    {
        List<BsStaffDept> returnList = new ArrayList<BsStaffDept>();
        List<Long> tempList = new ArrayList<Long>();
        for (BsStaffDept dept : depts)
        {
            tempList.add(dept.getDeptId());
        }
        for (Iterator<BsStaffDept> iterator = depts.iterator(); iterator.hasNext();)
        {
            BsStaffDept dept = (BsStaffDept) iterator.next();
            // 如果是顶级节点, 遍历该父节点的所有子节点
            if (!tempList.contains(dept.getParentId()))
            {
                recursionFn(depts, dept);
                returnList.add(dept);
            }
        }
        if (returnList.isEmpty())
        {
            returnList = depts;
        }
        return returnList;
    }

    Long[] getAllChildDeptIdByTreeSelect(TreeSelect dept) {
        List<Long> idList = new ArrayList<>();
        idList.add(dept.getId());

        // 设备只能增加到顶级，所以设备最多只有二级
        List<TreeSelect> items = dept.getChildren();
        if(!CollectionUtils.isEmpty(items)) {
            items.stream().forEach(item->{
                idList.add(item.getId());
            });
        }

        Long[] ids = new Long[idList.size()];
        idList.toArray(ids);
        return  ids;
    }

    /**
     * 递归列表
     */
    private void recursionFn(List<BsStaffDept> list, BsStaffDept t)
    {
        // 得到子节点列表
        List<BsStaffDept> childList = getChildList(list, t);
        t.setChildren(childList);
        for (BsStaffDept tChild : childList)
        {
            if (hasChild(list, tChild))
            {
                recursionFn(list, tChild);
            }
        }
    }
    /**
     * 得到子节点列表
     */
    private List<BsStaffDept> getChildList(List<BsStaffDept> list, BsStaffDept t)
    {
        List<BsStaffDept> tlist = new ArrayList<BsStaffDept>();
        Iterator<BsStaffDept> it = list.iterator();
        while (it.hasNext())
        {
            BsStaffDept n = (BsStaffDept) it.next();
            if (StringUtils.isNotNull(n.getParentId()) && n.getParentId().longValue() == t.getDeptId().longValue())
            {
                tlist.add(n);
            }
        }
        return tlist;
    }

    /**
     * 判断是否有子节点
     */
    private boolean hasChild(List<BsStaffDept> list, BsStaffDept t)
    {
        return getChildList(list, t).size() > 0 ? true : false;
    }

    /*
     * 根据当前部门id 删除所有下面的部门id
     * @param DeptId
     * @return java.util.List<java.lang.Long>
     */
    private List<Long> getAllDeptIdByDeptId(Long deptId) {
        List<Long> result = new ArrayList<>();
        result.add(deptId);
        List<BsStaffDept> list = bsStaffDeptMapper.selectBsStaffDeptList(new BsStaffDept());
        BsStaffDept dept  =selectBsStaffDeptById(deptId);
        if(!CollectionUtils.isEmpty(list)) {
            List<BsStaffDept> childList =  getChildList(list,dept);
            if(!CollectionUtils.isEmpty(childList)) {
                childList.stream().forEach(t->{
                    result.add(t.getDeptId());
                });
            }
        }
        return result;
    }


}