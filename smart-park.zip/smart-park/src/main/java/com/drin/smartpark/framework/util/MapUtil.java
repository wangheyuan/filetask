/**
 * 文件名称:          	CommonUtil
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.framework.util;


import org.springframework.util.CollectionUtils;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 常用的工具类
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/30 15:20
 */
public class MapUtil {

    /**
     * 将Object对象里面的属性和值转化成Map对象
     *
     * @param obj
     * @return
     * @throws IllegalAccessException
     */
    public static Map<String, Object> objectToMap(Object obj)  {
        Map<String, Object> map = new HashMap<String,Object>();
        Class<?> clazz = obj.getClass();
        for (Field field : clazz.getDeclaredFields()) {
            field.setAccessible(true);
            String fieldName = field.getName();
            Object value = null;
            try {
                value = field.get(obj);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            // 如果类型是List<String>
            if( field.getType() == List.class ) {
               List<String> result = (List<String>) value;
               if(!CollectionUtils.isEmpty(result)) {
                   value = String.join(",",result);
               }else {
                   value = null;
               }
            }
            if(value!=null ) {
                map.put(fieldName, value);
            }
        }
        return map;
    }
}
