/**
 * 文件名称:          	RestCall
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.common;

import com.drin.smartpark.common.tool.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.Date;

/**
 * 自定义回调
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/28 16:56
 */
@Slf4j
public class RestCall<T> {
    private Call<T> icall;

    private Isuccess<T> isuccess;

    public RestCall(Call<T> call) {
        this.icall = call;
    }

    public RestCall<T> success(Isuccess<T> isuccess) {
        this.isuccess = isuccess;
        return this;
    }

    public void get() {
        icall.enqueue(new Callback<T>() {
                         @Override
                         public void onResponse(Call<T> call2, Response<T> response) {
                             System.out.println(new Date());
                             T result = response.body();
                             log.info("相应结果：{}",result.toString());
                             isuccess.onSuccess(result);

                         }

                         @Override
                         public void onFailure(Call<T> call2, Throwable throwable) {
                             log.info("相应结果：{}", JsonUtil.toJsonString(throwable.getMessage()));
                             isuccess.onSuccess(null);
                         }
                     }
        );
    }
}
