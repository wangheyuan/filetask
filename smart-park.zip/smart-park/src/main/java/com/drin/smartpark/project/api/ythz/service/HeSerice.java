/**
 * 文件名称:          	HeSerice
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.service;

import com.drin.smartpark.common.config.VistConfig;
import com.drin.smartpark.common.tool.FileToBase64;
import com.drin.smartpark.common.tool.JsonUtil;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.api.ythz.FaceApi;
import com.drin.smartpark.project.api.ythz.dto.face.FaceImageDto;
import com.drin.smartpark.project.api.ythz.form.FaceInsertForm;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.entity.BsStaff;
import com.drin.smartpark.project.check.mapper.BsCommonDeviceMapper;
import com.drin.smartpark.project.check.service.IBsCommonDeviceService;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.EOFException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 *  盒子的api
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/11/4 16:26
 */
@Slf4j
@Service
public class HeSerice {

    public static String ip ="http://172.16.25.166";

    @Autowired
    RetrofitService retrofitService;

    @Autowired
    private BsCommonDeviceMapper bsCommonDeviceMapper;

    /**
     * 增加人脸头像到设备
     * @param visitor
     * @return void
     * @author HIPAA
     * @date 2020/11/4 16:38
     */
    @SneakyThrows
    public void addVisitorFace(BsVisitor visitor) {
        FaceApi faceApi = retrofitService.getApiByIPService(ip,FaceApi.class);
        FaceInsertForm param = faceInsertForm(visitor);
        log.info("param:{}",param);
        try {
            faceApi.addFace("1", String.valueOf(visitor.getVisitorId()), param).execute();
        }catch (EOFException e) {
            log.info("盒子调用成功不返回任何数据");
        }
    }

    public void removeVisitorFace(String visitorId) {
        FaceApi faceApi = retrofitService.getApiByIPService(ip,FaceApi.class);
        try {
            faceApi.removeFace("1",visitorId).execute();
        } catch (IOException e) {
            log.info("盒子删除成功不会返回数据");
//            e.printStackTrace();
        }
    }

    private FaceInsertForm faceInsertForm(BsVisitor visitor) {
        String imageId = visitor.getImageId().replaceAll("/profile", "");
        String imagePath = VistConfig.getProfile() +"/"+ imageId;
        String imgBase64 = FileToBase64.encodeBase64File(imagePath);
        FaceImageDto faceImageDto = new FaceImageDto();
        faceImageDto.setContent(imgBase64);
        faceImageDto.setContent_type("JPEG");
        FaceInsertForm result = new FaceInsertForm();
        result.setFace_image(faceImageDto);
        Map<String,String> meta = new HashMap<String,String>();
        meta.put("name",visitor.getVisitorName());
        meta.put("id",visitor.getVisitorCard());
        result.setExtra_meta(JsonUtil.toJsonString(meta));
        return result;
    }

    public static String generateId() {
        Random random = new Random();
        return String.valueOf(System.currentTimeMillis()*1000+random.nextInt(999));
    }


    /**
     * 增加员工人脸信息到指定设备
     * @param device
     * @param staff
     * @date 2020/11/24 10:15
     */
    public void addStaffFace(BsCommonDevice device,BsStaff staff) {
        FaceApi faceApi = retrofitService.getApiByIPService(device.getDeviceIp(),FaceApi.class);
        FaceInsertForm param = faceInsertStaffForm(staff);
        log.info("param:{}",param);
        try {
            faceApi.addFace("1", String.valueOf(staff.getStaffId()), param).execute();
        }catch (EOFException e) {
            log.info("盒子调用成功不返回任何数据");
        }catch (IOException e) {
            log.info("盒子IO异常");
        }
    }
    
    /**
     * 增加人脸信息到所有设备
     * @param staff
     * @return void
     * @author HIPAA
     * @date 2020/11/24 10:20
     */
    public void addStaffFace(BsStaff staff) {
        
    }

    private FaceInsertForm faceInsertStaffForm(BsStaff visitor) {
        String imageId = visitor.getImageId().replaceAll("/profile", "");
        String imagePath = VistConfig.getProfile() +"/"+ imageId;
        String imgBase64 = FileToBase64.encodeBase64File(imagePath);
        FaceImageDto faceImageDto = new FaceImageDto();
        faceImageDto.setContent(imgBase64);
        faceImageDto.setContent_type("JPEG");
        FaceInsertForm result = new FaceInsertForm();
        result.setFace_image(faceImageDto);
        Map<String,String> meta = new HashMap<String,String>();
        meta.put("name",visitor.getStaffName());
        meta.put("id",String.valueOf(visitor.getStaffId()));
        result.setExtra_meta(JsonUtil.toJsonString(meta));
        return result;
    }






}
