/**
 * 文件名称:          	DeviceSubResp
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj.model.resp.sub;

import lombok.Data;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/3 13:54
 */
@Data
public class DeviceSubResp {
    //设备名称
    private String Name;
    //设备ID
    private Integer DeviceID;
    //设备版本
    private String Version;
}
