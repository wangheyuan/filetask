/**
 * 文件名称:          	YtyxServiceImpl
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.common.service.impl;

import com.drin.smartpark.common.config.VistConfig;
import com.drin.smartpark.common.tool.FileToBase64;
import com.drin.smartpark.framework.util.MapUtil;
import com.drin.smartpark.project.api.common.service.YtyxService;
import com.drin.smartpark.project.api.ythz.service.RetrofitService;
import com.drin.smartpark.project.api.ytyx.YtyxDeviceApi;
import com.drin.smartpark.project.api.ytyx.YtyxFaceApi;
import com.drin.smartpark.project.api.ytyx.dto.YtyxRestResp;
import com.drin.smartpark.project.api.ytyx.form.QueryDeviceListForm;
import com.drin.smartpark.project.api.ytyx.model.device.YtyxDevice;
import com.drin.smartpark.project.api.ytyx.model.face.PersonInfo;
import com.drin.smartpark.project.api.ytyx.model.face.StaffInfo;
import com.drin.smartpark.project.api.ytyx.model.face.StaffPostForm;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.entity.BsStaff;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 云悉的service
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/5 11:46
 */
@Service
public class YtyxServiceImpl implements YtyxService {

    // 处理盒子设备相关的
    @Autowired
    private RetrofitService retrofitService;

    /**
     * 获取云悉的子设备
     *
     * @param parentDevice
     * @return java.util.List<com.drin.smartpark.project.check.entity.BsCommonDevice>
     * @author HIPAA
     * @date 2021/1/5 11:47
     */
    @SneakyThrows
    @Override
    public List<BsCommonDevice> childDeviceList(BsCommonDevice parentDevice) {
        // 2次校验，只有为云悉类型的时候才会初始化
        retrofitService.tempInitDeviceService(parentDevice);
        YtyxDeviceApi deviceApi = retrofitService.getApiByIPService(parentDevice.getDeviceIp(),YtyxDeviceApi.class);
        QueryDeviceListForm param = new QueryDeviceListForm();
        param.setPage(0);
        param.setSize(0);
        YtyxRestResp<List<YtyxDevice>> deviceResp = deviceApi.deviceList(MapUtil.objectToMap(param)).execute().body();
        if(deviceResp.getRtn()==0) {
            List<BsCommonDevice> result = new ArrayList<>();
            List<YtyxDevice> devices= deviceResp.getResult();
            if(!CollectionUtils.isEmpty(devices)) {
                devices.stream().forEach(d->{
                    BsCommonDevice device = new BsCommonDevice();
                    device.setRealId(d.getDevice_id());
                    device.setParentId(parentDevice.getDeviceId());
                    device.setDeviceIp(d.getDevice_meta().getIp());
                    device.setDeviceName(d.getDevice_meta().getDevice_name());
                    // 状态和类型后面调整
                    device.setStatus("0");
                    device.setDeviceType("5");
                    result.add(device);
                });
                return result;
            }
        }

        return null;
    }

    /**
     * 云悉录入人员
     *
     * @param device
     * @param staff
     * @return void
     * @author HIPAA
     * @date 2021/1/5 11:31
     */
    @Override
    public void addStaffToDevice(BsCommonDevice device, BsStaff staff) {
        YtyxFaceApi faceApi = retrofitService.getApiByIPService(device.getDeviceIp(), YtyxFaceApi.class);
        StaffPostForm param = staffPostForm(staff);
        faceApi.addStaff(param);
    }

    /**
     * 云悉删除人员
     *
     * @param device
     * @param staffId
     * @return void
     * @author HIPAA
     * @date 2021/1/5 11:35
     */
    @Override
    public void removeStaffFromDevice(BsCommonDevice device, String staffId) {
        YtyxFaceApi faceApi = retrofitService.getApiByIPService(device.getDeviceIp(), YtyxFaceApi.class);
        faceApi.removeStaff(staffId);
    }

    private StaffPostForm staffPostForm(BsStaff staff) {
        StaffPostForm result = new StaffPostForm();

        StaffInfo staffInfo = new StaffInfo();

        PersonInfo info = new PersonInfo();
        info.setId(staff.getStaffCard());
        info.setName(staff.getStaffName());;

        staffInfo.setPerson_information(info);
        // 这里暂时是平和学校的标签，后期改成一个统一的标签
        staffInfo.setDept_id("5f34f20105209ce9cc8f2b2d");
        // 获取图片
        String imageId = staff.getImageId().replaceAll("/profile", "");
        String imagePath = VistConfig.getProfile() +"/"+ imageId;
        String imgBase64 = FileToBase64.encodeBase64File(imagePath);
        staffInfo.getFace_image_content_list().add(imgBase64);

        result.getStaff_list().add(staffInfo);

        return result;
    }
}
