package com.drin.smartpark.project.check.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import java.util.List;

import com.drin.smartpark.project.access.entity.BsVisitorPost;
import com.drin.smartpark.project.check.entity.BsStaffPost;
import com.drin.smartpark.project.system.entity.SysPost;

/**
 * 标签信息Mapper接口
 *
 * @author wangheyuan
 * @date 2020-11-20
 */
public interface BsStaffPostMapper  extends BaseMapper<BsStaffPost>
{
    /**
     * 查询标签信息
     *
     * @param postId 标签信息ID
     * @return 标签信息
     */
    public BsStaffPost selectBsStaffPostById(Long postId);

    /**
     * 查询标签信息列表
     *
     * @param bsStaffPost 标签信息
     * @return 标签信息集合
     */
    public List<BsStaffPost> selectBsStaffPostList(BsStaffPost bsStaffPost);

    /**
     * 新增标签信息
     *
     * @param bsStaffPost 标签信息
     * @return 结果
     */
    public int insertBsStaffPost(BsStaffPost bsStaffPost);

    /**
     * 修改标签信息
     *
     * @param bsStaffPost 标签信息
     * @return 结果
     */
    public int updateBsStaffPost(BsStaffPost bsStaffPost);

    /**
     * 删除标签信息
     *
     * @param postId 标签信息ID
     * @return 结果
     */
    public int deleteBsStaffPostById(Long postId);

    /**
     * 批量删除标签信息
     *
     * @param postIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsStaffPostByIds(Long[] postIds);

    /**
     * 查询所有标签
     *
     * @return 岗位列表
     */
    public List<BsStaffPost> selectStaffPostAll();

    /**
     * 根据员工ID获取标签选择框列表
     *
     * @param staffId 用户ID
     * @return 选中标签ID列表
     */
    public List<Long> selectStaffPostListByStaffId(Long staffId);

    /**
     * 根据策略ID获取标签选择框列表
     *
     * @param plicyId 策略ID
     * @return 选中标签ID列表
     */
    public List<Long> selectStaffPostListByPlicyId(Long plicyId);


}