/**
 * 文件名称:          	LoginApi
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx;

import com.drin.smartpark.project.api.ytyx.dto.YtyxRestResp;
import com.drin.smartpark.project.api.ytyx.model.login.YtyxUserLoginForm;
import com.drin.smartpark.project.api.ytyx.model.login.UserLoginResp;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * 云悉登录
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/17 11:57
 */
public interface YtyxLoginApi {

    @POST("park/website/login")
    Call<YtyxRestResp<UserLoginResp>> login(@Body YtyxUserLoginForm param);


}