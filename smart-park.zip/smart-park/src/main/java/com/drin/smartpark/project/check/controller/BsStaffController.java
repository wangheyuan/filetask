package com.drin.smartpark.project.check.controller;

import java.util.List;

import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.project.check.service.IBsStaffPostService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.project.check.entity.BsStaff;
import com.drin.smartpark.project.check.service.IBsStaffService;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.page.TableDataInfo;

/**
 * 员工Controller
 *
 * @author wangheyuan
 * @date 2020-11-20
 */
@RestController
@RequestMapping("/check/staff")
public class BsStaffController extends BaseController
{
    @Autowired
    private IBsStaffService bsStaffService;

    @Autowired
    private IBsStaffPostService bsStaffPostService;

    /**
     * 查询员工列表
     */
    @RequiresPermissions("check:staff:list")
    @GetMapping("/list")
    public TableDataInfo list(BsStaff bsStaff)
    {
        startPage();
        List<BsStaff> list = bsStaffService.selectBsStaffList(bsStaff);
        return getDataTable(list);
    }

    /**
     * 导出员工列表
     */
    @RequiresPermissions("check:staff:export")
    @Log(title = "员工", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsStaff bsStaff)
    {
        List<BsStaff> list = bsStaffService.selectBsStaffList(bsStaff);
        ExcelUtil<BsStaff> util = new ExcelUtil<BsStaff>(BsStaff.class);
        return util.exportExcel(list, "staff");
    }

    /**
     * 获取员工详细信息
     */
    @RequiresPermissions("check:staff:query")
    @GetMapping(value = {"/","/{staffId}"})
    public RestResp getInfo(@PathVariable(value = "staffId" , required = false) Long staffId)
    {
        RestResp ajax = RestResp.success();
        ajax.put("posts",bsStaffPostService.selectBsStaffPostAll());
        if (StringUtils.isNotNull(staffId)) {
            ajax.put(RestResp.DATA_TAG,bsStaffService.selectBsStaffById(staffId));
            ajax.put("postIds",bsStaffPostService.selectStaffPostListByStaffId(staffId));
        }
        return ajax;
    }

    /**
     * 新增员工
     */
    @RequiresPermissions("check:staff:add")
    @Log(title = "员工", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsStaff bsStaff)
    {
        return toAjax(bsStaffService.insertBsStaff(bsStaff));
    }

    /**
     * 修改员工
     */
    @RequiresPermissions("check:staff:edit")
    @Log(title = "员工", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsStaff bsStaff)
    {
        return toAjax(bsStaffService.updateBsStaff(bsStaff));
    }

    /**
     * 删除员工
     */
    @RequiresPermissions("check:staff:remove")
    @Log(title = "员工", businessType = BusinessType.DELETE)
    @DeleteMapping("/{staffIds}")
    public RestResp remove(@PathVariable Long[] staffIds)
    {
        return toAjax(bsStaffService.deleteBsStaffByIds(staffIds));
    }
}