package com.drin.smartpark.project.access.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.access.entity.BsStaffHistory;

import java.util.List;

/**
 * 员工考勤历史列Mapper接口
 *
 * @author wangheyuan
 * @date 2020-11-05
 */
public interface BsStaffHistoryMapper  extends BaseMapper<BsStaffHistory>
{
    /**
     * 查询员工考勤历史列
     *
     * @param visitorId 员工考勤历史列ID
     * @return 员工考勤历史列
     */
    public BsStaffHistory selectBsStaffHistoryById(Long visitorId);

    /**
     * 查询员工考勤历史列列表
     *
     * @param bsStaffHistory 员工考勤历史列
     * @return 员工考勤历史列集合
     */
    public List<BsStaffHistory> selectBsStaffHistoryList(BsStaffHistory bsStaffHistory);

    /**
     * 新增员工考勤历史列
     *
     * @param bsStaffHistory 员工考勤历史列
     * @return 结果
     */
    public int insertBsStaffHistory(BsStaffHistory bsStaffHistory);

    /**
     * 修改员工考勤历史列
     *
     * @param bsStaffHistory 员工考勤历史列
     * @return 结果
     */
    public int updateBsStaffHistory(BsStaffHistory bsStaffHistory);

    /**
     * 删除员工考勤历史列
     *
     * @param visitorId 员工考勤历史列ID
     * @return 结果
     */
    public int deleteBsStaffHistoryById(Long visitorId);

    /**
     * 批量删除员工考勤历史列
     *
     * @param visitorIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsStaffHistoryByIds(Long[] visitorIds);
}