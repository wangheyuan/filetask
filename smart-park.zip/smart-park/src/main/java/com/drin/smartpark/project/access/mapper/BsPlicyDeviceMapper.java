/**
 * 文件名称:          	BsPlicyDeviceMapper
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.access.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.access.entity.BsPlicyDevice;

import java.util.List;

/**
 * 设备策略mapper
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/4 1:42
 */
public interface BsPlicyDeviceMapper extends BaseMapper<BsPlicyDevice> {
    /**
     * 通过策略ID删除策略和标签关联
     *
     * @param plicyId 策略ID
     * @return 结果
     */
    public int deletePlicyDeviceByPlicyId(Long plicyId);

    /**
     * 通过标签ID查询标签使用数量
     *
     * @param deviceId 标签ID
     * @return 结果
     */
    public int countPlicyDeviceById(Long deviceId);

    /**
     * 批量删除策略和标签关联
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deletePlicyDevice(Long[] ids);

    /**
     * 批量新增策略标签信息
     *
     * @param plicyDeviceList 策略角色列表
     * @return 结果
     */
    public int batchPlicyDevice(List<BsPlicyDevice> plicyDeviceList);

}