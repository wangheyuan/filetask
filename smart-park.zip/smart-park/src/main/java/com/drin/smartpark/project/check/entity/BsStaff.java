package com.drin.smartpark.project.check.entity;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.drin.smartpark.framework.excel.annotation.Excel;
import com.drin.smartpark.common.BaseEntity;

/**
 * 员工对象 bs_staff
 *
 * @author wangheyuan
 * @date 2020-11-20
 */
public class BsStaff extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编码 */
    private Long staffId;

    /** 部门 */
    @Excel(name = "部门")
    private Long deptId;

    /** 名称 */
    @Excel(name = "名称")
    private String staffName;

    /** 外部编码 */
    @Excel(name = "外部编码")
    private Long staffExternId;

    /** 工号 */
    @Excel(name = "工号")
    private String staffCard;

    /** 照片 */
    @Excel(name = "照片")
    private String imageId;

    /** 状态 */
    @Excel(name = "状态")
    private String status;

    /** 岗位组 */
    @TableField(exist = false)
    private Long[] postIds;


    /** 入职时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "入职时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date employTime;

    public void setStaffId(Long staffId)
    {
        this.staffId = staffId;
    }

    public Long getStaffId()
    {
        return staffId;
    }
    public void setDeptId(Long deptId)
    {
        this.deptId = deptId;
    }

    public Long getDeptId()
    {
        return deptId;
    }
    public void setStaffName(String staffName)
    {
        this.staffName = staffName;
    }

    public String getStaffName()
    {
        return staffName;
    }
    public void setStaffExternId(Long staffExternId)
    {
        this.staffExternId = staffExternId;
    }

    public Long getStaffExternId()
    {
        return staffExternId;
    }
    public void setStaffCard(String visitorCard)
    {
        this.staffCard = visitorCard;
    }

    public String getStaffCard()
    {
        return staffCard;
    }
    public void setImageId(String imageId)
    {
        this.imageId = imageId;
    }

    public String getImageId()
    {
        return imageId;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }
    public void setEmployTime(Date employTime)
    {
        this.employTime = employTime;
    }

    public Date getEmployTime()
    {
        return employTime;
    }

    public Long[] getPostIds()
    {
        return postIds;
    }

    public void setPostIds(Long[] postIds)
    {
        this.postIds = postIds;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("staffId", getStaffId())
                .append("deptId", getDeptId())
                .append("staffName", getStaffName())
                .append("staffExternId", getStaffExternId())
                .append("staffCard", getStaffCard())
                .append("imageId", getImageId())
                .append("status", getStatus())
                .append("employTime", getEmployTime())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}