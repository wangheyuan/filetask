/**
 * 文件名称:          	PullFaceRecordForm
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * 拉取和抓拍记录
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 11:14
 */
@Data
public class PullFaceRecordForm {
    /**string Enum: "capture" "retrieval" */
    private String mode;
    //人像姓名，支持模糊搜索。仅支持比对模式
    private String name = "";
    // 通道列表 是个数组需要逗号隔开
    private List<String> device_names = new ArrayList<>();
    // 时间开始点 毫秒
    private Long start_timestamp_ms = 1595489955000L;
    // 时间结束点 毫秒
    private Long end_timestamp_ms = 1596094755000L;
    // 起始记录的id
//    private Integer start_id = 0;
    // 记录多少条后开始
    private Integer start = 0;
    // 查询顺序，支持按时间或id排序 默认 asc
    private String order = "desc";
    // 返回多少条记录
    private Integer limit=1000;

}
