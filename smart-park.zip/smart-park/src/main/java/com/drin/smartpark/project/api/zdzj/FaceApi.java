/**
 * 文件名称:          	FaceApi
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj;

import com.drin.smartpark.project.api.zdzj.model.form.AddPersonForm;
import com.drin.smartpark.project.api.zdzj.model.form.DeletePersonForm;
import com.drin.smartpark.project.api.zdzj.model.form.DetectFaceForm;
import com.drin.smartpark.project.api.zdzj.model.form.SearchPersonListForm;
import com.drin.smartpark.project.api.zdzj.model.resp.AddPersonResp;
import com.drin.smartpark.project.api.zdzj.model.resp.DetectFaceResp;
import com.drin.smartpark.project.api.zdzj.model.resp.SearchPersonListResp;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * 设备人脸信息操作
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/3 10:10
 */
public interface FaceApi {

    //新增人脸名单
    @POST("action/AddPerson")
    Call<AddPersonResp> addFace(@Body AddPersonForm param);

    // 批量删除人脸名单
    @POST("action/DeletePerson")
    Call<Object> deleteFace(@Body DeletePersonForm param);

    @POST("action/DetectFaceFromPic")
    Call<DetectFaceResp> detectFace(@Body DetectFaceForm param);

    @POST("action/SearchPersonList")
    Call<SearchPersonListResp> searchPersonList(@Body SearchPersonListForm param);


}