package com.drin.smartpark.quartz.task;

import com.drin.smartpark.common.tool.JsonUtil;
import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.project.access.entity.BsDevice;
import com.drin.smartpark.project.access.entity.BsPassPlicy;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.access.service.IBsDeviceService;
import com.drin.smartpark.project.access.service.IBsPassPlicyService;
import com.drin.smartpark.project.access.service.IBsVisitorService;
import com.drin.smartpark.project.api.zdzj.service.FaceService;
import com.drin.smartpark.project.system.service.SysPostService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 定时任务调度测试
 * 
 * @author wangheyuan
 */
@Slf4j
@Component("ryTask")
public class RyTask
{
    @Autowired
    private IBsPassPlicyService passPlicyService;

    @Autowired
    private SysPostService postService;

    @Autowired
    private IBsVisitorService visitorService;

    @Autowired
    private FaceService faceService;





    @Autowired
    private IBsDeviceService deviceService;

    public void ryMultipleParams(String s, Boolean b, Long l, Double d, Integer i)
    {
        System.out.println(StringUtils.format("执行多参方法： 字符串类型{}，布尔类型{}，长整型{}，浮点型{}，整形{}", s, b, l, d, i));
    }

    public void ryParams(String params)
    {
        System.out.println("执行有参方法：" + params);
    }

    public void ryNoParams()
    {
        System.out.println("执行无参方法");
    }

    /**
     * 根据策略导入对应的人脸图像
     * @param id 传入策略id
     * @return void
     * @author HIPAA
     * @date 2020/9/7 9:26
     */
    public void vistImportPerson(Long id) {

        BsPassPlicy plicy = passPlicyService.selectBsPassPlicyById(id);
        // 0 是全天制，策略执行一次就好了，在修改访客内容的时候进行导入，策略中不进行任何操作
        if("0".equals(plicy.getPlicyType()))
            return;
        // 1 是 每周的制度
        List<Long> postIds = postService.selectPostListByPlicyId(plicy.getPlicyId());
        List<BsVisitor> visitorList = visitorService.selectBsVisitorListByPostIds(postIds);
        List<BsDevice> deviceList = deviceService.selectDeviceListByPlicyId(plicy.getPlicyId());

        LocalDateTime localDateTime = LocalDateTime.now();
        DayOfWeek week = localDateTime.getDayOfWeek();

        //当天是否有效
        if(isDayValid(week,plicy)) {
            System.out.println("导入人脸到人脸闸机");
            log.info("visitorList:{}", JsonUtil.toJsonString(visitorList));
            log.info("deviceList:{}", JsonUtil.toJsonString(deviceList));
//            faceService.addVisitorListToDevice(visitorList,deviceList);
        }

    }

    /**
     * 删除人脸信息
     * @param id
     * @return void
     * @author HIPAA
     * @date 2020/9/7 13:34
     */
    public void vistRemovePerson(Long id) {
        BsPassPlicy plicy = passPlicyService.selectBsPassPlicyById(id);
        // 0 是全天制，策略执行一次就好了，在修改访客内容的时候进行导入，策略中不进行任何操作
        if ("0".equals(plicy.getPlicyType()))
            return;
        // 1 是 每周的制度
        List<Long> postIds = postService.selectPostListByPlicyId(plicy.getPlicyId());
        List<BsVisitor> visitorList = visitorService.selectBsVisitorListByPostIds(postIds);
        List<BsDevice> deviceList = deviceService.selectDeviceListByPlicyId(plicy.getPlicyId());

        LocalDateTime localDateTime = LocalDateTime.now();
        DayOfWeek week = localDateTime.getDayOfWeek();
        //当天是否有效
        if (isDayValid(week, plicy)) {
//            faceService.deleteVisitorListFormDevice(visitorList, deviceList);
            log.info("从人脸闸机中删除人脸");
            log.info("visitorList:{}", JsonUtil.toJsonString(visitorList));
            log.info("deviceList:{}", JsonUtil.toJsonString(deviceList));

        }
    }

    /**
     * 如果星期没有选中就不执行，需要执行返回true
     * @param week
     * @param policy
     * @return boolean
     * @author HIPAA
     * @date 2020/9/7 10:43
     */
    private boolean isDayValid(DayOfWeek week, BsPassPlicy policy) {
        boolean flag = false;
        switch (week) {
            case MONDAY:
                if("1".equals(policy.getMonday())) {
                    flag=true;
                }
                break;
            case TUESDAY:
                if("1".equals(policy.getTuesday())) {
                    flag=true;
                }
                break;
            case WEDNESDAY:
                if("1".equals(policy.getWednesday())) {
                    flag=true;
                }
                break;
            case THURSDAY:
                if("1".equals(policy.getThursday())) {
                    flag=true;
                }
                break;
            case FRIDAY:
                if("1".equals(policy.getFriday())) {
                    flag=true;
                }
                break;
            case SATURDAY:
                if("1".equals(policy.getSaturday())) {
                    flag=true;
                }
                break;
            case SUNDAY:
                if("1".equals(policy.getSunday())) {
                    flag=true;
                }
                break;
        }
        return flag;
    }
}
