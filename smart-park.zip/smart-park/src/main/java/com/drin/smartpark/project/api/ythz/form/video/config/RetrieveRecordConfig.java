/**
 * 文件名称:          	RetrieveRecordConfig
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.video.config;

import lombok.Data;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/5 16:35
 */
@Data
public class RetrieveRecordConfig {
    private boolean enable_save_retrieve_record;
    private Integer retrieve_record_expire_in_days;
    private Integer max_retrieve_record;
}
