package com.drin.smartpark.project.access.entity;

import com.drin.smartpark.common.BaseEntity;
import com.drin.smartpark.framework.excel.annotation.Excel;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 员工考勤历史列对象 bs_staff_history
 *
 * @author wangheyuan
 * @date 2020-11-05
 */
public class BsStaffHistory extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 访客主键 */
    private Long visitorId;

    /** 访客名称 */
    @Excel(name = "访客名称")
    private String visitorName;

    /** $column.columnComment */
    @Excel(name = "访客名称")
    private String visitorCard;

    /** 访客照片id */
    @Excel(name = "访客照片id")
    private String imageId;

    /** 抓拍照片id */
    @Excel(name = "抓拍照片id")
    private String today;

    /** 场景照片id */
    @Excel(name = "场景照片id")
    private String num;

    /** 0正常 1 为黑名单 */
    @Excel(name = "0正常 1 为黑名单")
    private String status;

    /** $column.columnComment */
    private Date inTime;

    /** $column.columnComment */
    private Date outTime;

    public void setVisitorId(Long visitorId)
    {
        this.visitorId = visitorId;
    }

    public Long getVisitorId()
    {
        return visitorId;
    }
    public void setVisitorName(String visitorName)
    {
        this.visitorName = visitorName;
    }

    public String getVisitorName()
    {
        return visitorName;
    }
    public void setVisitorCard(String visitorCard)
    {
        this.visitorCard = visitorCard;
    }

    public String getVisitorCard()
    {
        return visitorCard;
    }
    public void setImageId(String imageId)
    {
        this.imageId = imageId;
    }

    public String getImageId()
    {
        return imageId;
    }
    public void setToday(String today)
    {
        this.today = today;
    }

    public String getToday()
    {
        return today;
    }
    public void setNum(String num)
    {
        this.num = num;
    }

    public String getNum()
    {
        return num;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }
    public void setInTime(Date inTime)
    {
        this.inTime = inTime;
    }

    public Date getInTime()
    {
        return inTime;
    }
    public void setOutTime(Date outTime)
    {
        this.outTime = outTime;
    }

    public Date getOutTime()
    {
        return outTime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("visitorId", getVisitorId())
                .append("visitorName", getVisitorName())
                .append("visitorCard", getVisitorCard())
                .append("imageId", getImageId())
                .append("today", getToday())
                .append("num", getNum())
                .append("status", getStatus())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("inTime", getInTime())
                .append("outTime", getOutTime())
                .toString();
    }
}