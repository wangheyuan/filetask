/**
 * 文件名称:          	DeceiveApi
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz;

import com.drin.smartpark.project.api.ythz.dto.ChannelConfigDto;
import com.drin.smartpark.project.api.ythz.dto.DeviceStatusDto;
import com.drin.smartpark.project.api.ythz.form.capture.CaptureChannelsConfig;
import com.drin.smartpark.project.api.ythz.form.video.config.CaptureRecordConfig;
import retrofit2.Call;
import retrofit2.http.*;

/**
 * 设备相关api
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/24 16:35
 */
public interface DeviceApi {

    @GET("nh_agent/v1/ipcs")
    Call<DeviceStatusDto> deviceStatus(@Query("channel_name") String cameraName);

    /**
     * 获取摄像头的配置
     * @date 2020/11/24 15:02
     */
    @GET("ops_agent/v1/applications/kassq.face/settings")
    Call<ChannelConfigDto> channelConfig();
    
    
    /**
     * 修改视频流的配置
     * @param param
     * @return retrofit2.Call<java.lang.String>
     * @author HIPAA
     * @date 2021/1/7 14:07
     */
    @Headers("Content-Type:application/json")
    @PUT("ops_agent/v1/applications/kassq.face/settings")
    Call<String> updateChannelConfig(@Body ChannelConfigDto param);

    /**
     * 获取摄像头抓拍机的配置
     * @param 
     * @return retrofit2.Call<com.drin.smartpark.project.api.ythz.form.capture.CaptureChannelsConfig>
     * @author HIPAA
     * @date 2021/1/7 15:21
     */
    @GET("ops_agent/v1/applications/capture.engine/settings")
    Call<CaptureChannelsConfig> channelCaptrueConfig();

    /**
     * 修改抓拍机的接口
     * @param 
     * @return retrofit2.Call<java.lang.String>
     * @author HIPAA
     * @date 2021/1/7 14:08
     */
    @Headers("Content-Type:application/json")
    @PUT("ops_agent/v1/applications/capture.engine/settings")
    Call<String> updateCaptureCamera(@Body CaptureChannelsConfig param);



}