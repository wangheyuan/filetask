/**
 * 文件名称:          	BsCheckPlicyMapper
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.check.dto.QueryCheckPlicyParam;
import com.drin.smartpark.project.check.entity.BsCheckPlicy;

import java.util.List;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/11/25 11:51
 */
public interface BsCheckPlicyMapper  extends BaseMapper<BsCheckPlicy>
{
    /**
     * 查询策略列
     *
     * @param plicyId 策略列ID
     * @return 策略列
     */
    public BsCheckPlicy selectBsCheckPlicyById(Long plicyId);


    public List<BsCheckPlicy> selectBsCheckPlicyListByIds(List<Long> plicyIds);

    /**
     * 查询策略列列表
     *
     * @param bsCheckPlicy 策略列
     * @return 策略列集合
     */
    public List<BsCheckPlicy> selectBsCheckPlicyList(BsCheckPlicy bsCheckPlicy);

    /**
     * 根据设备，标签，部门查询对应的策略信息列表
     * @param param
     * @return java.util.List<com.drin.smartpark.project.check.entity.BsCheckPlicy>
     * @author HIPAA
     * @date 2020/12/4 13:58
     */
    public List<Long> selectBsCheckPlicyByParam(QueryCheckPlicyParam param);

    /**
     * 新增策略列
     *
     * @param bsCheckPlicy 策略列
     * @return 结果
     */
    public int insertBsCheckPlicy(BsCheckPlicy bsCheckPlicy);

    /**
     * 修改策略列
     *
     * @param bsCheckPlicy 策略列.
     *
     *
     * @return 结果
     */
    public int updateBsCheckPlicy(BsCheckPlicy bsCheckPlicy);

    /**
     * 删除策略列
     *
     * @param plicyId 策略列ID
     * @return 结果
     */
    public int deleteBsCheckPlicyById(Long plicyId);

    /**
     * 批量删除策略列
     *
     * @param plicyIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsCheckPlicyByIds(Long[] plicyIds);
}