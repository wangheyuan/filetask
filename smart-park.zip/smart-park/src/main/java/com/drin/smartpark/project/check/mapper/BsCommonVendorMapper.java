package com.drin.smartpark.project.check.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import java.util.List;
import com.drin.smartpark.project.check.entity.BsCommonVendor;

/**
 * 平台类型厂商Mapper接口
 *
 * @author wangheyuan
 * @date 2021-01-07
 */
public interface BsCommonVendorMapper  extends BaseMapper<BsCommonVendor>
{
    /**
     * 查询平台类型厂商
     *
     * @param vendorId 平台类型厂商ID
     * @return 平台类型厂商
     */
    public BsCommonVendor selectBsCommonVendorById(Long vendorId);

    /**
     * 查询平台类型厂商列表
     *
     * @param bsCommonVendor 平台类型厂商
     * @return 平台类型厂商集合
     */
    public List<BsCommonVendor> selectBsCommonVendorList(BsCommonVendor bsCommonVendor);

    /**
     * 新增平台类型厂商
     *
     * @param bsCommonVendor 平台类型厂商
     * @return 结果
     */
    public int insertBsCommonVendor(BsCommonVendor bsCommonVendor);

    /**
     * 修改平台类型厂商
     *
     * @param bsCommonVendor 平台类型厂商
     * @return 结果
     */
    public int updateBsCommonVendor(BsCommonVendor bsCommonVendor);

    /**
     * 删除平台类型厂商
     *
     * @param vendorId 平台类型厂商ID
     * @return 结果
     */
    public int deleteBsCommonVendorById(Long vendorId);

    /**
     * 批量删除平台类型厂商
     *
     * @param vendorIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsCommonVendorByIds(Long[] vendorIds);
}