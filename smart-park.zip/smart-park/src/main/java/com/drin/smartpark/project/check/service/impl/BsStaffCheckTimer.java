/**
 * 文件名称:          	BsStaffCheckTimer
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.service.impl;

import com.drin.smartpark.common.tool.JsonUtil;
import com.drin.smartpark.project.api.common.service.CommonFaceDeviceService;
import com.drin.smartpark.project.api.ythz.service.HeSerice;
import com.drin.smartpark.project.api.zdzj.service.FaceService;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.mapper.BsCommonDeviceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/11/24 9:58
 */
@Component
public class BsStaffCheckTimer {

    @Autowired
    private HeSerice heSerice;

    @Autowired
    private CommonFaceDeviceService faceDeviceService;

    @Autowired
    private BsCommonDeviceMapper commonDeviceMapper;

//    @Scheduled(fixedRate = 1000*60*60*24,initialDelay = 5000)
    public void test() {
        System.out.println("定时任务");

        List<BsCommonDevice> commonDevices = commonDeviceMapper.selectBsCommonDeviceList(new BsCommonDevice());
        if(!CollectionUtils.isEmpty(commonDevices)) {
            commonDevices.stream().forEach(device -> {
                faceDeviceService.childDeviceList(device);
            });

        }

//        System.out.println(JsonUtil.toJsonString(heSerice.));
    }


}
