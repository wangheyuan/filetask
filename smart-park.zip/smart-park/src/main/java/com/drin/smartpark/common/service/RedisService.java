package com.drin.smartpark.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 *  医保
 * <p>
 * Version		1.0.0
 *
 * @author wangheyuan
 * <p>
 * Date	      2020/4/17 12:29
 */
@Service
public class RedisService {
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    static ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();
    static Lock r = rwl.readLock();
    static Lock w = rwl.writeLock();

    public  String get(String key) {
        r.lock();
        String object = stringRedisTemplate.opsForValue().get(key);
        r.unlock();
        return object;
    }

    public  String put(String key,String value) {
        w.lock();
        stringRedisTemplate.opsForValue().set(key,value);
        w.unlock();
        return value;

    }

    public  String put_min(String key,String value,Integer minutes) {
        w.lock();
        stringRedisTemplate.opsForValue().set(key,value,minutes, TimeUnit.MINUTES);
        w.unlock();
        return value;

    }


}


