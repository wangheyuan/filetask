/**
 * 文件名称:          	Device
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 设备,记录名称和ip
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/28 11:17
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Device {
    private String name;
    private String ip;
}
