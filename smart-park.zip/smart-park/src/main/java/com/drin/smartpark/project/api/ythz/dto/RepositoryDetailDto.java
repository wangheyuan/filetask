/**
 * 文件名称:          	RepositroyDetail
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.dto;

import lombok.Data;

/**
 * 获取人脸库信息
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 10:22
 */
@Data
public class RepositoryDetailDto {

    private String extra_meta;
    private Integer face_number;
    private String name;
    private String summary;

}
