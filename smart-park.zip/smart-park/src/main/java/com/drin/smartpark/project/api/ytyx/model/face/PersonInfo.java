/**
 * 文件名称:          	PersonInfo
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.face;

import lombok.Data;

/**
 * 员工个人信息
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/18 2:20
 */
@Data
public class PersonInfo {

    private String id;
    private String name;
    private Integer accessType = 1;
    private String phone;
    private String remark;


}
