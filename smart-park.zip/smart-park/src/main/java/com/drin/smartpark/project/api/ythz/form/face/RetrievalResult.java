/**
 * 文件名称:          	RetrievalResult
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.face;

import lombok.Data;

/**
 * 获取比对的结果
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 14:49
 */
@Data
public class RetrievalResult {

    private CaptureResult capture_result;
    private HitPerson hit_person;
    private Long id;
    private Double similarity;
    private Long unix_timestamp_ms;

}
