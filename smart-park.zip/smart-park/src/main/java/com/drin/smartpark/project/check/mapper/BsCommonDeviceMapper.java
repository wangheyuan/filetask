package com.drin.smartpark.project.check.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import java.util.List;

import com.drin.smartpark.project.access.entity.BsDevice;
import com.drin.smartpark.project.check.entity.BsCommonDevice;

/**
 * 通用设备Mapper接口
 *
 * @author wangheyuan
 * @date 2020-11-23
 */
public interface BsCommonDeviceMapper  extends BaseMapper<BsCommonDevice>
{
    /**
     * 查询通用设备
     *
     * @param deviceId 通用设备ID
     * @return 通用设备
     */
    public BsCommonDevice selectBsCommonDeviceById(Integer deviceId);

    /**
     * 查询通用设备
     *
     * @param realId 第三方平台设备ID
     * @return 通用设备
     */
    public BsCommonDevice selectBsCommonDeviceByRealId(String realId);

    /**
     * 查询通用设备列表
     *
     * @param bsCommonDevice 通用设备
     * @return 通用设备集合
     */
    public List<BsCommonDevice> selectBsCommonDeviceList(BsCommonDevice bsCommonDevice);

    /**
     * 新增通用设备
     *
     * @param bsCommonDevice 通用设备
     * @return 结果
     */
    public int insertBsCommonDevice(BsCommonDevice bsCommonDevice);

    /**
     * 修改通用设备
     *
     * @param bsCommonDevice 通用设备
     * @return 结果
     */
    public int updateBsCommonDevice(BsCommonDevice bsCommonDevice);

    /**
     * 删除通用设备
     *
     * @param deviceId 通用设备ID
     * @return 结果
     */
    public int deleteBsCommonDeviceById(Long deviceId);

    /**
     * 批量删除通用设备
     *
     * @param deviceIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsCommonDeviceByIds(Long[] deviceIds);

    /**
     * 根据策略ID获取岗位选择框列表
     *
     * @param plicyId 策略ID
     * @return 选中标签ID列表
     */
    public List<BsDevice> selectCommonDeviceListByPlicyId(Long plicyId);

    /**
     * 根据策略ID获取标签选择框列表
     *
     * @param plicyId 策略ID
     * @return 选中标签ID列表
     */
    public List<Long> selectCommonDeviceIdListByPlicyId(Long plicyId);
}