package com.drin.smartpark.project.check.controller;

import java.util.List;

import com.drin.smartpark.project.check.dto.GroupCheckDay;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.project.check.entity.BsStaffCaptureDay;
import com.drin.smartpark.project.check.service.IBsStaffCaptureDayService;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.page.TableDataInfo;

/**
 * 每日考勤Controller
 *
 * @author wangheyuan
 * @date 2020-11-27
 */
@RestController
@RequestMapping("/check/checkDay")
public class BsStaffCaptureDayController extends BaseController
{
    @Autowired
    private IBsStaffCaptureDayService bsStaffCaptureDayService;

    /**
     * 查询每日考勤列表
     */
    @RequiresPermissions("check:checkDay:list")
    @GetMapping("/list")
    public TableDataInfo list(BsStaffCaptureDay bsStaffCaptureDay)
    {
        startPage();
        List<BsStaffCaptureDay> list = bsStaffCaptureDayService.selectBsStaffCaptureDayList(bsStaffCaptureDay);
        return getDataTable(list);
    }

    /**
     * 查询每日考勤分组列表
     */
    @RequiresPermissions("check:checkDay:list")
    @GetMapping("/groupList")
    public TableDataInfo groupList(BsStaffCaptureDay bsStaffCaptureDay)
    {
        startPage();
        List<GroupCheckDay> list = bsStaffCaptureDayService.selectBsStaffCaptureDayGroupList(bsStaffCaptureDay);
        return getDataTable(list);
    }

    /**
     * 导出每日考勤列表
     */
    @RequiresPermissions("check:checkDay:export")
    @Log(title = "每日考勤", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsStaffCaptureDay bsStaffCaptureDay)
    {
        List<BsStaffCaptureDay> list = bsStaffCaptureDayService.selectBsStaffCaptureDayList(bsStaffCaptureDay);
        ExcelUtil<BsStaffCaptureDay> util = new ExcelUtil<BsStaffCaptureDay>(BsStaffCaptureDay.class);
        return util.exportExcel(list, "checkDay");
    }

    /**
     * 获取每日考勤详细信息
     */
    @RequiresPermissions("check:checkDay:query")
    @GetMapping(value = "/{historyDayId}")
    public RestResp getInfo(@PathVariable("historyDayId") Long historyDayId)
    {
        return RestResp.success(bsStaffCaptureDayService.selectBsStaffCaptureDayById(historyDayId));
    }

    /**
     * 新增每日考勤
     */
    @RequiresPermissions("check:checkDay:add")
    @Log(title = "每日考勤", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsStaffCaptureDay bsStaffCaptureDay)
    {
        return toAjax(bsStaffCaptureDayService.insertBsStaffCaptureDay(bsStaffCaptureDay));
    }

    /**
     * 修改每日考勤
     */
    @RequiresPermissions("check:checkDay:edit")
    @Log(title = "每日考勤", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsStaffCaptureDay bsStaffCaptureDay)
    {
        return toAjax(bsStaffCaptureDayService.updateBsStaffCaptureDay(bsStaffCaptureDay));
    }

    /**
     * 删除每日考勤
     */
    @RequiresPermissions("check:checkDay:remove")
    @Log(title = "每日考勤", businessType = BusinessType.DELETE)
    @DeleteMapping("/{historyDayIds}")
    public RestResp remove(@PathVariable Long[] historyDayIds)
    {
        return toAjax(bsStaffCaptureDayService.deleteBsStaffCaptureDayByIds(historyDayIds));
    }
}