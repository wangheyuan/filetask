/**
 * 文件名称:          	BsCheckPlicyController
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.controller;

import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.framework.page.TableDataInfo;
import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.entity.BsCheckPlicy;
import com.drin.smartpark.project.check.entity.BsStaffDept;
import com.drin.smartpark.project.check.service.IBsCheckPlicyService;
import com.drin.smartpark.project.check.service.IBsCommonDeviceService;
import com.drin.smartpark.project.check.service.IBsStaffDeptService;
import com.drin.smartpark.project.check.service.impl.BsStaffPostServiceImpl;
import com.drin.smartpark.project.system.service.SysPostService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 策略列Controller
 *
 * @author wangheyuan
 * @date 2020-09-03
 */
@RestController
@RequestMapping("/check/plicy")
public class BsCheckPlicyController extends BaseController
{
    @Autowired
    private IBsCheckPlicyService bsCheckPlicyService;

    @Autowired
    private BsStaffPostServiceImpl postService;

    @Autowired
    private IBsCommonDeviceService deviceService;

    @Autowired
    private IBsStaffDeptService deptService;

    /**
     * 查询策略列列表
     */
    @RequiresPermissions("check:plicy:list")
    @GetMapping("/list")
    public TableDataInfo list(BsCheckPlicy bsCheckPlicy)
    {
        startPage();
        List<BsCheckPlicy> list = bsCheckPlicyService.selectBsCheckPlicyList(bsCheckPlicy);
        return getDataTable(list);
    }

    /**
     * 获取策略列详细信息
     */
    @RequiresPermissions("check:plicy:query")
    @GetMapping(value = {"/","/{plicyId}"})
    public RestResp getInfo(@PathVariable(value = "plicyId", required = false) Long plicyId)
    {
        RestResp restResp = RestResp.success();
        restResp.put("posts", postService.selectBsStaffPostAll());
        restResp.put("devices",deviceService.selectBsCommonDeviceList(new BsCommonDevice()));
        List<BsStaffDept> depts = deptService.selectBsStaffDeptList(new BsStaffDept());
        restResp.put("depts",depts);
        if (StringUtils.isNotNull(plicyId))
        {
            restResp.put(RestResp.DATA_TAG, bsCheckPlicyService.selectBsCheckPlicyById(plicyId));
            restResp.put("postIds", postService.selectStaffPostListByPlicyId(plicyId));
            restResp.put("deviceIds",deviceService.selectCommonDeviceIdListByPlicyId(plicyId));
            restResp.put("deptIds",deptService.selectBsCheckPlicyDeptListByPlicyId(plicyId));
        }

        return restResp;
    }

    /**
     * 新增策略列
     */
    @RequiresPermissions("check:plicy:add")
    @Log(title = "策略列", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsCheckPlicy bsCheckPlicy)
    {
        return toAjax(bsCheckPlicyService.insertBsCheckPlicy(bsCheckPlicy).intValue());
    }

    /**
     * 修改策略列
     */
    @RequiresPermissions("check:plicy:edit")
    @Log(title = "策略列", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsCheckPlicy bsCheckPlicy)
    {
        return toAjax(bsCheckPlicyService.updateBsCheckPlicy(bsCheckPlicy));
    }

    /**
     * 删除策略列
     */
    @RequiresPermissions("check:plicy:remove")
    @Log(title = "策略列", businessType = BusinessType.DELETE)
    @DeleteMapping("/{plicyIds}")
    public RestResp remove(@PathVariable Long[] plicyIds)
    {
        return toAjax(bsCheckPlicyService.deleteBsCheckPlicyByIds(plicyIds));
    }
}
