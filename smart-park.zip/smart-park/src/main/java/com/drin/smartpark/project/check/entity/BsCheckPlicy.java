/**
 * 文件名称:          	BsCheckPlicy
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.entity;

import com.drin.smartpark.common.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalTime;

/**
 * 考勤策略列对象 bs_check_plicy
 *
 * @author wangheyuan
 * @date 2020-09-03
 */
public class BsCheckPlicy  extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 策略主键 */
    private Long plicyId;

    /** 策略名称 */
    private String plicyName;

    /** 0为全时段 1为周选项 */
    private String plicyType;

    /** 0为正常 1为禁用 */
    private String plicyStatus;

    /** 星期1 ,0为未选中 1 为选中 */
    private String monday;

    /** 星期2 ,0为未选中 1 为选中 */
    private String tuesday;

    /** 星期3 ,0为未选中 1 为选中 */
    private String wednesday;

    /** 星期4 ,0为未选中 1 为选中 */
    private String thursday;

    /** 星期5 ,0为未选中 1 为选中 */
    private String friday;

    /** 星期6 ,0为未选中 1 为选中 */
    private String saturday;

    /** 星期7 ,0为未选中 1 为选中 */
    private String sunday;

    private Long[] postIds;

    private Long[] deviceIds;
    
    private  Long[] deptIds;

    @DateTimeFormat(pattern = "HH:mm:ss")
    private LocalTime startTime;

    @DateTimeFormat(pattern = "HH:mm:ss")
    private LocalTime finishTime;

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(LocalTime finishTime) {
        this.finishTime = finishTime;
    }

    public Long[] getPostIds() {
        return postIds;
    }

    public String getPlicyStatus() {
        return plicyStatus;
    }

    public void setPlicyStatus(String plicyStatus) {
        this.plicyStatus = plicyStatus;
    }

    public void setPostIds(Long[] postIds) {
        this.postIds = postIds;
    }

    public Long[] getDeviceIds() {
        return deviceIds;
    }

    public void setDeviceIds(Long[] deviceIds) {
        this.deviceIds = deviceIds;
    }

    public void setPlicyId(Long plicyId)
    {
        this.plicyId = plicyId;
    }

    public Long getPlicyId()
    {
        return plicyId;
    }
    public void setPlicyName(String plicyName)
    {
        this.plicyName = plicyName;
    }

    public String getPlicyName()
    {
        return plicyName;
    }
    public void setPlicyType(String plicyType)
    {
        this.plicyType = plicyType;
    }

    public String getPlicyType()
    {
        return plicyType;
    }
    public void setMonday(String monday)
    {
        this.monday = monday;
    }

    public String getMonday()
    {
        return monday;
    }
    public void setTuesday(String tuesday)
    {
        this.tuesday = tuesday;
    }

    public String getTuesday()
    {
        return tuesday;
    }
    public void setWednesday(String wednesday)
    {
        this.wednesday = wednesday;
    }

    public String getWednesday()
    {
        return wednesday;
    }
    public void setThursday(String thursday)
    {
        this.thursday = thursday;
    }

    public String getThursday()
    {
        return thursday;
    }
    public void setFriday(String friday)
    {
        this.friday = friday;
    }

    public String getFriday()
    {
        return friday;
    }
    public void setSaturday(String saturday)
    {
        this.saturday = saturday;
    }

    public String getSaturday()
    {
        return saturday;
    }
    public void setSunday(String sunday)
    {
        this.sunday = sunday;
    }

    public String getSunday()
    {
        return sunday;
    }

    public Long[] getDeptIds() {
        return deptIds;
    }

    public void setDeptIds(Long[] deptIds) {
        this.deptIds = deptIds;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("plicyId", getPlicyId())
                .append("plicyName", getPlicyName())
                .append("plicyType", getPlicyType())
                .append("monday", getMonday())
                .append("tuesday", getTuesday())
                .append("wednesday", getWednesday())
                .append("thursday", getThursday())
                .append("friday", getFriday())
                .append("saturday", getSaturday())
                .append("sunday", getSunday())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}
