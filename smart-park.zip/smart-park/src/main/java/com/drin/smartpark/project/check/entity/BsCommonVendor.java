package com.drin.smartpark.project.check.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.drin.smartpark.framework.excel.annotation.Excel;
import com.drin.smartpark.project.system.model.TreeEntity;

/**
 * 平台类型厂商对象 bs_common_vendor
 *
 * @author wangheyuan
 * @date 2021-01-07
 */
public class BsCommonVendor extends TreeEntity
{
    private static final long serialVersionUID = 1L;

    /** 厂商或者平台类型 */
    private Long vendorId;

    /** 厂商实际值 */
    @Excel(name = "厂商实际值")
    private String vendorValue;

    /** 厂商名称 */
    @Excel(name = "厂商名称")
    private String vendorName;

    public void setVendorId(Long vendorId)
    {
        this.vendorId = vendorId;
    }

    public Long getVendorId()
    {
        return vendorId;
    }
    public void setVendorValue(String vendorValue)
    {
        this.vendorValue = vendorValue;
    }

    public String getVendorValue()
    {
        return vendorValue;
    }
    public void setVendorName(String vendorName)
    {
        this.vendorName = vendorName;
    }

    public String getVendorName()
    {
        return vendorName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("vendorId", getVendorId())
                .append("parentId", getParentId())
                .append("ancestors", getAncestors())
                .append("vendorValue", getVendorValue())
                .append("vendorName", getVendorName())
                .append("orderNum", getOrderNum())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}
