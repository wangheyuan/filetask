/**
 * 文件名称:          	DeviceStatusDto
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.dto;

import lombok.Data;

/**
 * 设备状态
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 16:03
 */
@Data
public class DeviceStatusDto {
    private String channel_status;
}
