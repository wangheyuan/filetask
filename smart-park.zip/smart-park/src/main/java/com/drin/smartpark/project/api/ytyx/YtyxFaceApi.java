/**
 * 文件名称:          	YtyxFaceApi
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx;

import com.drin.smartpark.project.api.ytyx.dto.YtyxRestResp;
import com.drin.smartpark.project.api.ytyx.model.face.StaffModel;
import com.drin.smartpark.project.api.ytyx.model.face.StaffPostForm;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.List;
import java.util.Map;

/**
 * 在云悉平台操作人员
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/5 11:04
 */
public interface YtyxFaceApi {

    // 删除云悉的员工
    @DELETE("park/website/staffs/{id}")
    Call<YtyxRestResp<String>> removeStaff(@Path("id") String staffId);

    // 获取云悉的人员列表
    @GET("park/website/staffs")
    Call<YtyxRestResp<List<StaffModel>>> staffList(@QueryMap Map<String, Object> param);

    // 新增人员信息
    @POST("park/website/staffs")
    Call<YtyxRestResp<Object>> addStaff(@Body StaffPostForm param);

    // 更新人员信息
    @PUT("park/website/staffs/{id}")
    Call<YtyxRestResp<List<StaffModel>>> updateList(@Path("id") String staffId, @Body StaffModel param);

}