/**
 * 文件名称:          	AlgorithmConfig
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.video;

import lombok.Data;

/**
 * 记录摄像头的配置
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/30 14:17
 */
@Data
public class AlgorithmConfig {
    private String config;
}
