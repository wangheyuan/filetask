package com.drin.smartpark.project.check.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import java.util.List;
import com.drin.smartpark.project.check.entity.BsQueryRecord;

/**
 * 考勤管理Mapper接口
 *
 * @author kano
 * @date 2020-12-25
 */
public interface BsQueryRecordMapper  extends BaseMapper<BsQueryRecord>
{
    /**
     * 查询考勤管理
     *
     * @param recordId 考勤管理ID
     * @return 考勤管理
     */
    public BsQueryRecord selectBsQueryRecordById(Long recordId);

    /**
     * 查询考勤管理列表
     *
     * @param bsQueryRecord 考勤管理
     * @return 考勤管理集合
     */
    public List<BsQueryRecord> selectBsQueryRecordList(BsQueryRecord bsQueryRecord);

    /**
     * 新增考勤管理
     *
     * @param bsQueryRecord 考勤管理
     * @return 结果
     */
    public int insertBsQueryRecord(BsQueryRecord bsQueryRecord);

    /**
     * 修改考勤管理
     *
     * @param bsQueryRecord 考勤管理
     * @return 结果
     */
    public int updateBsQueryRecord(BsQueryRecord bsQueryRecord);

    /**
     * 删除考勤管理
     *
     * @param recordId 考勤管理ID
     * @return 结果
     */
    public int deleteBsQueryRecordById(Long recordId);

    /**
     * 批量删除考勤管理
     *
     * @param recordIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsQueryRecordByIds(Long[] recordIds);
}