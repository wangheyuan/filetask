/**
 * 文件名称:          	DeletePersonFormSub
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj.model.form.sub;

import lombok.Data;

import java.util.List;

/**
 * 删除人员的实体
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/7 11:13
 */
@Data
public class DeletePersonFormSub {
    private Integer DeviceID;
    private Integer TotalNum;
    private int IdType;
    private List<Integer> CustomizeID;
}
