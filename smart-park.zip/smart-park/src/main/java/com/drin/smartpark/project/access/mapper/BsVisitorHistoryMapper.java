package com.drin.smartpark.project.access.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.access.entity.BsVisitorHistory;

import java.util.List;

/**
 * 访客历史列表Mapper接口
 *
 * @author ruoyi
 * @date 2020-09-07
 */
public interface BsVisitorHistoryMapper  extends BaseMapper<BsVisitorHistory>
{
    /**
     * 查询访客历史列表
     *
     * @param visitorId 访客历史列表ID
     * @return 访客历史列表
     */
    public BsVisitorHistory selectBsVisitorHistoryById(Long visitorId);

    /**
     * 查询访客历史列表列表
     *
     * @param bsVisitorHistory 访客历史列表
     * @return 访客历史列表集合
     */
    public List<BsVisitorHistory> selectBsVisitorHistoryList(BsVisitorHistory bsVisitorHistory);

    /**
     * 新增访客历史列表
     *
     * @param bsVisitorHistory 访客历史列表
     * @return 结果
     */
    public int insertBsVisitorHistory(BsVisitorHistory bsVisitorHistory);

    /**
     * 修改访客历史列表
     *
     * @param bsVisitorHistory 访客历史列表
     * @return 结果
     */
    public int updateBsVisitorHistory(BsVisitorHistory bsVisitorHistory);

    /**
     * 删除访客历史列表
     *
     * @param visitorId 访客历史列表ID
     * @return 结果
     */
    public int deleteBsVisitorHistoryById(Long visitorId);

    /**
     * 批量删除访客历史列表
     *
     * @param visitorIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsVisitorHistoryByIds(Long[] visitorIds);
}