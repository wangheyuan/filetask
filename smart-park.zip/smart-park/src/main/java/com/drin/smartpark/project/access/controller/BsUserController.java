/**
 * 文件名称:          	BsUserController
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.access.controller;

import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.common.tool.JsonUtil;
import com.drin.smartpark.common.tool.SecurityUtils;
import com.drin.smartpark.common.tool.StringUtils;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.framework.page.TableDataInfo;
import com.drin.smartpark.project.access.entity.BsVisitor;
import com.drin.smartpark.project.access.service.IBsVisitorService;
import com.drin.smartpark.project.system.service.SysPostService;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 用户信息管理Controller
 *
 * @author wangheyuan
 * @date 2020-09-02
 */
@Slf4j
@RestController
@RequestMapping("/access/user")
public class BsUserController extends BaseController
{
    @Autowired
    private IBsVisitorService bsVisitorService;

    @Autowired
    private SysPostService postService;

    /**
     * 查询用户信息管理列表
     */
    @RequiresPermissions("access:user:list")
    @GetMapping("/list")
    public TableDataInfo list(BsVisitor bsVisitor)
    {
        startPage();
        // 用户类型为1
        bsVisitor.setVisitorType("0");
        List<BsVisitor> list = bsVisitorService.selectBsVisitorList(bsVisitor);
        return getDataTable(list);
    }

    /**
     * 导出用户信息管理列表
     */
    @RequiresPermissions("access:user:export")
    @Log(title = "用户信息管理", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsVisitor bsVisitor)
    {
        // 用户类型为1
        bsVisitor.setVisitorType("0");
        List<BsVisitor> list = bsVisitorService.selectBsVisitorList(bsVisitor);
        ExcelUtil<BsVisitor> util = new ExcelUtil<BsVisitor>(BsVisitor.class);
        return util.exportExcel(list, "user");
    }

    /**
     * 根据用户编号获取详细标签信息
     */
    @RequiresPermissions("access:user:query")
    @GetMapping(value = { "/", "/{userId}" })
    public RestResp getPost(@PathVariable(value = "userId", required = false) Long userId)
    {
        RestResp ajax = RestResp.success();
        ajax.put("posts", postService.selectPostAll());
        if (StringUtils.isNotNull(userId))
        {
            ajax.put(RestResp.DATA_TAG, bsVisitorService.selectBsVisitorById(userId));
            ajax.put("postIds", postService.selectPostListByVisitorId(userId));
        }
        return ajax;
    }


    /**
     * 新增用户信息管理
     */
    @RequiresPermissions("access:user:add")
    @Log(title = "用户信息管理", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsVisitor bsVisitor)
    {
        // 用户类型为1
        bsVisitor.setVisitorType("0");
        return toAjax(bsVisitorService.insertBsVisitor(bsVisitor));
    }

    /**
     * 修改用户信息管理
     */
    @RequiresPermissions("access:user:edit")
    @Log(title = "用户信息管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsVisitor bsVisitor)
    {
        bsVisitor.setUpdateBy(SecurityUtils.getUsername());
        return toAjax(bsVisitorService.updateBsVisitor(bsVisitor));
    }

    /**
     * 删除用户信息管理
     */
    @RequiresPermissions("access:user:remove")
    @Log(title = "用户信息管理", businessType = BusinessType.DELETE)
    @DeleteMapping("/{userIds}")
    public RestResp remove(@PathVariable Long[] userIds)
    {
        log.info("userId:{}", JsonUtil.toJsonString(userIds));
        // 需要增加用户校验，防止删除用户的时候删掉了用户
        return toAjax(bsVisitorService.deleteBsVisitorByIds(userIds));
    }
}