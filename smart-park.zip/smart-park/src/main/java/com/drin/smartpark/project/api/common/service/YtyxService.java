/**
 * 文件名称:          	YtyxService
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.common.service;

import com.drin.smartpark.project.check.entity.BsCommonDevice;
import com.drin.smartpark.project.check.entity.BsStaff;

import java.util.List;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/5 11:45
 */
public interface YtyxService {

    /**
     * 获取云悉的子设备
     * @param parentDevice
     * @return java.util.List<com.drin.smartpark.project.check.entity.BsCommonDevice>
     * @author HIPAA
     * @date 2021/1/5 11:47
     */
    public List<BsCommonDevice> childDeviceList(BsCommonDevice parentDevice);

    /**
     * 云悉录入人员
     * @param device
     * @param staff
     * @return void
     * @author HIPAA
     * @date 2021/1/5 11:31
     */
    public void addStaffToDevice(BsCommonDevice device, BsStaff staff);

    /**
     * 云悉删除人员
     * @param device
     * @param staffId
     * @return void
     * @author HIPAA
     * @date 2021/1/5 11:35
     */
    public void removeStaffFromDevice(BsCommonDevice device, String staffId);

}