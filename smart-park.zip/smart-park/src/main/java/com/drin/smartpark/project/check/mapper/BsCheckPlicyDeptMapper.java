/**
 * 文件名称:          	BsCheckPlicyDeptMapper
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.drin.smartpark.project.check.entity.BsCheckPlicyDept;

import java.util.List;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/12/2 14:06
 */
public interface BsCheckPlicyDeptMapper extends BaseMapper<BsCheckPlicyDept> {

    /**
     * 通过策略ID删除策略和标签关联
     *
     * @param plicyId 策略ID
     * @return 结果
     */
    public int deleteCheckPlicyDeptByPlicyId(Long plicyId);

    /**
     * 通过标签ID查询标签使用数量
     *
     * @param deviceId 标签ID
     * @return 结果
     */
    public int countCheckPlicyDeptById(Long deviceId);

    /**
     * 批量删除策略和标签关联
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteCheckPlicyDeptByPlicyIds(Long[] ids);

    /**
     * 批量新增策略标签信息
     *
     * @param plicyDeptList 策略角色列表
     * @return 结果
     */
    public int batchCheckPlicyDept(List<BsCheckPlicyDept> plicyDeptList);
    
}