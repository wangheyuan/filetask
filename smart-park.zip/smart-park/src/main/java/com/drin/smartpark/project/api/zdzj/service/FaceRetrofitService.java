/**
 * 文件名称:          	RetrofitFactory
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj.service;

import com.drin.smartpark.project.access.entity.BsDevice;
import com.drin.smartpark.project.access.mapper.BsDeviceMapper;
import com.drin.smartpark.project.api.zdzj.net.SSLTool;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import javax.annotation.PostConstruct;
import javax.net.ssl.*;
import java.io.IOException;
import java.security.KeyStore;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * 初始化需要调用的请求
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/24 14:56
 */
@Slf4j
@Service
public class FaceRetrofitService {

    @Autowired
    private BsDeviceMapper deviceMapper;

    @Value("${httpLogFlag}")
    private Boolean httpLogFlag;
    

    private Map<String,Retrofit> retrofitMap = new HashMap<>();
    
    private Map<String,Retrofit> tempRetrofitMap = new HashMap<>();
    
    
    /**
     * 临时初始化一个retrofit对象，获取设备id
     * @param device
     * @return void
     * @author HIPAA
     * @date 2020/9/9 23:33
     */
    public void tempInitDeviceService(BsDevice device) {
        tempRetrofitMap.put(device.getDeviceIp(),retrofitByBsDevice(device));
    }

    public void clearReftrofitByBsDevice(BsDevice device) {
        retrofitMap.remove(device.getDeviceIp());
    }

    // 初始化retrofit对应的拦截器和请求配置
    @PostConstruct
    public void init() {

        List<BsDevice> deceiveList =deviceMapper.selectBsDeviceList(new BsDevice());
        if(!CollectionUtils.isEmpty(deceiveList)) {
            deceiveList.stream().forEach(device -> {
                // 对没有初始化的设备进行初始化
                if(retrofitMap.get(device.getDeviceIp())==null) {
                    retrofitMap.put(device.getDeviceIp(), retrofitByBsDevice(device));
                }
            });
        }


    }


    /**
     *  根据ip和对应apiService返回对应的实体类
     * @param ip
     * @param serviceClass
     * @return T
     * @author HIPAA
     * @date 2020/7/29 0:25
     */
    public <T> T getApiByIPService(String ip,Class<T> serviceClass){
        Retrofit retrofit =retrofitMap.get(ip);
        if(retrofit==null) {
            retrofit = tempRetrofitMap.get(ip);
        }
        return retrofit.create(serviceClass);
    }
    
    /**
     * 根据设备信息初始化retrofit信息
     * @param device
     * @return retrofit2.Retrofit
     * @author HIPAA
     * @date 2020/9/9 23:23
     */
    @SneakyThrows
    private Retrofit retrofitByBsDevice(BsDevice device)  {
        TrustManagerFactory trustManagerFactory = null;
        trustManagerFactory = TrustManagerFactory.getInstance(
                TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init((KeyStore) null);
        TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
        if (trustManagers.length != 1 || !(trustManagers[0] instanceof X509TrustManager)) {
            throw new IllegalStateException("Unexpected default trust managers:"
                    + Arrays.toString(trustManagers));
        }
        X509TrustManager trustManager = (X509TrustManager) trustManagers[0];
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{trustManager}, null);
        SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

        HttpLoggingInterceptor logInterceptor = new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
            @Override
            public void log(String message) {
                if(httpLogFlag && !message.contains("----------------------")) {
                    log.info("第三方请求：{}",message);
                }
            }
        });
        logInterceptor.setLevel( HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client=  new OkHttpClient.Builder().connectTimeout(5L, TimeUnit.SECONDS)
                .sslSocketFactory(sslSocketFactory, trustManager)
//                .sslSocketFactory(SSLTool.createSSLSocketFactory())
                .hostnameVerifier(new SSLTool.TrustAllHostnameVerifier())
                .addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request originalRequest = chain.request();
                        String url = originalRequest.url().toString();
                        Request.Builder requestBuilder = originalRequest
                                .newBuilder();
                        if(device.getAccount()!=null && device.getPassword()!=null) {
                            String token = device.getAccount()+":"+device.getPassword();
                            requestBuilder.header("Authorization","Basic "+ Base64.getEncoder().encodeToString(token.getBytes()));
                        }
                        Request original = chain.request();
                        Request request = requestBuilder.header("Content-Type","application/json")
                                .header("Accept","application/json")
                                .method(original.method(), original.body()).build();
                        return chain.proceed(request);
                    }
                })
                .addInterceptor(logInterceptor)
                .build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(device.getDeviceIp())
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        return retrofit;
    }
    
    




}
