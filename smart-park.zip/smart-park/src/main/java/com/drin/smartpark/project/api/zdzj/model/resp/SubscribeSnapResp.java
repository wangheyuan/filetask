package com.drin.smartpark.project.api.zdzj.model.resp;

import com.drin.smartpark.project.api.zdzj.model.resp.sub.SubscribeSnapSubResp;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/9/9 14:26
 * @描述: 陌生人抓拍上报实体类
 */
@Data
public class SubscribeSnapResp {
    private String operator;
    private SubscribeSnapSubResp info;
    @JsonProperty("SanpPic")
    private String SanpPic;
}
