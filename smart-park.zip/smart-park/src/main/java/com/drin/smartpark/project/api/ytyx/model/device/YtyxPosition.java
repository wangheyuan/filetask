/**
 * 文件名称:          	YtyxPosition
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.device;

import lombok.Data;

/**
 * 设备在地图的位置
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/4 10:40
 */
@Data
public class YtyxPosition {
    private double x;
    private double y;
}
