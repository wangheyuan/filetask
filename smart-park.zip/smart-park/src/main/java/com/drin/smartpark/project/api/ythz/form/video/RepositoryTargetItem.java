/**
 * 文件名称:          	RepositoryTargetItem
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.video;

import lombok.Data;

/**
 * 记录目标人脸库的配置
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/30 14:25
 */
@Data
public class RepositoryTargetItem {

    private String  repo_id;
    private Integer threshold;
    private Integer topK;

}
