package com.drin.smartpark.project.check.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import java.util.List;

import com.drin.smartpark.project.check.dto.GroupCheckDay;
import com.drin.smartpark.project.check.entity.BsStaffCaptureDay;

/**
 * 每日考勤Mapper接口
 *
 * @author wangheyuan
 * @date 2020-11-27
 */
public interface BsStaffCaptureDayMapper  extends BaseMapper<BsStaffCaptureDay>
{
    /**
     * 查询每日考勤
     *
     * @param historyDayId 每日考勤ID
     * @return 每日考勤
     */
    public BsStaffCaptureDay selectBsStaffCaptureDayById(Long historyDayId);

    /**
     * 查询每日考勤列表
     *
     * @param bsStaffCaptureDay 每日考勤
     * @return 每日考勤集合
     */
    public List<BsStaffCaptureDay> selectBsStaffCaptureDayList(BsStaffCaptureDay bsStaffCaptureDay);

    /**
     * 新增每日考勤
     *
     * @param bsStaffCaptureDay 每日考勤
     * @return 结果
     */
    public int insertBsStaffCaptureDay(BsStaffCaptureDay bsStaffCaptureDay);

    /**
     * 修改每日考勤
     *
     * @param bsStaffCaptureDay 每日考勤
     * @return 结果
     */
    public int updateBsStaffCaptureDay(BsStaffCaptureDay bsStaffCaptureDay);

    /**
     * 删除每日考勤
     *
     * @param historyDayId 每日考勤ID
     * @return 结果
     */
    public int deleteBsStaffCaptureDayById(Long historyDayId);

    /**
     * 批量删除每日考勤
     *
     * @param historyDayIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsStaffCaptureDayByIds(Long[] historyDayIds);

    public List<GroupCheckDay> selectBsStaffCaptureDayGroupList(BsStaffCaptureDay bsStaffCaptureDay);

}