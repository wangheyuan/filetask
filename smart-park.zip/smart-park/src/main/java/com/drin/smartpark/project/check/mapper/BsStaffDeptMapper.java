package com.drin.smartpark.project.check.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import java.util.List;
import com.drin.smartpark.project.check.entity.BsStaffDept;

/**
 * 员工部门管理Mapper接口
 *
 * @author wangheyuan
 * @date 2020-11-19
 */
public interface BsStaffDeptMapper  extends BaseMapper<BsStaffDept>
{
    /**
     * 查询员工部门管理
     *
     * @param deptId 员工部门管理ID
     * @return 员工部门管理
     */
    public BsStaffDept selectBsStaffDeptById(Long deptId);

    /**
     * 查询员工部门管理列表
     *
     * @param bsStaffDept 员工部门管理
     * @return 员工部门管理集合
     */
    public List<BsStaffDept> selectBsStaffDeptList(BsStaffDept bsStaffDept);

    /**
     * 新增员工部门管理
     *
     * @param bsStaffDept 员工部门管理
     * @return 结果
     */
    public int insertBsStaffDept(BsStaffDept bsStaffDept);

    /**
     * 修改员工部门管理
     *
     * @param bsStaffDept 员工部门管理
     * @return 结果
     */
    public int updateBsStaffDept(BsStaffDept bsStaffDept);

    /**
     * 删除员工部门管理
     *
     * @param deptId 员工部门管理ID
     * @return 结果
     */
    public int deleteBsStaffDeptById(Long deptId);

    /**
     * 批量删除员工部门管理
     *
     * @param deptIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBsStaffDeptByIds(Long[] deptIds);

    /**
     * 根据策略ID获取标签选择框列表
     *
     * @param plicyId 策略ID
     * @return 选中标签ID列表
     */
    public List<Long> selectBsStaffDeptIdListByPlicyId(Long plicyId);
}