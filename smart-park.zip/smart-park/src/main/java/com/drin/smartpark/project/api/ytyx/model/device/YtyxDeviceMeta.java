/**
 * 文件名称:          	YtyxDeviceMeta
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.device;

import lombok.Data;

import java.util.Map;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/4 10:21
 */
@Data
public class YtyxDeviceMeta {
    private String adjacency_id;
    private String device_name;
    //设备出入口状态, 0代表入口设备,1代表出口设备,-1代表无
    //样例 : 0
    private int direction_type;
    private Map<String,Object> docking_config;
    private boolean enable;
    private String ip;
    private String location;
    private String map_id;
    private String password;
    private int port;
    private YtyxPosition position;
    //设备型号
    private String specification;
    //设备类型, 1代表c230抓拍机，2代表门禁，3代表闸机，4代表海康抓拍机，5代表NVR视频流, 7代表依图抓拍机, 8代表视频摄像机
    private String type;
    private String username;
    private String version;
    //频分辨率, 1代表1080P
    private String video_definition_type;

}
