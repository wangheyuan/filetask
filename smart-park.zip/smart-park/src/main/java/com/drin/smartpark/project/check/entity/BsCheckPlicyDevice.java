/**
 * 文件名称:          	BsCheckPlicyDevice
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.check.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 *  考勤策略设备
 * <p>
 * Version		1.0.0
 *
 * @author wangheyuan
 * <p>
 * Date	      2020/11/25 13:30
 */
public class BsCheckPlicyDevice {

    /** 策略ID */
    private Long plicyId;

    /** 岗位ID */
    private Long deviceId;

    public Long getPlicyId()
    {
        return plicyId;
    }

    public void setPlicyId(Long plicyId)
    {
        this.plicyId = plicyId;
    }

    public Long getDeviceId()
    {
        return deviceId;
    }

    public void setDeviceId(Long deviceId)
    {
        this.deviceId = deviceId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("plicyId", getPlicyId())
                .append("deviceId", getDeviceId())
                .toString();
    }

}
