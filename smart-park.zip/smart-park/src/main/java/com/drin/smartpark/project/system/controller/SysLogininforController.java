package com.drin.smartpark.project.system.controller;

import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.framework.page.TableDataInfo;
import com.drin.smartpark.project.system.entity.SysLogininfor;
import com.drin.smartpark.project.system.service.SysLogininforService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 系统访问记录
 * 
 * @author wangheyuan
 */
@RestController
@RequestMapping("/monitor/logininfor")
public class SysLogininforController extends BaseController
{
    @Autowired
    private SysLogininforService logininforService;

    @RequiresPermissions("monitor:logininfor:list")
    @GetMapping("/list")
    public TableDataInfo list(SysLogininfor logininfor)
    {
        startPage();
        List<SysLogininfor> list = logininforService.selectLogininforList(logininfor);
        return getDataTable(list);
    }

    @Log(title = "登陆日志", businessType = BusinessType.EXPORT)
    @RequiresPermissions("monitor:logininfor:export")
    @GetMapping("/export")
    public RestResp export(SysLogininfor logininfor)
    {
        List<SysLogininfor> list = logininforService.selectLogininforList(logininfor);
        ExcelUtil<SysLogininfor> util = new ExcelUtil<SysLogininfor>(SysLogininfor.class);
        return util.exportExcel(list, "登陆日志");
    }

    @RequiresPermissions("monitor:logininfor:remove")
    @Log(title = "登陆日志", businessType = BusinessType.DELETE)
    @DeleteMapping("/{infoIds}")
    public RestResp remove(@PathVariable Long[] infoIds)
    {
        return toAjax(logininforService.deleteLogininforByIds(infoIds));
    }

    @RequiresPermissions("monitor:logininfor:remove")
    @Log(title = "登陆日志", businessType = BusinessType.CLEAN)
    @DeleteMapping("/clean")
    public RestResp clean()
    {
        logininforService.cleanLogininfor();
        return RestResp.success();
    }
}
