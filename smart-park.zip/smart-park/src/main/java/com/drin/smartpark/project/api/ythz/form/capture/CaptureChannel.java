/**
 * 文件名称:          	CaptureChannels
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.capture;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * 盒子抓拍机的设置
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/7 14:12
 */
@Data
public class CaptureChannel {
    private String channel_id;
    private String  channel_name;
    private String channel_ip;
    private Integer channel_port;
    private String username;
    private String password;
    private String channel_type="FaceRetrieval";
    //默认厂商是依图设备
    private String vendor="YITU";
    private String extra_meta = "{\"device_id\":\"\",\"place_code\":\"0\",\"camera_path\":\"\",\"longitude\":0,\"latitude\":0}";
    private Integer  Number=1;
    private List<String> target_repo = new ArrayList<>();
    private String tdKind;
    private String device_id;
    private String camera_path="";
    private Integer longitude;
    private Integer latitude;
}
