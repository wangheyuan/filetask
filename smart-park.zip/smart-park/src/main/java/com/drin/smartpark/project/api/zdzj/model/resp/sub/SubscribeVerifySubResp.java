package com.drin.smartpark.project.api.zdzj.model.resp.sub;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @作者: Kano
 * @时间:2020/9/7 14:08
 * @描述: 认证结果info
 */
@Data
public class SubscribeVerifySubResp {
    //设备ID
    @JsonProperty("DeviceID")
    private int DeviceID;
    //设备储存的人员ID号
    @JsonProperty("PersonID")
    private int PersonID;
    //当前设备时间
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonProperty("CreateTime")
    private LocalDateTime CreateTime;
    //黑名单对比相似度
    @JsonProperty("Similarity1")
    private float Similarity1;
    //身份证比对相似度
    @JsonProperty("Similarity2")
    private float Similarity2;
    //认证结果 0无 1允许 2拒绝 3还没有注册
    @JsonProperty("VerifyStatus")
    private int VerifyStatus;
    //验证类型 1白名单验证 2身份证验证 3白名单+身份证验证
    @JsonProperty("VerfyType")
    private int VerfyType;
    //名单类型   0白名单  1黑名单
    @JsonProperty("PersonType")
    private int PersonType;
    //姓名
    @JsonProperty("Name")
    private String Name;
    //性别 0男  1女  2其他
    @JsonProperty("Gender")
    private Integer Gender;
    //民族   1汉....
    @JsonProperty("Nation")
    private int Nation;
    //证件号
    @JsonProperty("IdCard")
    private String IdCard;
    //生日
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonProperty("Birthday")
    private LocalDate Birthday;
    //电话号码
    @JsonProperty("Telnum")
    private String Telnum;
    //籍贯
    @JsonProperty("Native")
    private String Native;
    //地址
    @JsonProperty("Address")
    private String Address;
    //备注
    @JsonProperty("Notes")
    private String Notes;
    //是否是临时名单 0永久名单  1临时名单 2临时名单2 3临时名单3
    @JsonProperty("Tempvalid")
    private int Tempvalid;

    @JsonProperty("CustomizeID")
    private Integer CustomizeID;



}
