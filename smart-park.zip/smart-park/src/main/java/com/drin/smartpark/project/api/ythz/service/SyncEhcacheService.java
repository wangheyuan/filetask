/**
 * 文件名称:          	SyncEhcacheService
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.service;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 本机缓存
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/24 15:51
 */
@Service
public class SyncEhcacheService {

    static ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();
    static Lock r = rwl.readLock();
    static Lock w = rwl.writeLock();

    private static String cacheName = "sessionCache";


    @Autowired
    private CacheManager cacheManager;

    public  void putCode(String key, String value) {
        //获取Cache
        w.lock();
        Cache cache=cacheManager.getCache(cacheName);
        cache.put(new Element(key,value));
        w.unlock();
    }


    public String getCode(String key) {
        //获取Cache
        r.lock();
        Cache cache=cacheManager.getCache(cacheName);
        Element element = cache.get(key);
        if(element == null){
            r.unlock();
            return  null;
        }
        String value =element.getObjectValue().toString();
        r.unlock();
        return value;
    }





}
