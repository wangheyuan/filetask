/**
 * 文件名称:          	FaceSearchItemDto
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.dto.face;

import lombok.Data;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/29 10:48
 */
@Data
public class FaceSearchItemDto {

    /** 人像的meta信息 */
    private String extra_meta;
    /** 人像的id */
    private String face_id;
    /** 特征值的base64 非图片*/
    private String feature;

}
