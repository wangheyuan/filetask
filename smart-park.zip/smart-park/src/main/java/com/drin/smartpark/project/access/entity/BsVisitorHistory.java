package com.drin.smartpark.project.access.entity;

import com.drin.smartpark.common.BaseEntity;
import com.drin.smartpark.framework.excel.annotation.Excel;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 访客历史列表对象 bs_visitor_history
 *
 * @author ruoyi
 * @date 2020-09-07
 */
public class BsVisitorHistory extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 访客主键 */
    @Excel(name = "访客主键")
    private Long visitorId;

    /** 访客名称 */
    @Excel(name = "访客名称")
    private String visitorName;

    /** 身份证号 */
    @Excel(name = "身份证号")
    private String visitorCard;

    /** 访客照片id */
    @Excel(name = "访客照片id")
    private String imageId;

    /** 0正常 1 为黑名单 */
    @Excel(name = "0正常 1 为黑名单")
    private String status;

    /** 进入时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "进入时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date inTime;

    /** 离开时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "离开时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date outTime;

    /** 抓拍访客照片id */
    private String captureId;

    /** 抓拍访客场景照片id */
    private String pictureId;

    public void setVisitorId(Long visitorId)
    {
        this.visitorId = visitorId;
    }

    public Long getVisitorId()
    {
        return visitorId;
    }
    public void setVisitorName(String visitorName)
    {
        this.visitorName = visitorName;
    }

    public String getVisitorName()
    {
        return visitorName;
    }
    public void setVisitorCard(String visitorCard)
    {
        this.visitorCard = visitorCard;
    }

    public String getVisitorCard()
    {
        return visitorCard;
    }
    public void setImageId(String imageId)
    {
        this.imageId = imageId;
    }

    public String getImageId()
    {
        return imageId;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }
    public void setInTime(Date inTime)
    {
        this.inTime = inTime;
    }

    public Date getInTime()
    {
        return inTime;
    }
    public void setOutTime(Date outTime)
    {
        this.outTime = outTime;
    }

    public Date getOutTime()
    {
        return outTime;
    }

    public String getCaptureId() {
        return captureId;
    }

    public void setCaptureId(String captureId) {
        this.captureId = captureId;
    }

    public String getPictureId() {
        return pictureId;
    }

    public void setPictureId(String pictureId) {
        this.pictureId = pictureId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("visitorId", getVisitorId())
                .append("visitorName", getVisitorName())
                .append("visitorCard", getVisitorCard())
                .append("imageId", getImageId())
                .append("status", getStatus())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("inTime", getInTime())
                .append("outTime", getOutTime())
                .toString();
    }
}