/**
 * 文件名称:          	FaceInfo
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.face;

import lombok.Data;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/18 2:24
 */
@Data
public class FaceInfo {
    private String face_id;
    private String face_image_id;
    private String scene_image_id;
}
