/**
 * 文件名称:          	ErrorPageResovler
 * 版权所有@ 2019-2020 	易鑫集团，保留所有权利
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.common.config;

import org.springframework.boot.autoconfigure.web.servlet.error.ErrorViewResolver;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * 配置自定义错误页面
 * 注意此配置只能在2.0.5版本使用，版本过高可能会报错
 * <p>
 * Version		1.0.0
 *
 * @author wangheyuan
 * <p>
 * Date	      2020/5/6 13:02
 */
//@Component
public class ErrorPageResovler implements ErrorViewResolver {

    @Override
    public ModelAndView resolveErrorView(HttpServletRequest request, HttpStatus status, Map<String, Object> model) {
        ModelAndView mv = new ModelAndView();
        switch (status) {
            case NOT_FOUND:
                mv.setViewName("redirect:/error/404.html");
                break;
            default:
                mv.setViewName("redirect:/err404.html");
        }
        return mv;
    }
}
