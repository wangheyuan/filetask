/**
 * 文件名称:          	DetectFaceForm
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.zdzj.model.form;

/**
 * 检测人脸
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/7 13:41
 */
public class DetectFaceForm {

    private String operator;
    // 图片base64信息 头信息: data:image/jpeg;base64,
    private String picinfo;

    public void setPicinfo(String picinfo) {
        this.picinfo = "data:image/jpeg;base64," + picinfo;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getPicinfo() {
        return picinfo;
    }

    public DetectFaceForm(String picinfo) {
        this.operator = "DetectFaceFromPic";
        this.picinfo = "data:image/jpeg;base64," + picinfo;
    }

}
