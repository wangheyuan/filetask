package com.drin.smartpark.project.check.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.drin.smartpark.framework.log.annotation.Log;
import com.drin.smartpark.common.BaseController;
import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.framework.log.enums.BusinessType;
import com.drin.smartpark.project.check.entity.BsQueryRecord;
import com.drin.smartpark.project.check.service.IBsQueryRecordService;
import com.drin.smartpark.framework.excel.poi.ExcelUtil;
import com.drin.smartpark.framework.page.TableDataInfo;

/**
 * 考勤管理Controller
 *
 * @author kano
 * @date 2020-12-25
 */
@RestController
@RequestMapping("/check/record")
public class BsQueryRecordController extends BaseController
{
    @Autowired
    private IBsQueryRecordService bsQueryRecordService;

    /**
     * 查询考勤管理列表
     */
    @RequiresPermissions("check:record:list")
    @GetMapping("/list")
    public TableDataInfo list(BsQueryRecord bsQueryRecord)
    {
        startPage();
        List<BsQueryRecord> list = bsQueryRecordService.selectBsQueryRecordList(bsQueryRecord);
        return getDataTable(list);
    }

    /**
     * 导出考勤管理列表
     */
    @RequiresPermissions("check:record:export")
    @Log(title = "考勤管理", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public RestResp export(BsQueryRecord bsQueryRecord)
    {
        List<BsQueryRecord> list = bsQueryRecordService.selectBsQueryRecordList(bsQueryRecord);
        ExcelUtil<BsQueryRecord> util = new ExcelUtil<BsQueryRecord>(BsQueryRecord.class);
        return util.exportExcel(list, "record");
    }

    /**
     * 获取考勤管理详细信息
     */
    @RequiresPermissions("check:record:query")
    @GetMapping(value = "/{recordId}")
    public RestResp getInfo(@PathVariable("recordId") Long recordId)
    {
        return RestResp.success(bsQueryRecordService.selectBsQueryRecordById(recordId));
    }

    /**
     * 新增考勤管理
     */
    @RequiresPermissions("check:record:add")
    @Log(title = "考勤管理", businessType = BusinessType.INSERT)
    @PostMapping
    public RestResp add(@RequestBody BsQueryRecord bsQueryRecord)
    {
        return toAjax(bsQueryRecordService.insertBsQueryRecord(bsQueryRecord));
    }

    /**
     * 修改考勤管理
     */
    @RequiresPermissions("check:record:edit")
    @Log(title = "考勤管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public RestResp edit(@RequestBody BsQueryRecord bsQueryRecord)
    {
        return toAjax(bsQueryRecordService.updateBsQueryRecord(bsQueryRecord));
    }

    /**
     * 删除考勤管理
     */
    @RequiresPermissions("check:record:remove")
    @Log(title = "考勤管理", businessType = BusinessType.DELETE)
    @DeleteMapping("/{recordIds}")
    public RestResp remove(@PathVariable Long[] recordIds)
    {
        return toAjax(bsQueryRecordService.deleteBsQueryRecordByIds(recordIds));
    }
}