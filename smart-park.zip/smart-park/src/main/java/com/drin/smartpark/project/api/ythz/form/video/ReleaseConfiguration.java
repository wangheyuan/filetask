/**
 * 文件名称:          	ReleaseConfiguration
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.form.video;

import lombok.Data;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2021/1/5 16:26
 */
@Data
public class ReleaseConfiguration {
   private boolean has_feature;
   private boolean has_face_image;
   private boolean has_scene_image;
   private boolean need_retrieval;
   private Integer capture_threshold;
   private Integer scene_image_resize_ratio;
   private Integer face_image_compress_ratio;
   private String mode;
}
