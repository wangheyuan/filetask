/**
 * 文件名称:          	PullController
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.controller;

import com.drin.smartpark.common.config.VistConfig;
import com.drin.smartpark.common.tool.BeanUtils;
import com.drin.smartpark.common.tool.DateUtils;
import com.drin.smartpark.common.tool.FileToBase64;
import com.drin.smartpark.common.tool.JsonUtil;
import com.drin.smartpark.framework.util.DateUtil;
import com.drin.smartpark.framework.util.IdWorker;
import com.drin.smartpark.project.check.dto.CheckTime;
import com.drin.smartpark.project.check.dto.QueryCheckPlicyParam;
import com.drin.smartpark.project.check.entity.*;
import com.drin.smartpark.project.check.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.*;

/**
 * 拉取抓拍的照片
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/12/3 10:05
 */
@RestController
public class PullController {

    @Autowired
    private IBsStaffService staffService;

    @Autowired
    private IBsCommonDeviceService deviceService;

    @Autowired
    private IBsStaffCaptureHistoryService historyService;

    @Autowired
    private IBsCheckPlicyService checkPlicyService;

    @Autowired
    private IBsStaffCaptureDayService captureDayService;

    @Autowired
    private IBsStaffPostService postService;



    @Autowired
    private IdWorker idWorker;

    /**
     * 处理盒子的抓拍记录
     * @param formDto
     * @return void
     * @author HIPAA
     * @date 2020/12/3 11:11
     */
    @PostMapping("/pushRecord")
    public void pullRecord(@RequestBody Map<String,Object> formDto) {

        String realId =String.valueOf(formDto.get("channel_id"));


        List<Map<String, Object>> retrieval_results = (List<Map<String, Object>>) formDto.get("retrieval_results");
        Map<String,Object> faceImage_result = (Map<String, Object>) formDto.get("face_image");
        Map<String,Object> sceneImage_result = (Map<String, Object>) formDto.get("scene_image");

        // 如果没有检索记录就不处理
        if (CollectionUtils.isEmpty(retrieval_results))
            return;
        // 获取相似的人脸
        Map<String,Object> simPerson = retrieval_results.get(0);
        List<Map<String,Object>> simFace = (List<Map<String, Object>>) simPerson.get("similar_faces");

        // 如果人员不在人脸库，就无法进行识别
        if(CollectionUtils.isEmpty(simFace))
            return;

        Map<String,Object> faceMap = simFace.get(0);
        // 获取员工的id
        String personId = (String) faceMap.get("person_id");
//        System.out.println(JsonUtil.toJsonString(formDto));
        BsStaff staff = staffService.selectBsStaffById(Long.valueOf(personId));

        if (staff==null){
            System.out.println(personId);
            return;
        }else {
            System.out.println(JsonUtil.toJsonString(staff));
        }
        //员工存在的时候才需要处理
        //获取抓拍时间 这个时间是盒子的时间
        String captureTime = (String) formDto.get("iso8601timestamp");
        Date captureDate = null;
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        try {
            captureDate = fmt.parse(captureTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        //考虑到盒子的时间可能和系统的时间不一致，所以直接以接受到的时间为主
        captureDate = new Date();

        //保存图片信息
        String faceDirHome = VistConfig.getUploadPath()+"/"+ DateUtils.datePath() +"/face";
        String sceneDirHome = VistConfig.getUploadPath()+"/"+ DateUtils.datePath()+"/scene";

        BsCommonDevice device = deviceService.selectBsCommonDeviceByRealId(realId);

        BsStaffCaptureHistory history = new BsStaffCaptureHistory();
        String faceUrl =String.valueOf(idWorker.nextId());
        history.setCaptureId("/profile/upload/"+DateUtils.datePath() + "/face/"+faceUrl+".jpg");
        history.setPictureId("/profile/upload/"+DateUtils.datePath() + "/scene/"+faceUrl+".jpg");
        history.setImageId(staff.getImageId());
        history.setCreateTime(captureDate);
        if(device!=null) {
            history.setDeviceId(device.getDeviceId());
        }
        history.setStaffId(staff.getStaffId());
        history.setStaffName(staff.getStaffName());
        history.setStaffCard(staff.getStaffCard());
        BsCommonDevice parentDevice = deviceService.selectBsCommonDeviceById(device.getParentId().intValue());
        history.setRemark(parentDevice.getDeviceName()+"->"+device.getDeviceName());

        //保存图片信息
        String sceneBase64 = String.valueOf(sceneImage_result.get("content"));
        String faceBase64 = String.valueOf(faceImage_result.get("content"));
        try {
            File faceFileDir = new File(faceDirHome);
            if(!faceFileDir.exists()) {
                faceFileDir.mkdirs();
            }
            File sceneFileDir = new File(sceneDirHome);
            if(!sceneFileDir.exists()) {
                sceneFileDir.mkdirs();
            }
            FileToBase64.decoderBase64File(sceneBase64,sceneDirHome+"/"+faceUrl+".jpg");
            FileToBase64.decoderBase64File(faceBase64,faceDirHome+"/"+faceUrl+".jpg");
        } catch (Exception e) {
            e.printStackTrace();
        }
        //插入每日抓拍记录
        historyService.insertBsStaffCaptureHistory(history);

        // 处理对应的策略
        QueryCheckPlicyParam param = new QueryCheckPlicyParam();
        param.setDeviceId(device.getDeviceId());
        param.setDeptId(7L);
        List<Long> postList = postService.selectStaffPostListByStaffId(staff.getStaffId());
        Long[] postIds = new Long[postList.size()];
        postList.toArray(postIds);
        param.setPostIds(postIds); //staff.getPostIds()
        List<BsCheckPlicy> plicies = checkPlicyService.selectBsCheckPlicyByParam(param);

        // 如果策略信息不存在，不做处理
        if (CollectionUtils.isEmpty(plicies)){
            return;
        }


        // 获取当日考勤内容,默认都存在，不存在新增，存在根据策略的世界确定是否更新上下班的时间
        BsCheckPlicy goalPlicy = new BsCheckPlicy();
        for (int i = 0; i < plicies.size(); i++) {
            BsCheckPlicy plicy = plicies.get(i);
            if(goalPlicy.getPlicyId() == null ) {
                BeanUtils.copyBeanProp(goalPlicy,plicy);
            }else {
                //如果一个人有两个策略，需要获取一个范围最大的策略

            }
        }


        Calendar cal = Calendar.getInstance();
        // 0 表示星期天  1 表示 星期1
        int w = cal.get(Calendar.DAY_OF_WEEK)-1;
        // 0 为全时段 1 为周时段
        if("0".equals(goalPlicy.getPlicyType())){
            dealWithStaffCheckNowTime(staff,goalPlicy);
        }else if("1".equals(goalPlicy.getPlicyType())) {
            switch (w) {
                case 0:
                    // 只有策略对应的天才需要处理
                    if("1".equals(goalPlicy.getSunday())) {
                        dealWithStaffCheckNowTime(staff,goalPlicy);
                    }
                    break;
                case 1:
                    if("1".equals(goalPlicy.getMonday())) {
                        dealWithStaffCheckNowTime(staff,goalPlicy);
                    }
                    break;
                case 2:
                    if("1".equals(goalPlicy.getTuesday())) {
                        dealWithStaffCheckNowTime(staff,goalPlicy);
                    }
                    break;
                case 3:
                    if("1".equals(goalPlicy.getWednesday())) {
                        dealWithStaffCheckNowTime(staff,goalPlicy);
                    }
                    break;
                case 4:
                    if("1".equals(goalPlicy.getThursday())) {
                        dealWithStaffCheckNowTime(staff,goalPlicy);
                    }
                    break;
                case 5:
                    if("1".equals(goalPlicy.getFriday())) {
                        dealWithStaffCheckNowTime(staff,goalPlicy);
                    }
                    break;
                case 6:
                    if("1".equals(goalPlicy.getSaturday())) {
                        dealWithStaffCheckNowTime(staff,goalPlicy);
                    }
                    break;
            }

        }
    }

    private void dealWithStaffCheckNowTime(BsStaff staff,BsCheckPlicy plicy) {
        LocalTime nowTime = LocalTime.now();
        // 只要在规定的时间才会修改考勤的记录,如果比策略的时间早就可以计入考勤 后续需要优化提前几个小时才有效
        if(nowTime.isBefore(plicy.getStartTime()) ) {
            captureDayService.setBsStaffCaptureDayNowInTime(staff.getStaffId(),plicy);
        }
        // 过了下班时间进行打卡
        if(nowTime.isAfter(plicy.getFinishTime())) {
            captureDayService.setBsStaffCaptureDayNowOutTime(staff.getStaffId(),plicy);
        }

        // 如果抓拍的时间在早上 上班 和 下班之间
        if(nowTime.isAfter(plicy.getStartTime()) && nowTime.isBefore(plicy.getFinishTime())) {
            List<BsStaffCaptureHistory> histories = historyService.getTodayStaffCaptureHistory(staff.getStaffId());
            // 因为有抓拍记录，所以至少1条，如果只有一条那么就默认是进入时间，状态为迟到
            if(histories.size()==1) {
                captureDayService.setBsStaffCaptureDayNowInTime(staff.getStaffId(),plicy);
            }else if(histories.size()>1) {
                // 实时更新工作的时长
                captureDayService.setBsStaffCaptureDayNowOutTime(staff.getStaffId(),plicy);
            }
        }
    }






}
