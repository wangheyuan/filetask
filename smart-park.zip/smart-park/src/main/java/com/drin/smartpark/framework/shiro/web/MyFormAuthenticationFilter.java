/**
 * 文件名称:          	MyFormAuthenticationFilter
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.framework.shiro.web;

import com.drin.smartpark.common.RestResp;
import com.drin.smartpark.common.tool.JsonUtil;
import org.apache.shiro.web.filter.authc.FormAuthenticationFilter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

import static com.drin.smartpark.common.constant.HttpStatus.UNAUTHORIZED;

/**
 * TODO: 文件注释
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/9/1 23:24
 */
public class MyFormAuthenticationFilter extends FormAuthenticationFilter {

    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {

        String path = ((HttpServletRequest) request).getRequestURI();
        if(path.contains("index")) {
            return true;
        }

        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        httpServletResponse.setStatus(200);
        httpServletResponse.setContentType("application/json;charset=utf-8");

        PrintWriter out = httpServletResponse.getWriter();

        // session过期的状态码是401
        out.println(JsonUtil.toJsonString(RestResp.error(UNAUTHORIZED,"session失效")));
        out.flush();
        out.close();
        return false;
    }
}