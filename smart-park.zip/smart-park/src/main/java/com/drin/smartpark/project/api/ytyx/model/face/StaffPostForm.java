/**
 * 文件名称:          	StaffPostForm
 * 版权所有@ 2019-2020    wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ytyx.model.face;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * 员工新增
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/8/18 3:46
 */
@Data
public class StaffPostForm {

    boolean enforce = false;
    List<StaffInfo> staff_list = new ArrayList<>();

}
