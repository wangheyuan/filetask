/**
 * 文件名称:          	Isuccess
 * 版权所有@ 2017-2018 	wangheyuan
 * 编译器:           	JDK1.8
 */

package com.drin.smartpark.project.api.ythz.common;

/**
 * 成功调用的方法
 * <p>
 * Version		1.0.0
 *
 * @author HIPAA
 * <p>
 * Date	      2020/7/28 17:16
 */
public interface Isuccess<T> {
    void onSuccess(T result);
}