package com.drin.smartpark.project.api.zdzj.model.resp;

import com.drin.smartpark.project.api.zdzj.model.resp.sub.SubscribeIDCardSubResp;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @作者: Kano
 * @时间:2020/9/9 13:34
 * @描述: 身份证信息返回实体类
 */
@Data
public class SubscribeIDCardResp {

    private String operator;
    private SubscribeIDCardSubResp info;
    @JsonProperty("IDCard_photo")
    private String IDCard_photo;

}
